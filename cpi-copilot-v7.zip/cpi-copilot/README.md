# CPI Copilot v0.7

Design and developed by Pushapgiri Sagarareddy.
Integration operations platform for SAP Integration Suite: monitor, diagnose, trace, move, repair and build, with a copilot panel on every screen and an MCP server for SAP Joule Studio and other agents.

## 1. Deploy
    cd app
    cf push -f manifest.yml

## 2. Set secrets (never put them in files)
Create long random values on Windows, one per line:
    powershell -command "[guid]::NewGuid().ToString('N') + [guid]::NewGuid().ToString('N')"
Then, using one value each:
    cf set-env cpi-copilot-api ACCESS_KEY      <operator key>
    cf set-env cpi-copilot-api APPROVER_KEY    <approver key>
    cf set-env cpi-copilot-api SESSION_SECRET  <random value>
    cf restage cpi-copilot-api
Optional: VIEWER_KEY (read only), ADMIN_KEY (all scopes). Give each person their own key so actions and approvals are attributable.
Four-eyes needs two identities: the operator requests, a different person with the approver key approves.

## 3. Connect tenants (nothing to type in the app)
    cf create-service it-rt api cpi-dev -c cpi-roles.json
    cf bind-service cpi-copilot-api cpi-dev
    cf restage cpi-copilot-api
For queue retry and move add the extra roles, then unbind, bind and restage so the token carries them:
    cf update-service cpi-dev -c cpi-roles-ext.json
Open Connect > Diagnose to see, per API, what the tenant allows and which role is missing.

## 4. Security profiles
- pilot (default): sandbox on, tenants can be added in the UI, 8 hour sessions.
- strict: cf set-env cpi-copilot-api SECURITY_PROFILE strict. Sandbox off, no tenant entry in the UI, 30 minute sessions.
Other switches: READ_ONLY=1, NOTIFY_WEBHOOK_URL, NOTIFY_ON_CRITICAL=1, POLL_SECONDS (default 120, 0 = off), ALLOWED_TENANT_SUFFIXES.
Evidence for security and compliance reviews: Trust center > Evidence pack (printable).

## 5. MCP
    POST https://<app-url>/mcp   Authorization: Bearer <access key>
Writes need confirm=true. UAT, PRE-PROD and PROD create an approval request that a person approves in the web UI. Agents cannot approve.

## Known limits
No SSO bound by default (use XSUAA/IAS for production), audit and jobs are in memory (events are also written as JSON log lines), not independently penetration tested. Validate queue retry/move and package import on a real DEV tenant before relying on them.
