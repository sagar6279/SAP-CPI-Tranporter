"""Writes tenants.json for permanent registration (cf uups). Any number of tenants, any names."""
import json
out = {}
print("Enter each tenant from its Process Integration Runtime service key (oauth block). Empty name to finish.")
while True:
    name = input("\nTenant name (e.g. ACME-DEV): ").strip()
    if not name:
        break
    stage = input("Stage [DEV/QA/UAT/PREPROD/PROD]: ").strip().upper() or "DEV"
    out[name] = {"stage": stage,
                 "url": input("url: ").strip(),
                 "tokenurl": input("tokenurl (ends with /oauth/token): ").strip(),
                 "clientid": input("clientid: ").strip(),
                 "clientsecret": input("clientsecret: ").strip()}
json.dump(out, open("tenants.json", "w"), indent=2)
print("\ntenants.json written for:", ", ".join(out) or "nothing")
print("Next: cf uups cpi-copilot-tenants -p tenants.json  then  cf restage cpi-copilot-api  then delete tenants.json")
