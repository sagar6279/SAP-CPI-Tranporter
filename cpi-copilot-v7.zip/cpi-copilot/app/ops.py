"""Operations: package/iFlow moves between tenants with dependency analysis, snapshot, verification and rollback."""
import difflib, io, re, time, zipfile
import config, jobs
from clients import client_for
from cpi_client import CPIError

KIND_LABEL = {"iflow": "iFlow", "vm": "Value Mapping", "script": "Script Collection"}
KEYMAP = {"iflows": "iflow", "valuemaps": "vm", "scripts": "script"}


def _norm(s):
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def find_package(client, text):
    """Find package by id or name. Returns (package or None, suggestions)."""
    pk = client.packages()
    n = _norm(text)
    for p in pk:
        if _norm(p["Id"]) == n or _norm(p["Name"]) == n:
            return p, []
    for p in pk:
        if n and (n in _norm(p["Id"]) or n in _norm(p["Name"])):
            return p, []
    names = [p["Name"] for p in pk] + [p["Id"] for p in pk]
    return None, difflib.get_close_matches(text, names, n=3, cutoff=0.4)


def find_iflow(client, text):
    """Find an iFlow by id or name across packages. Returns (package_id, iflow) or (None, suggestions)."""
    n = _norm(text)
    allf = []
    for p in client.packages():
        for a in client.package_artifacts(p["Id"])["iflows"]:
            allf.append((p["Id"], a))
    for pid, a in allf:
        if _norm(a["Id"]) == n or _norm(a["Name"]) == n:
            return pid, a
    for pid, a in allf:
        if n and (n in _norm(a["Id"]) or n in _norm(a["Name"])):
            return pid, a
    return None, difflib.get_close_matches(text, [a["Id"] for _, a in allf], n=3, cutoff=0.4)


def scan_content(content):
    creds, eps, vms = set(), set(), set()
    try:
        with zipfile.ZipFile(io.BytesIO(content)) as z:
            for nm in z.namelist():
                if nm.endswith((".iflw", ".prop", ".propdef", ".xml")):
                    t = z.read(nm).decode("utf-8", "ignore")
                    creds.update(re.findall(r"<key>credentialName</key>\s*<value>([^<]+)</value>", t))
                    creds.update(re.findall(r"^credentialName=(.+)$", t, re.M))
                    eps.update(re.findall(r"<key>address</key>\s*<value>([^<]+)</value>", t))
                    vms.update(re.findall(r"<key>valueMappingId</key>\s*<value>([^<]+)</value>", t))
    except Exception:
        pass
    return creds, eps, vms


def build_selection(src, pkg_id, artifacts, include_deps, tgt):
    """Resolve what to move. artifacts=None means the whole package."""
    arts = src.package_artifacts(pkg_id)
    items = []
    for plural, kind in KEYMAP.items():
        for a in arts[plural]:
            items.append({"kind": kind, "id": a["Id"], "name": a["Name"], "version": a["Version"]})
    if artifacts:
        want = {(a["kind"], a["id"]) for a in artifacts}
        sel = [i for i in items if (i["kind"], i["id"]) in want]
        if include_deps:
            have = {(i["kind"], i["id"]) for i in sel}
            for i in items:
                if i["kind"] in ("vm", "script") and (i["kind"], i["id"]) not in have and not tgt.artifact_info(i["kind"], i["id"]):
                    i = dict(i, dependency=True); sel.append(i)
        return sel
    return items


def analyze_move(src, tgt, pkg_id, artifacts=None, include_deps=True, tgt_stage="DEV"):
    issues, creds, eps, vms = [], set(), set(), set()
    pinfo = src.package_info(pkg_id)
    if not pinfo:
        return {"ready": False, "issues": [{"level": "error", "text": "Package '%s' not found in source" % pkg_id}], "artifacts": []}
    sel = build_selection(src, pkg_id, artifacts, include_deps, tgt)
    if not sel:
        issues.append({"level": "error", "text": "Nothing selected to move"})
    exists_pkg = tgt.package_info(pkg_id) is not None
    rows = []
    for it in sel:
        cur = tgt.artifact_info(it["kind"], it["id"])
        rows.append({**it, "target_version": cur["Version"] if cur else None, "action": "update" if cur else "create"})
        if it["kind"] == "iflow":
            try:
                c, e, v = scan_content(src.export("iflow", it["id"]))
                creds |= c; eps |= e; vms |= v
            except CPIError as ex:
                issues.append({"level": "warn", "text": "Could not inspect %s: %s" % (it["id"], ex.message)})
    if not exists_pkg:
        issues.append({"level": "info", "text": "Package will be created in the target"})
    known = tgt.credential_aliases()
    cred_rows = []
    for c in sorted(creds):
        ok = None if known is None else (c in known)
        cred_rows.append({"alias": c, "in_target": ok})
        if ok is False:
            issues.append({"level": "warn", "text": "Credential alias %s is not deployed in the target. Credentials are never transported, create it before runtime use" % c})
    if known is None and creds:
        issues.append({"level": "info", "text": "Credential aliases could not be verified automatically, check %s manually" % ", ".join(sorted(creds))})
    in_pack = {r["id"] for r in rows if r["kind"] == "vm"}
    for v in sorted(vms):
        if v not in in_pack and not tgt.artifact_info("vm", v):
            issues.append({"level": "warn", "text": "Value mapping %s is referenced but not in the selection or target" % v})
    try:
        for c in tgt.cert_expiry():
            if c["days"] < config.MIN_CERT_DAYS:
                issues.append({"level": "warn", "text": "Target certificate %s expires in %d days" % (c["alias"], c["days"])})
    except Exception:
        pass
    for r in rows:
        if r["action"] == "create" and r["kind"] == "iflow" and any(i["level"] == "warn" for i in issues):
            break
    updates = sum(1 for r in rows if r["action"] == "update")
    score = (3 if tgt_stage == "PROD" else 2 if tgt_stage in ("PREPROD", "UAT") else 1) + (1 if updates > 3 else 0) + sum(1 for i in issues if i["level"] == "warn")
    risk = "High" if score >= 5 else "Medium" if score >= 3 else "Low"
    blocking = any(i["level"] == "error" for i in issues)
    return {"package": {"id": pkg_id, "name": pinfo["Name"], "version": pinfo["Version"], "exists_in_target": exists_pkg},
            "artifacts": rows, "dependencies": {"credentials": cred_rows, "endpoints": sorted(eps), "valuemappings": sorted(vms)},
            "issues": issues, "risk": risk, "ready": not blocking, "counts": {"create": len(rows) - updates, "update": updates}}


def run_move(ctx, user, p):
    src, tgt = client_for(p["source"]), client_for(p["target"])
    src_name, tgt_name, pid = p["source"], p["target"], p["package_id"]
    deploy = p.get("deploy", True)
    ctx.steps([("Connect to tenants", "%s and %s" % (src_name, tgt_name)),
               ("Analyze package and dependencies", "Credentials, value mappings, certificates, endpoints"),
               ("Governance and approval", "Policy, four-eyes, change window"),
               ("Snapshot target for rollback", "Export current target versions"),
               ("Prepare target package", "Create package if missing"),
               ("Import artifacts", ""), ("Deploy", ""), ("Verify runtime", "Wait for STARTED and validate")])
    lock = jobs.tenant_lock(tgt_name)
    if not lock.acquire(blocking=False):
        ctx.start(0); ctx.fail(0, "Another operation is running on %s" % tgt_name); ctx.status("failed")
        ctx.result(error="Target tenant busy"); return
    try:
        ctx.start(0)
        a, b = src.ping(), tgt.ping()
        ctx.ok(0, "%s %d ms, %s %d ms" % (src_name, a["latency_ms"], tgt_name, b["latency_ms"]))
        ctx.start(1)
        plan = analyze_move(src, tgt, pid, p.get("artifacts"), p.get("include_deps", True), p.get("target_stage", "DEV"))
        ctx.result(plan=plan)
        if not plan["ready"]:
            ctx.fail(1, "; ".join(i["text"] for i in plan["issues"] if i["level"] == "error")); ctx.status("failed"); return
        warns = [i for i in plan["issues"] if i["level"] == "warn"]
        (ctx.warn if warns else ctx.ok)(1, "%d artifacts, risk %s, %d warnings" % (len(plan["artifacts"]), plan["risk"], len(warns)))
        ctx.ok(2, "Approved by %s" % p["approver"] if p.get("approver") else "Authorized for %s" % tgt_name)
        ctx.start(3)
        snap = {}
        for r in plan["artifacts"]:
            if r["action"] == "update":
                snap[(r["kind"], r["id"])] = (tgt.export(r["kind"], r["id"]), tgt.artifact_info(r["kind"], r["id"])["Name"])
        ctx.ok(3, "%d artifacts snapshotted" % len(snap) if snap else "Nothing to snapshot, all artifacts are new")
        ctx.start(4)
        pinfo = src.package_info(pid)
        if not plan["package"]["exists_in_target"]:
            tgt.create_package(pinfo); ctx.ok(4, "Package %s created" % pid)
        else:
            ctx.ok(4, "Package exists")
        ctx.start(5)
        done, order = [], sorted(plan["artifacts"], key=lambda r: 0 if r["kind"] != "iflow" else 1)
        try:
            for n, r in enumerate(order, 1):
                ctx.start(5, "%d/%d  %s %s" % (n, len(order), KIND_LABEL[r["kind"]], r["id"]))
                tgt.import_artifact(r["kind"], r["id"], r["name"], pid, src.export(r["kind"], r["id"]))
                done.append(r)
            ctx.ok(5, "%d artifacts imported" % len(done))
        except Exception as e:
            ctx.fail(5, "%s on %s" % (e, r["id"]))
            return _rollback(ctx, tgt, snap, done, pid, [], str(e))
        if not deploy:
            ctx.skip(6, "Deployment skipped by option"); ctx.skip(7, "Not deployed")
            ctx.result(moved=[r["id"] for r in done], deployed=False); return
        ctx.start(6)
        deployed = []
        try:
            for r in order:
                try:
                    tgt.deploy(r["kind"], r["id"])
                except CPIError as e:
                    if r["kind"] == "iflow":
                        raise
                    ctx.log("Deploy of %s %s not accepted (%s)" % (r["kind"], r["id"], e.message))
                deployed.append(r)
            ctx.ok(6, "%d deployments started" % len(deployed))
        except Exception as e:
            ctx.fail(6, str(e)); return _rollback(ctx, tgt, snap, done, pid, deployed, str(e))
        ctx.start(7)
        if p.get("simulate_failure") and getattr(tgt, "demo", False):
            tgt.fail_ids.add([r for r in order if r["kind"] == "iflow"][-1]["id"])
        timeout = 25 if getattr(tgt, "demo", False) else config.VERIFY_TIMEOUT
        flows = [r for r in order if r["kind"] == "iflow"]
        t0, bad, pending = time.time(), None, {r["id"] for r in flows}
        while pending and time.time() - t0 < timeout and not bad:
            for aid in list(pending):
                st = tgt.runtime_status(aid)
                if st["Status"] == "STARTED":
                    pending.discard(aid)
                elif st["Status"] in ("ERROR", "STOPPED"):
                    bad = (aid, st.get("Error") or st["Status"]); break
            ctx.start(7, "%d/%d iFlows STARTED" % (len(flows) - len(pending), len(flows)))
            time.sleep(1)
        if bad or pending:
            msg = ("%s: %s" % bad) if bad else "Timeout waiting for %s" % ", ".join(sorted(pending))
            ctx.fail(7, msg)
            return _rollback(ctx, tgt, snap, done, pid, deployed, msg)
        ctx.ok(7, "All %d iFlows STARTED, health check passed" % len(flows))
        ctx.result(moved=[r["id"] for r in done], deployed=True, outcome="success")
    finally:
        lock.release()


def _rollback(ctx, tgt, snap, done, pid, deployed, reason):
    i = ctx.add("Automatic rollback", "Reason: " + reason[:140], "running")
    ok = True
    restored, removed = 0, 0
    for r in reversed(done):
        key = (r["kind"], r["id"])
        try:
            if key in snap:
                content, name = snap[key]
                tgt.import_artifact(r["kind"], r["id"], name, pid, content)
                if getattr(tgt, "fail_ids", None) is not None:
                    tgt.fail_ids.discard(r["id"])
                tgt.deploy(r["kind"], r["id"]); restored += 1
            else:
                if getattr(tgt, "fail_ids", None) is not None:
                    tgt.fail_ids.discard(r["id"])
                try:
                    tgt.undeploy(r["id"])
                except Exception:
                    pass
                removed += 1
        except Exception as e:
            ok = False; ctx.log("Rollback of %s failed: %s" % (r["id"], e))
    time.sleep(1.8)
    j = ctx.add("Verify rollback", "", "running")
    healthy = True
    for k, (c, n) in snap.items():
        if k[0] == "iflow":
            healthy = healthy and tgt.runtime_status(k[1])["Status"] in ("STARTED", "STARTING")
    if ok and healthy:
        ctx.warn(i, "%d restored to previous version, %d new artifacts withdrawn" % (restored, removed))
        ctx.ok(j, "Target is running the previous versions")
        ctx.status("rolled_back"); ctx.result(outcome="rolled_back", reason=reason)
    else:
        ctx.fail(i, "Rollback incomplete, manual intervention required"); ctx.fail(j, "See log")
        ctx.status("failed"); ctx.result(outcome="rollback_failed", reason=reason)


def run_retry(ctx, user, p):
    c = client_for(p["tenant"])
    q, ids, mode, target_q = p["queue"], p.get("ids") or [], p.get("mode", "retry"), p.get("target_queue")
    label = "Retry" if mode == "retry" else "Move to " + str(target_q)
    ctx.steps([("Connect", p["tenant"]), ("Select messages", q), (label + " messages", ""), ("Verify queue", "Compare queue before and after")])
    lock = jobs.tenant_lock(p["tenant"])
    if not lock.acquire(blocking=False):
        ctx.start(0); ctx.fail(0, "Another operation is running on this tenant"); ctx.status("failed"); return
    try:
        ctx.start(0); ctx.ok(0, "%d ms" % c.ping()["latency_ms"])
        ctx.start(1)
        msgs = c.queue_messages(q, 200)
        failed = [m for m in msgs if (m.get("Status") or "").upper() in ("FAILED", "ERROR", "RETRY", "BLOCKED")]
        sel = [m["JmsMessageId"] for m in msgs if m["JmsMessageId"] in ids] if ids else [m["JmsMessageId"] for m in failed]
        sel = sel[:100]
        ctx.ok(1, "%d messages selected (max 100 per run)" % len(sel))
        if not sel:
            ctx.skip(2, "Nothing to do"); ctx.skip(3); ctx.result(processed=0); return
        ctx.start(2)
        n = c.retry_messages(q, sel) if mode == "retry" else c.move_messages(q, target_q, sel)
        ctx.ok(2, "%d of %d messages %s" % (n, len(sel), "retried successfully" if mode == "retry" else "moved"))
        ctx.start(3)
        time.sleep(0.8)
        rest = len(c.queue_messages(q, 200))
        ctx.ok(3, "Queue %s now holds %d messages (was %d)" % (q, rest, len(msgs)))
        ctx.result(processed=n, selected=len(sel), remaining=rest)
    finally:
        lock.release()
