
'use strict';
const STAGES=['DEV','QA','UAT','PREPROD','PROD'];
const $=(s,r)=>(r||document).querySelector(s), $$=(s,r)=>[...(r||document).querySelectorAll(s)];
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const fmt=n=>n==null?'-':Number(n).toLocaleString();
const S={alerts:[],tr:null,build:null,auth:JSON.parse(sessionStorage.getItem('auth')||'null'),me:null,tenants:[],ov:{},jobs:[],view:'dash',selJob:null,pkTenant:null,pkData:{},failTenant:null,failTab:'patterns',failData:null,qSel:null,qData:null,chatInit:false};
let pollT=null,renderT=null;

function toast(t,k){const d=document.createElement('div');d.className='toast '+(k||'');d.textContent=t;$('#toasts').appendChild(d);setTimeout(()=>d.remove(),5000)}
function authHeaders(){const h={};if(S.auth){if(S.auth.type==='session')h['Authorization']='Bearer '+S.auth.value;else if(S.auth.type==='sandbox')h['X-Demo-Session']=S.auth.value}return h}
async function api(path,body,method){
  const h={'Content-Type':'application/json',...authHeaders()};
  const r=await fetch(path,{method:method||(body?'POST':'GET'),headers:h,body:body?JSON.stringify(body):undefined});
  const nt=r.headers.get('X-Session-Token');if(nt&&S.auth&&S.auth.type==='session'){S.auth.value=nt;sessionStorage.setItem('auth',JSON.stringify(S.auth))}
  let j=null;try{j=await r.json()}catch(e){}
  if(!r.ok){let m=j&&(j.detail||j.reply)||('HTTP '+r.status);if(typeof m!=='string')m=JSON.stringify(m);const e=new Error(m);e.status=r.status;if(r.status===401&&S.auth)showGate(m);throw e}
  return j}
function ago(ts){if(!ts)return '-';const s=Math.max(0,Date.now()/1000-ts);if(s<60)return Math.round(s)+'s ago';if(s<3600)return Math.round(s/60)+'m ago';return Math.round(s/3600)+'h ago'}
function stageIdx(s){return STAGES.indexOf(s)}
function T(name){return S.tenants.find(t=>t.name===name)}
function health(o){return o&&o.connected?(o.health==null?null:o.health):null}
const hcol=h=>h==null?'#8e97b3':h>90?'#22c55e':h>75?'#f59e0b':'#ff4d5e';
function ring(p,col){const C=163.4;return `<div class="ring"><svg width="64" height="64"><circle class="bg" cx="32" cy="32" r="26"/><circle class="fg" cx="32" cy="32" r="26" stroke="${col}" stroke-dasharray="${C}" stroke-dashoffset="${C}" data-off="${C*(1-p/100)}"/></svg><span>${Math.round(p)}%</span></div>`}
function spark(a,c){if(!a||a.length<2)return '';const w=170,h=38,mx=Math.max(...a),mn=Math.min(...a),dx=w/(a.length-1);const p=a.map((v,i)=>(i*dx).toFixed(1)+','+(h-3-(v-mn)/(mx-mn||1)*(h-8)).toFixed(1));return `<svg width="100%" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none"><path d="M0,${h} L${p.join(' L')} L${w},${h}Z" fill="${c||'#93a1ff'}" opacity=".16"/><path d="M${p.join(' L')}" fill="none" stroke="${c||'#93a1ff'}" stroke-width="2"/></svg>`}
function countUp(el){const to=parseFloat(el.dataset.count)||0,dec=+el.dataset.dec||0,t0=performance.now();const f=t=>{const k=Math.min(1,(t-t0)/1000),e=1-Math.pow(1-k,3);el.textContent=(to*e).toLocaleString(undefined,{minimumFractionDigits:dec,maximumFractionDigits:dec});if(k<1)requestAnimationFrame(f)};requestAnimationFrame(f)}
function animateAll(root){$$('[data-count]',root).forEach(countUp);$$('.ring .fg',root).forEach(c=>setTimeout(()=>c.style.strokeDashoffset=c.dataset.off,60));$$('.bar i',root).forEach(b=>setTimeout(()=>b.style.width=b.dataset.w,80))}
const catCol={Security:'#ff4d5e',Connectivity:'#f59e0b',Data:'#93a1ff','SAP Backend':'#6764f6',External:'#22c55e',Platform:'#ff957e',Unknown:'#8e97b3'};

/* ---------- background ---------- */
(function(){const c=$('#bg'),x=c.getContext('2d');let w,h,P=[];function rs(){w=c.width=innerWidth;h=c.height=innerHeight;P=Array.from({length:Math.round(w*h/26000)},()=>({x:Math.random()*w,y:Math.random()*h,vx:(Math.random()-.5)*.25,vy:(Math.random()-.5)*.25}))}
rs();addEventListener('resize',rs);function f(){x.clearRect(0,0,w,h);const dark=document.body.dataset.theme==='dark';x.fillStyle=dark?'rgba(147,161,255,.7)':'rgba(103,100,246,.5)';P.forEach(p=>{p.x+=p.vx;p.y+=p.vy;if(p.x<0||p.x>w)p.vx*=-1;if(p.y<0||p.y>h)p.vy*=-1;x.beginPath();x.arc(p.x,p.y,1.6,0,7);x.fill()});
for(let i=0;i<P.length;i++)for(let j=i+1;j<P.length;j++){const dx=P[i].x-P[j].x,dy=P[i].y-P[j].y,d=dx*dx+dy*dy;if(d<14000){x.strokeStyle='rgba(147,161,255,'+(.16*(1-d/14000))+')';x.beginPath();x.moveTo(P[i].x,P[i].y);x.lineTo(P[j].x,P[j].y);x.stroke()}}
if(!document.hidden)requestAnimationFrame(f);else setTimeout(f,1000)}f()})();

/* ---------- gate / auth ---------- */
function showGate(msg){$('#fab').style.display='none';$('#app').style.display='none';$('#gate').style.display='grid';$('#gateErr').textContent=msg||''}
function hideGate(){$('#fab').style.display='block';$('#gate').style.display='none';$('#app').style.display='grid'}
async function enter(auth){S.auth=auth;try{S.me=await api('/api/me');sessionStorage.setItem('auth',JSON.stringify(auth));hideGate();await start()}catch(e){S.auth=null;sessionStorage.removeItem('auth');showGate(e.status===401?'Sign-in failed or the session expired.':e.message)}}
$('#themeBtn').onclick=()=>{document.body.dataset.theme=document.body.dataset.theme==='dark'?'light':'dark'};

/* ---------- navigation ---------- */
function go(v){if(v==='chat'){openPanel();return}clearInterval(S.autoT);S.view=v;$$('#nav a').forEach(a=>a.classList.toggle('on',a.dataset.v===v));$$('.view').forEach(x=>x.classList.toggle('on',x.id==='v-'+v));updCtx();render(v)}
$$('#nav a').forEach(a=>a.onclick=()=>go(a.dataset.v));
function render(v){v=v||S.view;({dash:rDash,mon:rMon,trans:rTrans,drift:rDrift,build:rBuild,tenants:rTenants,packages:rPackages,ops:rOps,fail:rFail,approvals:rApprovals,agent:rAgent,audit:rAudit,about:rAbout})[v]()}
function softRender(){clearTimeout(renderT);renderT=setTimeout(()=>{if(['dash','tenants'].includes(S.view))render();else if(S.view==='mon'&&!S.monBusy)rMon(true)},150)}

async function start(){
  $('#modeTxt').textContent=S.me.sandbox?'Sandbox (simulated tenants)':'Signed in: '+S.me.user+(S.me.profile==='strict'?' | strict':'');$('.dot',$('#modePill')).classList.toggle('w',!!S.me.sandbox);
  $('#who').innerHTML='<b>'+esc(S.me.user)+'</b><br>v'+esc(S.me.version)+'<div class="credit">Design and developed by<br><b>'+esc(S.me.author)+'</b></div>';
  $('#roBanner').style.display=S.me.read_only?'block':'none';
  initPanel();
  try{S.tools=(await api('/api/agent/tools')).tools;TOOLN=S.tools.length}catch(e){S.tools=[]}
  await loadTenants();go('dash');startPoll()}
async function loadTenants(refresh){
  const r=await api('/api/tenants');S.tenants=r.tenants;S.ov=refresh?{}:S.ov;
  S.tenants.forEach(t=>{api('/api/overview/'+encodeURIComponent(t.name)+(refresh?'?refresh=1':'')).then(o=>{S.ov[t.name]=o;softRender()}).catch(e=>{S.ov[t.name]={name:t.name,stage:t.stage,connected:false,error:e.message};softRender()})});
  api('/api/alerts').then(x=>{S.alerts=x.alerts;softRender()}).catch(()=>{});
  api('/api/briefing').then(b=>{S.briefing=b;softRender()}).catch(()=>{});
  api('/api/approvals').then(a=>{S.approvals=a;badge(a)}).catch(()=>{});
  if(!S.pkTenant||!T(S.pkTenant))S.pkTenant=S.tenants[0]&&S.tenants[0].name;
  if(!S.monTenant||!T(S.monTenant))S.monTenant=S.tenants[0]&&S.tenants[0].name;
  if(!S.failTenant||!T(S.failTenant))S.failTenant=S.tenants[0]&&S.tenants[0].name}
function badge(a){const pc=a.approvals.filter(x=>x.status==='PENDING').length,b=$('#apBadge');if(b){b.style.display=pc?'inline-block':'none';b.textContent=pc}}
function startPoll(){clearInterval(pollT);let n=0;pollT=setInterval(async()=>{if(!S.auth)return;n++;try{const r=await api('/api/jobs');const prev=JSON.stringify(S.jobs.map(j=>j.id+j.status));S.jobs=r.jobs;const run=S.jobs.filter(j=>j.status==='running'||j.status==='queued').length;const b=$('#opsBadge');b.style.display=run?'inline-block':'none';b.textContent=run;
  const changed=prev!==JSON.stringify(S.jobs.map(j=>j.id+j.status));if(S.view==='ops')updOps();if(changed&&S.view==='dash')rDash(true);if(changed&&run===0&&prev.includes('running')){loadTenants(true)}
  if(n%4===0){const a=await api('/api/approvals');const sig=JSON.stringify(a.approvals.map(x=>x.id+x.status));if(sig!==S._apsig){S._apsig=sig;S.approvals=a;badge(a);if(S.view==='approvals')rApprovals();if(S.view==='dash')rDash(true)}}}catch(e){}},1200)}
/* ---------- dashboard ---------- */
function topology(){
  const by={};S.tenants.forEach(t=>(by[t.stage]=by[t.stage]||[]).push(t));const mx=Math.max(1,...Object.values(by).map(a=>a.length));
  const W=1000,H=Math.max(250,90+mx*100),pos={};
  STAGES.forEach((s,i)=>{(by[s]||[]).forEach((t,k,a)=>{pos[t.name]={x:90+i*((W-180)/4),y:H/2+(k-(a.length-1)/2)*100,t}})});
  const occ=STAGES.filter(s=>by[s]);let links='',defs='';
  for(let i=0;i<occ.length-1;i++)by[occ[i]].forEach(a=>by[occ[i+1]].forEach(b=>{const p=pos[a.name],q=pos[b.name],mxp=(p.x+q.x)/2;links+=`<path class="flow" d="M${p.x+34},${p.y} C${mxp},${p.y} ${mxp},${q.y} ${q.x-34},${q.y}"/>`}));
  let pk='';S.jobs.filter(j=>j.status==='running'&&j.meta&&pos[j.meta.source]&&pos[j.meta.target]).forEach((j,i)=>{const p=pos[j.meta.source],q=pos[j.meta.target],mxp=(p.x+q.x)/2,d=`M${p.x},${p.y} C${mxp},${p.y} ${mxp},${q.y} ${q.x},${q.y}`;pk+=`<path id="jp${i}" d="${d}" fill="none"/><circle r="8" fill="#ff000f"><animateMotion dur="2.4s" repeatCount="indefinite"><mpath href="#jp${i}"/></animateMotion></circle><circle r="14" fill="#ff000f" opacity=".25"><animateMotion dur="2.4s" repeatCount="indefinite"><mpath href="#jp${i}"/></animateMotion></circle>`});
  const cols=STAGES.map((s,i)=>`<text x="${90+i*((W-180)/4)}" y="22" text-anchor="middle" class="t2" style="letter-spacing:2px;font-weight:700">${s}</text>`).join('');
  const nodes=Object.values(pos).map(({x,y,t})=>{const o=S.ov[t.name],h=health(o),c=o?(o.connected?hcol(h):'#8e97b3'):'#6764f6',fl=o&&o.failed_24h;
    return `<g class="node" data-t="${esc(t.name)}"><circle cx="${x}" cy="${y}" r="42" fill="${c}" opacity=".12"><animate attributeName="r" values="38;46;38" dur="3s" repeatCount="indefinite"/></circle><circle class="c" cx="${x}" cy="${y}" r="32" fill="var(--bg2)" stroke="${c}" stroke-width="3"/><text x="${x}" y="${y+5}" text-anchor="middle" font-weight="700" font-size="13">${o&&o.connected?(h==null?'\u2013':Math.round(h)+'%'):'...'}</text><text x="${x}" y="${y+54}" text-anchor="middle" font-size="12" font-weight="600">${esc(t.name)}</text>${fl?`<g><circle cx="${x+26}" cy="${y-24}" r="11" fill="#ff000f"/><text x="${x+26}" y="${y-20}" text-anchor="middle" font-size="10" font-weight="700" style="fill:#fff">${fl>99?'99+':fl}</text></g>`:''}</g>`}).join('');
  return `<svg class="topo" viewBox="0 0 ${W} ${H}">${cols}${links}${nodes}${pk}</svg>`}
function rDash(soft){
  const el=$('#v-dash');
  if(!S.tenants.length){el.innerHTML=`<div class="empty card"><div class="orb"></div><h2>Connect your first tenant</h2><p>Bind a Process Integration Runtime instance to this app and the tenant appears here automatically, or load a simulated landscape to explore every feature.</p><div class="chips" style="justify-content:center"><button class="btn" data-a="go" data-p="tenants">How to connect</button><button class="btn ghost" data-a="loadDemo">Load demo tenants</button></div></div>`;return}
  const L=S.tenants.map(t=>S.ov[t.name]||{name:t.name,stage:t.stage,loading:true}),C=L.filter(o=>o.connected);
  const known=C.filter(o=>o.messages_24h!=null),tot=known.reduce((a,o)=>a+o.messages_24h,0),fl=known.reduce((a,o)=>a+(o.failed_24h||0),0),ok=tot?(tot-fl)/tot*100:null;
  const unread=C.filter(o=>o.messages_24h==null).length;
  const arts=C.reduce((a,o)=>a+(o.artifacts||[]).length,0),bad=C.reduce((a,o)=>a+(o.artifacts||[]).filter(x=>x.Status!=='STARTED').length,0);
  const certs=C.flatMap(o=>(o.certs||[]).map(c=>({...c,t:o.name}))),exp=certs.filter(c=>c.days<30).length;
  const pats=C.flatMap(o=>(o.patterns||[]).map(p=>({...p,t:o.name}))),hi=pats.filter(p=>p.severity==='P1'||p.severity==='P2').length;
  const run=S.jobs.filter(j=>j.status==='running').length,pend=((S.approvals&&S.approvals.approvals)||[]).filter(x=>x.status==='PENDING').length;
  const K=[['T','Tenants',S.tenants.length,0,'var(--lil)'],['M','Messages (24h)',known.length?tot:null,0,'#4b8bf6'],['!','Failed messages',known.length?fl:null,0,'var(--red)'],['%','Success rate',ok,2,'var(--ok)'],['I','Runtime artifacts',C.length?arts:null,0,'#6764f6'],['X','Not started',C.length?bad:null,0,'var(--warn)'],['C','Certs < 30 days',C.length?exp:null,0,'#ff957e'],['P','High severity patterns',C.length?hi:null,0,'var(--bad)'],['A','Pending approvals',pend,0,'var(--lil2)'],['J','Running operations',run,0,'var(--lil2)']];
  const B=S.briefing;
  el.innerHTML=`<div class="head"><div class="grow"><h2>Landscape overview</h2><div class="sub">${S.me.sandbox?'Simulated tenants for demonstration':'Live data read from your tenants'} - updated ${new Date().toLocaleTimeString()}</div></div><button class="btn ghost sm" data-a="reload">Refresh</button><button class="btn lil sm" data-a="openReport">Executive report</button></div>
  ${B?`<div class="card brief"><div class="chips" style="justify-content:space-between"><h3 style="margin:0">Today's briefing</h3><button class="btn ghost sm" data-a="askCopilot" data-p="Give me the daily briefing">Ask the copilot</button></div><div class="bh">${esc(B.headline)}</div>${(B.items||[]).slice(0,4).map(i=>`<div class="alert ${i.severity}"><i></i><div style="flex:1">${esc(i.text)}<div class="tiny">${esc(i.action||'')}</div></div></div>`).join('')}${B.pending_approvals?`<div class="tiny" style="margin-top:6px">${B.pending_approvals} approval request(s) waiting</div>`:''}</div>`:''}
  <div class="grid kpis" style="margin-top:16px">${K.map((k,i)=>`<div class="card kpi" style="--d:${i*40}ms;--c:${k[4]}"><div class="k-ico">${k[0]}</div>${k[2]==null?'<div class="k-val na">n/a</div>':`<div class="k-val" data-count="${k[2]}" data-dec="${k[3]}">0</div>`}<div class="k-lab">${k[1]}</div></div>`).join('')}</div>
  ${unread?`<div class="banner w" style="margin-top:12px"><b>${unread} tenant${unread>1?'s':''} did not return message statistics.</b> Values shown as n/a are unknown, not zero. <button class="btn ghost sm" data-a="go" data-p="tenants">Run diagnostics</button></div>`:''}
  ${mission(C,run)}
  <div class="card" style="margin-top:16px"><h3>Transport topology</h3>${topology()}<div class="tiny">Dashed lines show the promotion path. A glowing packet travels along it while an operation runs. Click a tenant to open its packages.</div></div>
  <div class="grid tiles" style="margin-top:16px">${L.map((o,i)=>{if(o.loading)return `<div class="card tcard" style="--d:${i*60}ms"><div class="nm">${esc(o.name)}</div><div class="skel"></div><div class="skel" style="width:60%"></div></div>`;
    if(!o.connected)return `<div class="card tcard" style="--d:${i*60}ms"><div class="top"><span class="nm">${esc(o.name)}</span><span class="chip b">Unreachable</span></div><div class="em" style="color:var(--bad)">${esc(o.error||'')}</div><div class="chips" style="margin-top:10px"><button class="btn ghost sm" data-a="diag" data-p="${esc(o.name)}">Diagnose</button></div></div>`;
    const h=health(o),unr=Object.entries(o.quality||{}).filter(([k,v])=>!v.ok).map(([k])=>k);
    return `<div class="card tcard hov" style="--d:${i*60}ms;cursor:pointer" data-a="pkTo" data-p="${esc(o.name)}"><div class="top"><span class="nm">${esc(o.name)}</span><span><span class="chip l">${o.stage}</span> <span class="chip ${h==null?'':h>90?'ok':h>75?'w':'b'}">${esc(o.health_label||'')}</span></span></div><div class="tbody">${h==null?`<div class="ring na"><span>\u2013</span></div>`:ring(h,hcol(h))}<div class="em">Messages <b>${o.messages_24h==null?'n/a':fmt(o.messages_24h)}</b><br>Failed <b style="color:var(--bad)">${o.failed_24h==null?'n/a':fmt(o.failed_24h)}</b><br>Artifacts <b>${o.quality&&o.quality.artifacts&&!o.quality.artifacts.ok?'n/a':(o.artifacts||[]).length}</b><br>Latency <b>${o.latency_ms} ms</b></div></div>${unr.length?`<div class="tiny" style="color:var(--warn);margin-top:6px">Not readable: ${unr.join(', ')}</div>`:`<div style="height:38px;margin-top:6px">${spark(o.series)}</div>`}</div>`}).join('')}</div>
  <div class="card" style="margin-top:16px"><h3>Active alerts <span class="chip ${S.alerts.some(a=>a.severity==='critical')?'b':'w'}">${S.alerts.length}</span></h3>${alertsHtml(S.alerts.slice(0,6))}</div>
  <div class="grid two"><div class="card"><h3>Failure categories</h3>${donut(pats)}</div><div class="card"><h3>Certificate expiry</h3>${certsHtml(certs)}</div></div>
  <div class="grid two"><div class="card"><h3>Top failing interfaces</h3>${topFail(pats)}</div><div class="card"><h3>Recent operations</h3><div class="feed">${feed()}</div></div></div>`;
  $$('.node',el).forEach(n=>n.onclick=()=>{S.pkTenant=n.dataset.t;go('packages')});animateAll(el)}
function donut(pats){const cat={};pats.forEach(p=>cat[p.domain]=(cat[p.domain]||0)+p.count);const tt=Object.values(cat).reduce((a,b)=>a+b,0);if(!tt)return '<div class="sub">No failures detected.</div>';let off=0;const R=54,CF=2*Math.PI*R;
  const seg=Object.entries(cat).map(([k,v])=>{const l=v/tt*CF,s=`<circle r="${R}" cx="70" cy="70" fill="none" stroke="${catCol[k]||'#888'}" stroke-width="20" stroke-dasharray="${l} ${CF-l}" stroke-dashoffset="${-off}"/>`;off+=l;return s}).join('');
  return `<div class="donutw"><svg width="150" height="150" viewBox="0 0 140 140" style="transform:rotate(-90deg)">${seg}</svg><div class="leg">${Object.entries(cat).map(([k,v])=>`<div><i style="background:${catCol[k]||'#888'}"></i>${esc(k)} <b style="color:var(--tx)">${v}</b></div>`).join('')}</div></div>`}
function certsHtml(c){c=c.sort((a,b)=>a.days-b.days).slice(0,7);if(!c.length)return '<div class="sub">No certificate data.</div>';return c.map(x=>{const col=x.days<15?'var(--bad)':x.days<30?'var(--warn)':'var(--ok)';return `<div class="row"><span style="width:110px;color:var(--mut);overflow:hidden;text-overflow:ellipsis">${esc(x.t)}</span><span style="width:120px">${esc(x.alias)}</span><div class="bar"><i data-w="${Math.max(3,Math.min(100,x.days/3))}%" style="background:${col}"></i></div><b style="width:56px;text-align:right;color:${col}">${x.days} d</b></div>`}).join('')}
function topFail(p){const m={};p.forEach(x=>{const k=x.t+' / '+x.iflow;m[k]=(m[k]||0)+x.count});const a=Object.entries(m).sort((x,y)=>y[1]-x[1]).slice(0,7),mx=a.length?a[0][1]:1;if(!a.length)return '<div class="sub">Nothing failing.</div>';return a.map(([k,v])=>`<div class="row"><span style="flex:1.4">${esc(k)}</span><div class="bar"><i data-w="${v/mx*100}%" style="background:linear-gradient(90deg,var(--lil),var(--red))"></i></div><b style="width:36px;text-align:right">${v}</b></div>`).join('')}
function feed(){if(!S.jobs.length)return '<div class="sub">No operations yet. Move a package or retry failed messages to see activity here.</div>';return S.jobs.slice(0,8).map(j=>`<div class="ev"><i style="background:${jcol(j.status)}"></i><div><b style="cursor:pointer" data-a="openJob" data-p="${j.id}">${esc(j.title)}</b><div class="tiny">${statusLabel(j.status)} - ${ago(j.created)} - ${esc(j.user)}</div></div></div>`).join('')}
const jcol=s=>({success:'var(--ok)',failed:'var(--bad)',rolled_back:'var(--warn)',running:'var(--lil2)',queued:'var(--lil2)'}[s]||'var(--mut)');
const statusLabel=s=>({success:'Succeeded',failed:'Failed',rolled_back:'Rolled back',running:'Running',queued:'Queued'}[s]||s);
const jchip=s=>({success:'ok',failed:'b',rolled_back:'w',running:'run',queued:'run'}[s]||'');

/* ---------- modal helpers ---------- */
function openModal(html){$('#mbox').innerHTML=html;$('#modal').classList.add('on')}
function closeModal(){$('#modal').classList.remove('on')}
$('#modal').onclick=e=>{if(e.target.id==='modal')closeModal()};
function confirmAction(o){
  openModal(`<h3>${esc(o.title)}</h3><div class="sub">${esc(o.text||'')}</div>${o.needsApproval?`<div class="banner w" style="margin:10px 0">A different person with the Approve permission must approve this before it runs. A request is created and tracked on the Approvals page.</div>`:''}<div class="err" id="cfErr"></div><div class="acts"><button class="btn ghost" data-a="closeModal">Cancel</button><button class="btn" id="cfGo">${esc(o.needsApproval?'Request approval':(o.go||'Run'))}</button></div>`);
  $('#cfGo').onclick=async()=>{$('#cfGo').disabled=true;try{await o.onGo()}catch(e){$('#cfErr').textContent=e.message;$('#cfGo').disabled=false}}}
async function startJob(kind,params){const r=await api('/api/jobs',{kind,params});if(r.status==='PENDING_APPROVAL'){closeModal();toast('Approval requested. A different person must approve it.','ok');go('approvals');return r}S.selJob=r.job;closeModal();toast('Operation started','ok');go('ops');return r}
/* ---------- tenants ---------- */
function guessStage(n){const u=n.toUpperCase().replace(/[^A-Z0-9]/g,'');for(const s of ['PREPROD','PROD','UAT','QA','DEV'])if(u.includes(s))return s;return 'DEV'}
function tenantModal(){
  openModal(`<h3>Add SAP Integration Suite tenant</h3><div class="sub">Use the service key of a Process Integration Runtime instance (plan api).</div>
  <label>Paste the service key JSON (optional, fills the form)</label><textarea id="tk" rows="3" placeholder='{"oauth":{"clientid":"...","clientsecret":"...","tokenurl":"...","url":"..."}}'></textarea>
  <div class="f2"><div><label>Tenant name</label><input id="tn" placeholder="ACME-DEV"></div><div><label>Stage</label><select id="ts">${STAGES.map(s=>`<option>${s}</option>`).join('')}</select></div></div>
  <label>Tenant URL (runtime)</label><input id="tu" placeholder="https://xxxx.it-cpi034.cfapps.ap21.hana.ondemand.com">
  <label>Token URL</label><input id="tt" placeholder="https://xxxx.authentication.ap21.hana.ondemand.com/oauth/token">
  <div class="f2"><div><label>Client ID</label><input id="tc"></div><div><label>Client secret</label><input id="tx" type="password" autocomplete="off"></div></div>
  <div class="tog"><input type="checkbox" id="tTest" checked><span>Test the connection before saving</span></div>
  <div class="tiny">The secret is kept in server memory only and never sent back to the browser. For permanent registration use the cf user-provided service (see README).</div>
  <div class="err" id="terr"></div><div class="acts"><button class="btn ghost" data-a="closeModal">Cancel</button><button class="btn" id="tGo">Save tenant</button></div>`);
  $('#tk').oninput=()=>{try{const j=JSON.parse($('#tk').value),o=j.oauth||j;$('#tu').value=o.url||j.url||'';$('#tt').value=o.tokenurl||(o.uaa&&o.uaa.url?o.uaa.url+'/oauth/token':'')||'';$('#tc').value=o.clientid||'';$('#tx').value=o.clientsecret||'';$('#terr').textContent=''}catch(e){}};
  $('#tn').oninput=()=>{$('#ts').value=guessStage($('#tn').value)};
  $('#tGo').onclick=async()=>{$('#terr').textContent='';$('#tGo').disabled=true;$('#tGo').textContent='Testing...';try{const r=await api('/api/tenants',{name:$('#tn').value,stage:$('#ts').value,url:$('#tu').value,tokenurl:$('#tt').value,clientid:$('#tc').value,clientsecret:$('#tx').value,test:$('#tTest').checked});closeModal();toast('Tenant '+r.name+' connected'+(r.test?' ('+r.test.latency_ms+' ms)':''),'ok');await loadTenants(true);render()}catch(e){$('#terr').textContent=e.message;$('#tGo').disabled=false;$('#tGo').textContent='Save tenant'}}}
async function loadDemo(){try{await api('/api/demo/load',{});toast('Demo landscape loaded','ok');await loadTenants(true);render()}catch(e){toast(e.message,'bad')}}
async function clearDemo(){await api('/api/demo/clear',{});await loadTenants(true);render()}
async function testT(n){try{const r=await api('/api/tenants/'+encodeURIComponent(n)+'/test',{});toast(r.ok?n+' reachable, '+r.latency_ms+' ms':n+': '+r.error,r.ok?'ok':'bad')}catch(e){toast(e.message,'bad')}}
async function rmT(n){confirmAction({title:'Remove tenant '+n+'?',text:'It disappears from the dashboard, transports and the copilot. The tenant itself is not changed.',go:'Remove',onGo:async()=>{await api('/api/tenants/'+encodeURIComponent(n),null,'DELETE');closeModal();await loadTenants(true);render()}})}

/* ---------- packages ---------- */
const KL={iflow:'iFlow',vm:'Value mapping',script:'Script collection'},KI={iflow:'\u21C4',vm:'\u2630',script:'{ }'};
async function rPackages(force){
  const el=$('#v-packages');
  if(!S.tenants.length){el.innerHTML=`<div class="empty card"><div class="orb"></div><h2>No tenants yet</h2><p>Add a tenant to browse its packages.</p><button class="btn" data-a="tenantModal">Add tenant</button></div>`;return}
  const t=S.pkTenant;
  el.innerHTML=`<div class="head"><div class="grow"><h2>Packages and artifacts</h2><div class="sub">Pick a tenant, then move a whole package or a single iFlow to another tenant.</div></div><input id="pkq" placeholder="Filter packages..." style="width:220px"><button class="btn ghost sm" id="pkr">Reload</button></div>
  <div class="seg" style="margin-bottom:16px">${S.tenants.map(x=>`<button class="${x.name===t?'on':''}" data-t="${esc(x.name)}">${esc(x.name)} <small>${x.stage}</small></button>`).join('')}</div><div id="pkBody"><div class="grid tiles">${[1,2,3].map(()=>'<div class="card"><div class="skel"></div><div class="skel" style="width:70%"></div><div class="skel" style="width:40%"></div></div>').join('')}</div></div>`;
  $$('.seg button',el).forEach(b=>b.onclick=()=>{S.pkTenant=b.dataset.t;rPackages()});$('#pkr').onclick=()=>{delete S.pkData[t];rPackages()};
  if(!S.pkData[t]){try{S.pkData[t]=(await api('/api/tenants/'+encodeURIComponent(t)+'/packages')).packages}catch(e){$('#pkBody').innerHTML=`<div class="card"><span style="color:var(--bad)">${esc(e.message)}</span></div>`;return}}
  const draw=()=>{const q=($('#pkq').value||'').toLowerCase(),list=(S.pkData[t]||[]).filter(p=>!q||(p.Name+p.Id).toLowerCase().includes(q));
    $('#pkBody').innerHTML=list.length?`<div class="grid tiles">${list.map((p,i)=>`<div class="card pk hov" style="--d:${i*50}ms" data-p="${esc(p.Id)}"><div class="nm">${esc(p.Name)}</div><div class="id">${esc(p.Id)} - v${esc(p.Version)}</div><div class="cnt"><span class="chip l">${p.counts.iflows} iFlows</span><span class="chip">${p.counts.valuemaps} value maps</span><span class="chip">${p.counts.scripts} scripts</span></div>
    <div class="chips"><button class="btn sm" data-mv="${esc(p.Id)}">Move package</button><button class="btn ghost sm" data-ex="1">Show artifacts</button></div>
    <div class="arts">${[['iflows','iflow'],['valuemaps','vm'],['scripts','script']].map(([k,kind])=>p.artifacts[k].map(a=>`<div class="art"><span class="k chip">${KL[kind]}</span><span class="grow" title="${esc(a.Id)}">${esc(a.Name)} <span class="tiny">v${esc(a.Version)}</span></span>${kind==='iflow'?`<button class="btn ghost sm" data-ex2="${esc(a.Id)}">Explain</button><button class="btn ghost sm" data-mi="${esc(p.Id)}|${esc(a.Id)}">Move</button>`:''}</div>`).join('')).join('')||'<div class="tiny">Empty package</div>'}</div></div>`).join('')}</div>`:'<div class="card empty">No packages found.</div>';
    $$('.pk',$('#pkBody')).forEach(c=>{c.onclick=e=>{if(e.target.closest('[data-mv],[data-mi],[data-ex2]'))return;c.classList.toggle('open')};});
    $$('[data-mv]',$('#pkBody')).forEach(b=>b.onclick=()=>{const p=S.pkData[t].find(x=>x.Id===b.dataset.mv);moveModal(t,p.Id,p.Name,null)});
    $$('[data-ex2]',$('#pkBody')).forEach(b=>b.onclick=()=>explainModal(t,b.dataset.ex2));
    $$('[data-mi]',$('#pkBody')).forEach(b=>b.onclick=()=>{const[pid,aid]=b.dataset.mi.split('|');const p=S.pkData[t].find(x=>x.Id===pid);moveModal(t,pid,p.Name+' / '+aid,[{kind:'iflow',id:aid}])});
    animateAll($('#pkBody'))};
  $('#pkq').oninput=draw;draw()}

/* ---------- move wizard ---------- */
let M=null;
function blocked(t){const s=T(M.src);if(t.name===M.src)return 'Source tenant';const si=stageIdx(s.stage),ti=stageIdx(t.stage);if(ti<si)return 'Backward promotion is not allowed';const regs=new Set(S.tenants.map(x=>x.stage)),sk=STAGES.slice(si+1,ti).filter(x=>regs.has(x));return sk.length?'Pass through '+sk.join(', ')+' first':''}
function moveModal(src,pid,pname,arts){M={src,pid,pname,arts,target:null,plan:null,needs:false,deploy:true,deps:true,sim:false,busy:false,err:''};drawMove();$('#modal').classList.add('on')}
function planHtml(p){
  if(!p)return '';const ic={error:'\u2715',warn:'!',info:'i'},col={error:'var(--bad)',warn:'var(--warn)',info:'var(--lil2)'};
  return `<div class="chips" style="margin:6px 0 10px"><span class="chip ok">${p.counts?p.counts.create:0} new</span><span class="chip w">${p.counts?p.counts.update:0} updates</span><span class="chip ${p.risk==='High'?'b':p.risk==='Medium'?'w':'ok'}">Risk ${esc(p.risk||'-')}</span></div>
  ${p.artifacts&&p.artifacts.length?`<div class="tw" style="max-height:200px"><table><tr><th>Type</th><th>Artifact</th><th>Source</th><th>Target</th><th></th></tr>${p.artifacts.map(a=>`<tr><td>${KL[a.kind]}</td><td>${esc(a.id)}${a.dependency?' <span class="chip l">dependency</span>':''}</td><td>${esc(a.version)}</td><td>${esc(a.target_version||'-')}</td><td><span class="chip ${a.action==='create'?'ok':'w'}">${a.action}</span></td></tr>`).join('')}</table></div>`:''}
  ${p.dependencies&&p.dependencies.credentials.length?`<div style="margin-top:10px"><div class="tiny">Credential aliases used by the iFlows</div><div class="chips" style="margin-top:5px">${p.dependencies.credentials.map(c=>`<span class="chip ${c.in_target===true?'ok':c.in_target===false?'w':''}">${esc(c.alias)} ${c.in_target===true?'present':c.in_target===false?'missing in target':'unchecked'}</span>`).join('')}</div></div>`:''}
  ${p.dependencies&&p.dependencies.endpoints.length?`<div class="tiny" style="margin-top:8px">External endpoints: ${p.dependencies.endpoints.map(esc).join(', ')}</div>`:''}
  ${(p.issues||[]).map(i=>`<div class="issue"><i style="color:${col[i.level]}">${ic[i.level]}</i><span>${esc(i.text)}</span></div>`).join('')}`}
function drawMove(){
  const s=T(M.src),others=S.tenants.filter(t=>t.name!==M.src);
  openModal(`<h3>Move ${M.arts?'iFlow':'package'}: ${esc(M.pname)}</h3><div class="sub">From <b>${esc(M.src)}</b> (${s.stage}). Choose the target tenant.</div>
  <div class="pick">${others.map(t=>{const b=blocked(t);return `<div class="opt ${b?'dis':''} ${M.target===t.name?'on':''}" data-t="${esc(t.name)}"><b>${esc(t.name)}</b><small>${t.stage}${b?' - '+esc(b):''}</small></div>`}).join('')||'<div class="muted">Add another tenant to move content.</div>'}</div>
  ${M.target?`<div class="tog" style="margin-top:14px"><input type="checkbox" id="oD" ${M.deploy?'checked':''}><span>Deploy after import and verify runtime</span></div><div class="tog"><input type="checkbox" id="oP" ${M.deps?'checked':''}><span>Include missing value mappings and script collections</span></div>${T(M.target).demo?`<div class="tog"><input type="checkbox" id="oS" ${M.sim?'checked':''}><span>Demo: simulate a failed health check to see automatic rollback</span></div>`:''}`:''}
  <div id="planBox">${M.busy?'<div class="skel"></div><div class="skel" style="width:70%"></div>':planHtml(M.plan)}</div>
  ${M.needs?`<div class="banner w" style="margin:10px 0">Four-eyes rule for ${esc(T(M.target).stage)}: a different person with the Approve permission must approve this before it runs.</div>`:''}
  <div class="err" id="mvErr">${esc(M.err)}</div>
  <div class="acts"><button class="btn ghost" data-a="closeModal">Cancel</button><button class="btn lil" id="mvPlan" ${M.target&&!M.busy?'':'disabled'}>Analyze</button><button class="btn" id="mvGo" ${M.plan&&M.plan.ready&&!M.busy?'':'disabled'}>${M.needs?'Request approval':'Start transport'}</button></div>`);
  $$('.opt',$('#mbox')).forEach(o=>o.onclick=()=>{if(o.classList.contains('dis'))return;M.target=o.dataset.t;M.plan=null;M.needs=false;M.err='';drawMove()});
  ['oD','oP','oS'].forEach(id=>{const e=$('#'+id);if(e)e.onchange=()=>{M.deploy=$('#oD').checked;M.deps=$('#oP').checked;M.sim=$('#oS')?$('#oS').checked:false;M.plan=null;drawMove()}});
  const body=()=>({source:M.src,target:M.target,package_id:M.pid,artifacts:M.arts,deploy:M.deploy,include_deps:M.deps,simulate_failure:M.sim});
  $('#mvPlan').onclick=async()=>{M.busy=true;M.err='';drawMove();try{const r=await api('/api/plan',body());M.plan=r.plan;M.needs=r.needs_approval}catch(e){M.err=e.message}M.busy=false;drawMove()};
  $('#mvGo').onclick=async()=>{$('#mvGo').disabled=true;try{await startJob('move',body())}catch(e){M.err=e.message;drawMove()}}}

/* ---------- operations ---------- */
function openJob(id){S.selJob=id;go('ops')}
function jobDetail(j){
  const st=j.steps,done=st.filter(s=>['ok','warn','skip','bad'].includes(s.status)).length,pct=st.length?done/st.length*100:0;
  const cls={success:'ok',failed:'bad',rolled_back:'w'}[j.status]||'';
  const run=j.status==='running'||j.status==='queued',m=j.meta||{},two=m.source&&m.target&&m.source!==m.target;
  const fin=j.status==='success'?'ok':j.status==='failed'?'bad':j.status==='rolled_back'?'w':'';
  const el=(j.finished||Date.now()/1000)-j.created,r=j.result||{};
  let ban='';
  if(j.status==='success')ban=`<div class="banner ok">${j.kind==='move'?'Transport completed and verified. '+((r.moved||[]).length)+' artifacts moved.'+(r.deployed===false?' Deployment was skipped.':''):'Processed '+r.processed+' of '+r.selected+' messages. '+r.remaining+' remain in the queue.'}</div>`;
  if(j.status==='rolled_back')ban=`<div class="banner w">Verification failed and the target was rolled back automatically. Reason: ${esc(r.reason||'')}. An incident record was written to the audit trail.</div>`;
  if(j.status==='failed')ban=`<div class="banner bad">${esc(r.error||r.reason||'The operation failed.')}</div>`;
  const ic={ok:'\u2713',bad:'\u2715',warn:'\u21BA',skip:'-',running:'',pending:''};
  return `<div class="card nf"><div class="chips" style="justify-content:space-between"><h3 style="margin:0">${esc(j.title)}</h3><span class="chip ${jchip(j.status)}">${statusLabel(j.status)}</span></div>
  <div class="tiny">By ${esc(j.user)} - started ${ago(j.created)} - ${Math.round(el)}s - id ${j.id}</div>
  ${two?`<div class="mini"><div class="pkt ${run?'go':''}">\u25B6</div><div class="n s ${fin==='bad'?'':''}"><div class="o">${esc(m.source_stage)}</div><b>${esc(m.source)}</b></div><div class="n t ${fin}"><div class="o">${esc(m.target_stage)}</div><b>${esc(m.target)}</b></div></div>`:''}
  <div class="prog ${cls}"><i style="width:${pct}%"></i></div>
  <div style="margin-top:12px">${st.map((s,i)=>`<div class="step ${s.status}"><div class="ic">${ic[s.status]||i+1}</div><div><b>${esc(s.name)}</b><p>${esc(s.detail)}</p></div></div>`).join('')}</div>${ban}
  ${r.plan?`<details style="margin-top:12px"><summary class="muted" style="cursor:pointer">Plan and dependency analysis</summary>${planHtml(r.plan)}</details>`:''}
  ${(j.log||[]).length?`<details style="margin-top:8px"><summary class="muted" style="cursor:pointer">Log (${j.log.length})</summary><pre class="tiny">${j.log.map(l=>esc(l.m)).join('\n')}</pre></details>`:''}</div>`}
function updOps(){
  const l=$('#jl'),d=$('#jd');if(!l)return;
  if(!S.selJob&&S.jobs.length)S.selJob=S.jobs[0].id;
  const lsig=JSON.stringify(S.jobs.map(j=>[j.id,j.status,j.steps.filter(s=>s.status==='ok').length])+S.selJob);
  if(S._lsig!==lsig){S._lsig=lsig;l.innerHTML=S.jobs.length?S.jobs.map(j=>{const done=j.steps.filter(s=>['ok','warn','skip','bad'].includes(s.status)).length;return `<div class="card job nf hov ${j.id===S.selJob?'on':''}" data-j="${j.id}"><div class="t">${esc(j.title)}</div><div class="chips"><span class="chip ${jchip(j.status)}">${statusLabel(j.status)}</span><span class="tiny">${ago(j.created)}</span></div><div class="prog ${{success:'ok',failed:'bad',rolled_back:'w'}[j.status]||''}"><i style="width:${j.steps.length?done/j.steps.length*100:0}%"></i></div></div>`}).join(''):`<div class="card nf empty">No operations yet.<br>Move a package from the Packages page, or ask the copilot.</div>`;
    $$('.job',l).forEach(c=>c.onclick=()=>{S.selJob=c.dataset.j;S._lsig=null;S._dsig=null;updOps()})}
  const j=S.jobs.find(x=>x.id===S.selJob);
  const dsig=j?JSON.stringify([j.status,j.steps.map(s=>s.status+s.detail),j.result&&Object.keys(j.result).length,Math.floor(Date.now()/5000)]):'none';
  if(S._dsig!==dsig){S._dsig=dsig;d.innerHTML=j?jobDetail(j):'<div class="card nf empty"><div class="orb"></div>Select an operation to see its live timeline.</div>'}}
async function rOps(){$('#v-ops').innerHTML=`<div class="head"><div class="grow"><h2>Operations</h2><div class="sub">Live progress of transports, retries and moves, including automatic rollback.</div></div></div><div class="ops"><div class="jl" id="jl"></div><div id="jd"></div></div>`;S._lsig=null;S._dsig=null;try{S.jobs=(await api('/api/jobs')).jobs}catch(e){}updOps()}

/* ---------- failures ---------- */
function mailText(f,tn){const t=T(tn)||{};return {subject:`[${f.severity}][${t.stage}] Critical CPI Failure Detected - ${f.iflow} - ${f.domain}`,body:`Environment: ${t.stage}\nSubaccount / Tenant: ${tn}\niFlow: ${f.iflow}\nFailure Category: ${f.domain} / ${f.subtype}\nOccurrences: ${f.count}\nRoot Cause (confidence ${Math.round(f.confidence*100)}%): ${f.root_cause}\nRecommended Resolution: ${f.recommended_fix}\nBusiness Impact: ${f.business_impact}\nRunbook: ${f.remediation_id||'none'}\n\nAI Action Plan:\n 1) Validate the evidence in the message processing log (message ${f.sample_message_guid})\n 2) Apply the recommended fix (approval required in PROD)\n 3) Retry affected messages if the receiver is idempotent\n 4) Confirm the error rate returns to baseline`}}
function showMail(f,tn){const m=mailText(f,tn);openModal(`<h3>Incident notification</h3><div class="sub">Preview. Delivery to Teams, Outlook and ServiceNow is the next integration step.</div><pre style="white-space:pre-wrap;background:var(--bg);padding:12px;border-radius:10px;font-size:12.5px">Subject: ${esc(m.subject)}\n\n${esc(m.body)}</pre><div class="acts"><button class="btn ghost" data-a="closeModal">Close</button><button class="btn lil" id="snd">Send via webhook</button><button class="btn" id="cpy">Copy</button></div>`);$('#snd').onclick=async()=>{try{const r=await api('/api/agent/call',{name:'notify_incident',args:{tenant:tn,confirm:true}});toast(r.status==='SENT'?'Notification sent':(r.error||r.message||'Not sent'),r.status==='SENT'?'ok':'bad')}catch(e){toast(e.message,'bad')}};$('#cpy').onclick=()=>{navigator.clipboard&&navigator.clipboard.writeText('Subject: '+m.subject+'\n\n'+m.body);toast('Copied','ok')}}
async function rFail(){
  const el=$('#v-fail');
  if(!S.tenants.length){el.innerHTML=`<div class="empty card"><div class="orb"></div><h2>No tenants yet</h2><button class="btn" data-a="tenantModal">Add tenant</button></div>`;return}
  const t=S.failTenant;
  el.innerHTML=`<div class="head"><div class="grow"><h2>Failure analysis and handling</h2><div class="sub">Root cause per pattern, failed message logs, and retry or move of failed queue messages.</div></div></div>
  <div class="seg" id="ft" style="margin-bottom:12px">${S.tenants.map(x=>`<button class="${x.name===t?'on':''}" data-t="${esc(x.name)}">${esc(x.name)} <small>${x.stage}</small></button>`).join('')}</div>
  <div class="seg" id="fb" style="margin-bottom:16px">${[['patterns','Patterns and root cause'],['messages','Failed message logs'],['search','Message search'],['queues','Queues: retry or move']].map(([k,l])=>`<button class="${S.failTab===k?'on':''}" data-k="${k}">${l}</button>`).join('')}</div><div id="fbody"><div class="skel"></div><div class="skel" style="width:60%"></div></div>`;
  $$('#ft button',el).forEach(b=>b.onclick=()=>{S.failTenant=b.dataset.t;S.failData=null;S.qSel=null;rFail()});$$('#fb button',el).forEach(b=>b.onclick=()=>{S.failTab=b.dataset.k;rFail()});
  const body=$('#fbody');
  try{
    if(S.failTab==='search'){drawSearch(t);return}
    if(S.failTab==='queues'){const qs=(await api('/api/tenants/'+encodeURIComponent(t)+'/queues')).queues;drawQueues(qs);return}
    if(!S.failData||S.failData.t!==t)S.failData={t,...(await api('/api/tenants/'+encodeURIComponent(t)+'/failed'))};
    const d=S.failData;
    if(S.failTab==='patterns')body.innerHTML=d.patterns.length?`<div class="fcards">${d.patterns.map((f,i)=>`<div class="card fc hov" style="--d:${i*50}ms"><div class="t"><b>${esc(f.iflow)}</b><span><span class="chip ${f.severity}">${f.severity}</span> <span class="chip">x${f.count}</span></span></div><div class="chips" style="margin-bottom:6px"><span class="chip" style="color:${catCol[f.domain]||'#aaa'}">${esc(f.domain)} / ${esc(f.subtype)}</span><span class="chip">${Math.round(f.confidence*100)}% confidence</span></div>
      <p>Root cause: <span>${esc(f.root_cause)}</span></p><p>Recommended fix: <span>${esc(f.recommended_fix)}</span></p><p>Business impact: <span>${esc(f.business_impact)}</span></p><p>Runbook: <span>${esc(f.remediation_id||'none, needs a person')}</span></p><p class="tiny">Evidence: ${esc((f.evidence||'').slice(0,160))}</p>
      <div class="chips" style="margin-top:8px"><button class="btn lil sm" data-m="${i}">Draft incident email</button><button class="btn ghost sm" data-x="${esc(f.iflow)}">Explain iFlow</button></div></div>`).join('')}</div>`:'<div class="card empty">No failures found.</div>';
    else body.innerHTML=`<div class="card"><input id="fq" placeholder="Filter by interface or error..." style="margin-bottom:10px"><div class="tw" id="ftab"></div></div>`;
    $$('[data-m]',body).forEach(b=>b.onclick=()=>showMail(d.patterns[+b.dataset.m],t));
    $$('[data-x]',body).forEach(b=>b.onclick=()=>explainModal(t,b.dataset.x));
    if(S.failTab==='messages'){const dr=()=>{const q=($('#fq').value||'').toLowerCase();$('#ftab').innerHTML=`<table><tr><th>Sev</th><th>Interface</th><th>Category</th><th>Time</th><th>Message</th><th>Error</th></tr>${d.messages.filter(m=>!q||JSON.stringify(m).toLowerCase().includes(q)).map(m=>`<tr class="clk" data-g="${esc(m.MessageGuid)}"><td><span class="chip ${m.severity}">${m.severity}</span></td><td>${esc(m.IntegrationFlowName)}</td><td>${esc(m.domain)} / ${esc(m.subtype)}</td><td>${esc(m.LogEnd)}</td><td>${esc(String(m.MessageGuid).slice(0,14))}</td><td class="tiny">${esc(m.error)}</td></tr>`).join('')}</table>`;$$('#ftab tr[data-g]').forEach(r=>r.onclick=()=>traceModal(t,r.dataset.g))};$('#fq').oninput=dr;dr()}
  }catch(e){body.innerHTML=`<div class="card"><span style="color:var(--bad)">${esc(e.message)}</span></div>`}}
function drawQueues(qs){
  const t=S.failTenant,body=$('#fbody');
  body.innerHTML=`<div class="grid tiles">${qs.map((q,i)=>`<div class="card hov qt" style="--d:${i*50}ms;cursor:pointer;${S.qSel===q.Name?'border-color:var(--lil2)':''}" data-q="${esc(q.Name)}"><div class="chips" style="justify-content:space-between"><b>${esc(q.Name)}</b><span class="chip ${q.NumberOfMessages&&/error|dlq|failed/i.test(q.Name)?'b':'l'}">${q.NumberOfMessages} msgs</span></div><div class="tiny" style="margin-top:6px">${esc(q.State)} - ${Math.round(q.SizeInBytes/1024)} KB</div></div>`).join('')||'<div class="card empty">No queues found (JMS may not be enabled on this tenant).</div>'}</div><div id="qbody" style="margin-top:16px"></div><div class="tiny" style="margin-top:10px">Retry and move use the Cloud Integration JMS API (MessagingQueues). Message processing logs of non-JMS flows can be analysed but not retried by API.</div>`;
  $$('.qt',body).forEach(c=>c.onclick=()=>{S.qSel=c.dataset.q;drawQueues(qs)});
  if(S.qSel)loadQ(qs)}
async function loadQ(qs){
  const t=S.failTenant,q=S.qSel,qb=$('#qbody');qb.innerHTML='<div class="skel"></div>';
  try{const ms=(await api('/api/tenants/'+encodeURIComponent(t)+'/queues/'+encodeURIComponent(q))).messages;const others=qs.filter(x=>x.Name!==q);
    qb.innerHTML=`<div class="card nf"><div class="chips" style="justify-content:space-between;margin-bottom:10px"><h3 style="margin:0">${esc(q)} (${ms.length})</h3><div class="chips"><button class="btn lil sm" id="qr" disabled>Retry selected</button><button class="btn ghost sm" id="qa">Retry all failed</button><select id="qt" style="width:150px">${others.map(o=>`<option>${esc(o.Name)}</option>`).join('')}</select><button class="btn ghost sm" id="qm" disabled>Move selected</button></div></div>
    <div class="tw"><table><tr><th><input type="checkbox" id="qall"></th><th>Message ID</th><th>Status</th><th>Retries</th><th>Created</th><th>Error</th></tr>${ms.map(m=>`<tr><td><input type="checkbox" class="qchk" value="${esc(m.JmsMessageId)}"></td><td class="tiny">${esc(m.JmsMessageId)}</td><td><span class="chip ${/fail|error/i.test(m.Status||'')?'b':'l'}">${esc(m.Status)}</span></td><td>${m.RetryCount}</td><td>${esc(m.Created)}</td><td class="tiny">${esc(m.Error||'')}</td></tr>`).join('')}</table></div></div>`;
    const sel=()=>$$('.qchk:checked',qb).map(c=>c.value),upd=()=>{$('#qr').disabled=!sel().length;$('#qm').disabled=!sel().length||!others.length};
    $$('.qchk',qb).forEach(c=>c.onchange=upd);$('#qall').onchange=e=>{$$('.qchk',qb).forEach(c=>c.checked=e.target.checked);upd()};
    const act=(mode,ids)=>{const st=T(t).stage;confirmAction({title:(mode==='retry'?'Retry':'Move')+' messages in '+q,text:(ids.length?ids.length+' selected messages':'All failed messages (max 100)')+(mode==='move'?' will be moved to '+$('#qt').value:' will be retried')+' on '+t+'. This is audited and verified afterwards.',needsApproval:st==='PROD',go:'Run',onGo:ap=>startJob('retry',{tenant:t,queue:q,ids,mode,target_queue:mode==='move'?$('#qt').value:null},ap)})};
    $('#qr').onclick=()=>act('retry',sel());$('#qa').onclick=()=>act('retry',[]);$('#qm').onclick=()=>act('move',sel())
  }catch(e){qb.innerHTML=`<div class="card"><span style="color:var(--bad)">${esc(e.message)}</span></div>`}}

/* ---------- chat ---------- */
function names(){const a=[...S.tenants].sort((x,y)=>stageIdx(x.stage)-stageIdx(y.stage));const s=a[0]&&a[0].name,t=(a[1]||a[0]||{}).name;return [s,t,(a[a.length-1]||{}).name]}
function prompts(){const [a,b,c]=names();if(!a)return ['What can you do?'];const m=S.tenants.length>1;return ['Give me the daily briefing','Any alerts?',m?'Compare tenants for drift':`Diagnose the connection of ${a}`,`Show failed messages in ${c}`,`Analyze issues in ${a}`,m?`Move package Order to Cash from ${a} to ${b}`:'Packages in '+a,'Create an iFlow that reads employees from SuccessFactors and sends them to Salesforce with OAuth']}
function addMsg(who,html){const m=document.createElement('div');m.className='m '+who;m.innerHTML=`<div class="av">${who==='u'?'YOU':'AI'}</div><div class="bub">${html}</div>`;const box=$('#msgs');box.appendChild(m);box.scrollTop=1e9;return m}
function renderReply(j){
  let h=(j.trace&&j.trace.length?`<div class="chips" style="margin-bottom:8px">${j.trace.map(t=>`<span class="chip ${t.ok?'l':'b'}" title="${esc(JSON.stringify(t.args))}">\u2699 ${esc(t.tool)} ${t.ms}ms</span>`).join('')}</div>`:'')+esc(j.reply||'');
  (j.blocks||[]).forEach(b=>{
    if(b.type==='table')h+=`<div class="blk tw" style="max-height:260px"><table><tr>${b.columns.map(c=>`<th>${esc(c)}</th>`).join('')}</tr>${b.rows.map(r=>`<tr>${r.map(c=>`<td>${esc(c)}</td>`).join('')}</tr>`).join('')}</table></div>`;
    if(b.type==='findings')h+=`<div class="blk">${b.items.slice(0,8).map(f=>`<div class="row"><span class="chip ${f.severity}">${f.severity}</span><b>${esc(f.iflow)}</b><span class="chip">x${f.count}</span><span class="muted" style="flex:1">${esc(f.domain)} / ${esc(f.subtype)}: ${esc(f.recommended_fix)}</span></div>`).join('')}</div>`;
    if(b.type==='plan')h+=`<div class="blk">${planHtml(b.plan)}</div>`;
    if(b.type==='alerts')h+=`<div class="blk">${alertsHtml(b.items)}</div>`;
    if(b.type==='diag')h+=`<div class="blk">${diagHtml(b.checks)}</div>`;
    if(b.type==='review')h+=`<div class="blk">${reviewHtml(b.review,true)}</div>`;
    if(b.type==='trace')h+=`<div class="blk">${traceHtml(b.trace)}</div>`;
    if(b.type==='briefing')h+=`<div class="blk">${(b.briefing.items||[]).slice(0,6).map(i=>`<div class="alert ${i.severity}"><i></i><div style="flex:1">${esc(i.text)}<div class="tiny">${esc(i.action||'')}</div></div></div>`).join('')||'<div class="tiny">Nothing needs attention.</div>'}<div class="tiny" style="margin-top:6px">Operations in 24h: ${b.briefing.operations_24h.total} (${b.briefing.operations_24h.success} succeeded, ${b.briefing.operations_24h.rolled_back} rolled back, ${b.briefing.operations_24h.failed} failed). Pending approvals: ${b.briefing.pending_approvals}.</div></div>`;
    if(b.type==='build'){S.build=b.build;h+=`<div class="blk"><b>${esc(b.build.iflow_id)}</b><div class="chips" style="margin-top:6px">${b.build.lint.map(l=>`<span class="chip ${l.level==='ok'?'ok':l.level==='warn'?'w':'b'}">${esc(l.text.slice(0,48))}</span>`).join('')}</div></div>`}
    if(b.type==='email')h+=`<div class="blk"><pre>Subject: ${esc(b.subject)}\n\n${esc(b.body)}</pre></div>`});
  if((j.proposals||[]).length)h+=`<div class="blk chips">${j.proposals.map((p,i)=>`<button class="btn sm" data-p="${i}">${esc(p.label)}</button>`).join('')}</div>`;
  h+=`<div class="fb"><button data-f="up">Helpful</button><button data-f="down">Not helpful</button><button data-f="copy">Copy</button></div>`;
  return h}
function renderSugg(l){$('#sugg').innerHTML=(l||[]).slice(0,4).map(p=>`<button class="btn ghost sm" data-s="${esc(p)}">${esc(p)}</button>`).join('')}
function saveChat(){sessionStorage.setItem('chat',JSON.stringify(S.chatHist.slice(-40)))}
async function sendChat(txt){
  const i=$('#cin'),t=(txt||i.value).trim();if(!t)return;i.value='';openPanel();addMsg('u',esc(t));S.chatHist.push({who:'u',text:t});
  const ty=addMsg('a','<span class="typing"><span></span><span></span><span></span></span>');
  try{const j=await api('/chat',{message:t,context:ctxNow()});const b=$('.bub',ty);b.innerHTML=renderReply(j);S.chatHist.push({who:'a',text:j.reply});saveChat();renderSugg(j.suggestions&&j.suggestions.length?j.suggestions:prompts());
    $$('[data-p]',b).forEach(btn=>btn.onclick=()=>{const p=j.proposals[+btn.dataset.p];if(p.kind==='build_open'){go('build');return}confirmAction({title:p.label,text:p.needs_approval?'This change needs a second approver.':'You can follow progress on the Operations page.',needsApproval:p.needs_approval,go:'Run',onGo:()=>startJob(p.kind,p.params)})});
    $$('[data-f]',b).forEach(btn=>btn.onclick=async()=>{const f=btn.dataset.f;if(f==='copy'){navigator.clipboard&&navigator.clipboard.writeText(j.reply);toast('Copied','ok');return}try{await api('/api/feedback',{rating:f})}catch(e){}$$('[data-f]',b).forEach(x=>x.disabled=true);btn.classList.add('on')});
    $$('[data-xr]',b).forEach(btn=>btn.onclick=()=>explainModal(btn.dataset.t,btn.dataset.xr));
  }catch(e){$('.bub',ty).innerHTML=`<span style="color:var(--bad)">${esc(e.message)}</span>`}
  $('#msgs').scrollTop=1e9}
function rChat(){openPanel()}
/* ---------- audit ---------- */
function openReport(){return openHtml('/api/report.html')}
async function rAudit(){
  const el=$('#v-audit');el.innerHTML=`<div class="head"><div class="grow"><h2>Trust center</h2><div class="sub">Live status of every security control, computed from the running configuration, plus the hash-chained audit trail.</div></div></div><div class="card"><div class="skel"></div><div class="skel" style="width:60%"></div></div>`;
  let g,au;try{[g,au]=await Promise.all([api('/api/governance'),api('/api/audit')])}catch(e){el.innerHTML=`<div class="card">${esc(e.message)}</div>`;return}
  const st={ok:['Active','ok'],warn:['Partial','w'],bad:['Gap','b'],info:['Info','l']},ev=au.events.slice().reverse();
  const refChips=r=>Object.entries(r||{}).filter(([k,v])=>v).map(([k,v])=>`<span class="chip ref" title="${({iso:'ISO/IEC 27001:2022 Annex A',soc2:'SOC 2 criteria',gdpr:'GDPR',owasp:'OWASP Top 10 2021',sox:'SOX ITGC'})[k]}">${({iso:'ISO',soc2:'SOC2',gdpr:'GDPR',owasp:'OWASP',sox:'SOX'})[k]} ${esc(v)}</span>`).join('');
  el.innerHTML=`<div class="head"><div class="grow"><h2>Trust center</h2><div class="sub">Live status of every security control, computed from the running configuration, plus the hash-chained audit trail.</div></div>
  <button class="btn lil sm" data-a="evidence">Evidence pack</button>${S.me.scopes.includes('Admin')&&!S.me.sandbox?'<button class="btn ghost sm" data-a="auditExport">Export audit</button>':''}<button class="btn ghost sm" data-a="auditVerify">Verify chain</button></div>
  <div class="grid two" style="margin-top:0;grid-template-columns:320px 1fr"><div class="card" style="text-align:center"><div class="bigring">${ring(g.score,g.score>=85?'#22c55e':g.score>=65?'#f59e0b':'#ff4d5e')}</div><h3 style="margin-top:10px">Control score</h3><div class="chips" style="justify-content:center"><span class="chip l">Profile: ${esc(g.profile)}</span><span class="chip ok">${g.counts.ok} active</span><span class="chip w">${g.counts.warn} partial</span><span class="chip b">${g.counts.bad} gaps</span></div><div class="tiny" style="margin-top:10px">Score counts active controls fully and partial controls half. It is not a certification.</div>
  <div class="tiny" style="margin-top:10px;text-align:left">Audit head <code>${esc(String(au.head.head_hash).slice(0,16))}</code><br>${au.head.events_total} events recorded, ${au.head.retained} retained</div></div>
  <div class="card"><h3>Profiles</h3><div class="tiny" style="line-height:1.7"><b>pilot</b> (default): sandbox on, tenants can be added in the UI, 8 hour sessions.<br><b>strict</b>: set <code>SECURITY_PROFILE=strict</code> to turn off the sandbox and UI tenant entry, shorten sessions to 30 minutes and require named identities.<br>Named identities: <code>ACCESS_KEY</code> (operator), <code>APPROVER_KEY</code>, <code>VIEWER_KEY</code>, <code>ADMIN_KEY</code>. Different people use different keys, so approvals are real four-eyes.</div><div class="chips" style="margin-top:12px"><span class="chip">ISO 27001 mapping</span><span class="chip">SOC 2 mapping</span><span class="chip">GDPR mapping</span><span class="chip">OWASP Top 10 mapping</span><span class="chip">SBOM</span></div><div class="tiny" style="margin-top:8px">Open the evidence pack for the full mapping, data-handling statement, known gaps and the software bill of materials. Print it to save as PDF.</div></div></div>
  <div class="card" style="margin-top:16px"><h3>Controls</h3><div class="ctl">${g.controls.map(c=>`<div class="cc"><span class="chip ${st[c.status][1]}">${st[c.status][0]}</span><div><b>${esc(c.name)}</b><div class="tiny">${esc(c.detail)}</div><div class="chips" style="margin-top:6px">${refChips(c.refs)}</div></div></div>`).join('')}</div></div>
  <div class="card" style="margin-top:16px"><h3>Audit trail</h3>${ev.length?`<div class="tw" style="max-height:420px"><table><tr><th>Time</th><th>Decision</th><th>Action</th><th>User</th><th>Target</th><th>Hash</th></tr>${ev.map(e=>`<tr><td>${new Date(e.ts*1000).toLocaleTimeString()}</td><td><span class="chip ${/DENY|FAIL|ERROR/.test(e.decision)?'b':/ROLLED|PENDING|REJECT/.test(e.decision)?'w':'ok'}">${esc(e.decision)}</span></td><td>${esc(e.action)}</td><td>${esc(e.user)}</td><td>${esc(e.target)}</td><td class="tiny">#${esc(String(e.hash).slice(0,10))}</td></tr>`).join('')}</table></div>`:'<div class="empty">No events yet.</div>'}</div>`;
  animateAll(el)}
/* ---------- command palette ---------- */
let pItems=[],pSel=0;
function palItems(q){const nav=[['dash','Mission control'],['mon','Monitoring'],['trans','Transport'],['drift','Landscape drift'],['build','iFlow Builder'],['fail','Failures'],['approvals','Approvals'],['agent','Agent and MCP'],['packages','Packages'],['ops','Operations'],['tenants','Connect and diagnostics'],['audit','Trust center'],['about','About']].map(([v,l])=>({t:'Go to '+l,k:'Navigate',run:()=>go(v)}));
  const act=[{t:'Open copilot',k:'Action',run:()=>openPanel()},{t:'Add tenant',k:'Action',run:()=>tenantModal()},{t:'Load demo tenants',k:'Action',run:loadDemo},{t:'Refresh all data',k:'Action',run:()=>loadTenants(true)},{t:'Security evidence pack',k:'Action',run:()=>openHtml('/api/evidence.html')},{t:'Switch theme',k:'Action',run:()=>$('#themeBtn').click()}];
  const ask=prompts().map(p=>({t:p,k:'Ask copilot',run:()=>sendChat(p)}));
  let all=[...nav,...act,...ask];if(q){all=all.filter(i=>i.t.toLowerCase().includes(q.toLowerCase()));all.push({t:'Ask copilot: '+q,k:'Ask',run:()=>sendChat(q)})}return all}
function drawPal(){const q=$('#pin').value;pItems=palItems(q);pSel=Math.min(pSel,pItems.length-1);$('#plist').innerHTML=pItems.map((i,n)=>`<div class="pi ${n===pSel?'on':''}" data-n="${n}">${esc(i.t)}<small>${i.k}</small></div>`).join('');$$('.pi').forEach(e=>e.onclick=()=>{closePal();pItems[+e.dataset.n].run()})}
function openPal(){if(!S.auth)return;$('#palette').classList.add('on');$('#pin').value='';pSel=0;drawPal();$('#pin').focus()}
function closePal(){$('#palette').classList.remove('on')}
$('#openPalette').onclick=openPal;$('#palette').onclick=e=>{if(e.target.id==='palette')closePal()};
$('#pin').oninput=()=>{pSel=0;drawPal()};
$('#pin').onkeydown=e=>{if(e.key==='ArrowDown'){pSel=Math.min(pItems.length-1,pSel+1);drawPal();e.preventDefault()}else if(e.key==='ArrowUp'){pSel=Math.max(0,pSel-1);drawPal();e.preventDefault()}else if(e.key==='Enter'){const i=pItems[pSel];closePal();if(i)i.run()}};
addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();openPal()}if(e.key==='Escape'){closePal();closeModal()}});


/* =================== v0.5 additions =================== */
let TOOLN=22;
function alertsHtml(a){if(!a||!a.length)return '<div class="sub">No active alerts. Everything looks healthy.</div>';
  return a.map(x=>`<div class="alert ${x.severity}"><i></i><div style="flex:1"><b>${esc(x.title)}</b><div class="tiny">${esc(x.tenant)} (${x.stage}) - ${esc(x.detail)}</div></div><span class="chip ${x.severity==='critical'?'b':'w'}">${x.severity}</span></div>`).join('')}
function mission(C,run){
  const hs=C.map(health).filter(x=>x!=null),avg=hs.length?hs.reduce((a,b)=>a+b,0)/hs.length:null,crit=S.alerts.filter(a=>a.severity==='critical').length;
  const mv=S.jobs.filter(j=>j.kind==='move'),last=mv[0],ap=((S.approvals&&S.approvals.approvals)||[]).filter(x=>x.status==='PENDING').length;
  return `<div class="mission">
  <div class="mtile m1" data-a="go" data-p="mon"><div class="mi">\u25C9</div><h3>Monitoring</h3><div class="big">${avg==null?'<span class="na">No data</span>':Math.round(avg)+'<small>% health</small>'}</div><div class="tiny">${C.length} tenant${C.length===1?'':'s'} live, <b style="color:${crit?'var(--bad)':'var(--ok)'}">${crit} critical</b>, ${S.alerts.length-crit} warnings</div><div class="go">Open monitoring \u2192</div></div>
  <div class="mtile m2" data-a="go" data-p="trans"><div class="mi">\u21C4</div><h3>Transport</h3><div class="big">${mv.length}<small> moves</small></div><div class="tiny">${ap?'<b style="color:var(--warn)">'+ap+' awaiting approval</b>':run?'<b style="color:var(--lil2)">'+run+' running</b>':last?'Last: '+statusLabel(last.status).toLowerCase()+' '+ago(last.created):'Governed moves with approval and rollback'}</div><div class="go">Start a transport \u2192</div></div>
  <div class="mtile m3" data-a="go" data-p="build"><div class="mi">\u2726</div><h3>iFlow Builder</h3><div class="big">6<small> templates</small></div><div class="tiny">Describe an integration. Get iFlow, Groovy, value mapping, security and docs.</div><div class="go">Build an iFlow \u2192</div></div>
  <div class="mtile m4" data-a="go" data-p="agent"><div class="mi">\u2699</div><h3>Agent and MCP</h3><div class="big">${TOOLN}<small> tools</small></div><div class="tiny">Chat panel, web UI and any MCP client share the same governed tools.</div><div class="go">See tools \u2192</div></div></div>`}
/* ---------- connect / tenants ---------- */
function rTenants(){
  const el=$('#v-tenants'),hasDemo=S.tenants.some(t=>t.demo),auto=S.tenants.filter(t=>t.source==='auto');
  el.innerHTML=`<div class="head"><div class="grow"><h2>Connect and diagnostics</h2><div class="sub">Tenants bound to this application appear automatically. Run diagnostics to see exactly which Integration Suite APIs each tenant allows.</div></div>${hasDemo?'<button class="btn ghost sm" data-a="clearDemo">Remove demo tenants</button>':'<button class="btn ghost sm" data-a="loadDemo">Load demo tenants</button>'}</div>
  ${S.me.sandbox?'':`<div class="card connect" style="margin-bottom:16px"><div class="chips" style="justify-content:space-between"><h3 style="margin:0">Connect a subaccount automatically</h3><span class="chip ${auto.length?'ok':'w'}">${auto.length} auto-connected</span></div>
  <p class="muted" style="margin:8px 0">The application reads the service binding of every Process Integration Runtime instance. Run these once per tenant, in the space where this app runs:</p>
  <pre class="cmd" id="cmdBox">cf create-service it-rt api cpi-dev -c cpi-roles.json\ncf bind-service cpi-copilot-api cpi-dev\ncf restage cpi-copilot-api</pre>
  <div class="tiny">Name the instance cpi-dev, cpi-qa, cpi-uat, cpi-preprod or cpi-prod and the stage is detected. For queue retry and move add the extra roles with <code>cf update-service cpi-dev -c cpi-roles-ext.json</code>, then unbind, bind and restage so the new roles reach the token.</div>
  <div class="chips" style="margin-top:10px"><button class="btn ghost sm" id="cpyCmd">Copy commands</button>${S.me.ui_tenants?'<button class="btn ghost sm" data-a="tenantModal">Add tenant from a service key</button>':'<span class="chip">Adding tenants in the UI is off in this security profile</span>'}</div></div>`}
  <div class="grid tiles">${S.tenants.map((t,i)=>{const o=S.ov[t.name],src={auto:'auto-connected (service binding)',service:'permanent (cf service)',ui:'added in UI (memory only)',demo:'demo'}[t.source],bad=o&&o.quality?Object.values(o.quality).filter(v=>!v.ok).length:0;
  return `<div class="card tcard hov" style="--d:${i*50}ms"><div class="top"><span class="nm">${esc(t.name)}</span><span class="chip l">${t.stage}</span></div>
  <div class="em">${esc(t.host)}<br>Source <b>${src}</b><br>Status <b style="color:${o&&o.connected?(bad?'var(--warn)':'var(--ok)'):o?'var(--bad)':'var(--mut)'}">${o?(o.connected?(bad?'Connected, '+bad+' section(s) not readable':'Connected, '+o.latency_ms+' ms'):'Unreachable'):'Checking...'}</b>${o&&!o.connected&&o.error?`<br><span style="color:var(--bad)">${esc(o.error)}</span>`:''}</div>
  <div class="chips" style="margin-top:12px">${t.demo||!S.me.scopes.includes('Admin')?'':`<select class="stsel" data-t="${esc(t.name)}" style="width:110px;padding:5px 8px">${STAGES.map(s=>`<option ${s===t.stage?'selected':''}>${s}</option>`).join('')}</select>`}<button class="btn lil sm" data-a="diag" data-p="${esc(t.name)}">Diagnose</button><button class="btn ghost sm" data-a="testT" data-p="${esc(t.name)}">Test</button><button class="btn ghost sm" data-a="pkTo" data-p="${esc(t.name)}">Packages</button>${t.source==='ui'?`<button class="btn ghost sm" data-a="rmT" data-p="${esc(t.name)}">Remove</button>`:''}</div></div>`}).join('')}
  ${!S.tenants.length?'<div class="card empty"><div class="orb"></div>No tenants yet. Run the commands above, or load the demo tenants.</div>':''}</div>`;
  $$('.stsel',el).forEach(s=>s.onchange=async()=>{try{await api('/api/tenants/'+encodeURIComponent(s.dataset.t)+'/stage',{stage:s.value});toast('Stage set to '+s.value,'ok');await loadTenants(true);render()}catch(e){toast(e.message,'bad')}});
  const cp=$('#cpyCmd');if(cp)cp.onclick=()=>{navigator.clipboard&&navigator.clipboard.writeText($('#cmdBox').textContent);toast('Copied','ok')};animateAll(el)}
/* ---------- monitoring ---------- */
function bigChart(a){if(!a||a.length<2)return '<div class="sub">No time series from this tenant.</div>';const w=900,h=190,mx=Math.max(...a)*1.1,dx=w/(a.length-1);const p=a.map((v,i)=>[i*dx,h-14-v/mx*(h-30)]);
  return `<svg viewBox="0 0 ${w} ${h}" width="100%" preserveAspectRatio="none" style="display:block"><defs><linearGradient id="gA" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#6764f6" stop-opacity=".55"/><stop offset="1" stop-color="#6764f6" stop-opacity="0"/></linearGradient></defs>${[0,1,2,3].map(i=>`<line x1="0" x2="${w}" y1="${14+i*(h-30)/3}" y2="${14+i*(h-30)/3}" stroke="var(--bd)" stroke-dasharray="3 5"/>`).join('')}<path d="M0,${h} L${p.map(x=>x.join(',')).join(' L')} L${w},${h}Z" fill="url(#gA)"/><path d="M${p.map(x=>x.join(',')).join(' L')}" fill="none" stroke="#93a1ff" stroke-width="2.5" stroke-dasharray="2200" stroke-dashoffset="2200"><animate attributeName="stroke-dashoffset" to="0" dur="1.6s" fill="freeze"/></path>${p.map((x,i)=>i%4===0?`<text x="${x[0]}" y="${h-1}" font-size="10" fill="var(--mut)">${24-a.length+i}h</text>`:'').join('')}</svg>`}
const SEC={stats:'Message statistics',sample:'Hourly chart',artifacts:'Runtime artifacts',certs:'Certificates',queues:'JMS queues',patterns:'Failure patterns'};
const STC={COMPLETED:'#22c55e',FAILED:'#ff000f',RETRY:'#f59e0b',ESCALATED:'#ff957e',PROCESSING:'#93a1ff',ABANDONED:'#8e97b3'};
function volChart(tot,fail){
  if(!tot||tot.length<2)return '<div class="sub">No hourly data available for this tenant.</div>';
  const w=900,h=200,mx=Math.max(...tot,1)*1.12,dx=w/(tot.length-1),P=a=>a.map((v,i)=>[(i*dx).toFixed(1),(h-22-v/mx*(h-40)).toFixed(1)]),pt=P(tot),pf=P(fail||tot.map(()=>0));
  return `<svg viewBox="0 0 ${w} ${h}" width="100%" preserveAspectRatio="none" style="display:block"><defs><linearGradient id="gV" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#6764f6" stop-opacity=".5"/><stop offset="1" stop-color="#6764f6" stop-opacity="0"/></linearGradient></defs>${[0,1,2,3].map(i=>`<line x1="0" x2="${w}" y1="${18+i*(h-40)/3}" y2="${18+i*(h-40)/3}" stroke="var(--bd)" stroke-dasharray="3 5"/>`).join('')}<path d="M0,${h-22} L${pt.map(x=>x.join(',')).join(' L')} L${w},${h-22}Z" fill="url(#gV)"/><path d="M${pt.map(x=>x.join(',')).join(' L')}" fill="none" stroke="#93a1ff" stroke-width="2.5"/><path d="M${pf.map(x=>x.join(',')).join(' L')}" fill="none" stroke="#ff000f" stroke-width="2.5"/>${pt.map((x,i)=>i%4===0||i===tot.length-1?`<text x="${Math.min(+x[0],w-30)}" y="${h-4}" font-size="10" fill="var(--mut)">${i===tot.length-1?'now':(tot.length-1-i)+'h ago'}</text>`:'').join('')}<text x="8" y="12" font-size="10" fill="#93a1ff">messages per hour (max ${fmt(Math.round(mx/1.12))})</text><text x="${w-110}" y="12" font-size="10" fill="#ff000f">failed per hour</text></svg>`}
function statusBar(by){
  if(!by)return '<div class="sub">Status counts are not readable for this tenant.</div>';
  const tot=Object.values(by).reduce((a,b)=>a+(b||0),0)||1;
  return `<div class="sbar">${Object.entries(by).filter(([k,v])=>v).map(([k,v])=>`<i style="width:${Math.max(1.5,v/tot*100)}%;background:${STC[k]||'#888'}" title="${k}: ${fmt(v)}"></i>`).join('')}</div><div class="chips" style="margin-top:8px">${Object.entries(by).map(([k,v])=>`<span class="chip" style="border:1px solid ${STC[k]||'#888'}">${k} ${v==null?'n/a':fmt(v)}</span>`).join('')}</div>`}
function flowTable(bf){
  const rows=Object.entries(bf||{}).sort((a,b)=>b[1].total-a[1].total).slice(0,8);
  if(!rows.length)return '<div class="sub">No per-interface data.</div>';
  const mx=rows[0][1].total||1;
  return rows.map(([n,v])=>`<div class="row"><span style="flex:1.4;overflow:hidden;text-overflow:ellipsis">${esc(n)}</span><div class="bar"><i data-w="${v.total/mx*100}%" style="background:linear-gradient(90deg,var(--lil),${v.failed?'var(--red)':'var(--lil)'})"></i></div><b style="width:62px;text-align:right">${fmt(v.total)}</b><span class="chip ${v.failed?'b':'ok'}" style="width:74px;text-align:center">${v.failed?(v.failed/v.total*100).toFixed(1)+'% fail':'clean'}</span></div>`).join('')}
async function rMon(soft){
  const el=$('#v-mon');
  if(!S.tenants.length){el.innerHTML=`<div class="empty card"><div class="orb"></div><h2>No tenants yet</h2><button class="btn" data-a="go" data-p="tenants">How to connect</button></div>`;return}
  const t=S.monTenant;if(!t)return;S.monBusy=true;
  if(!S.ov[t]){el.innerHTML='<div class="skel"></div><div class="skel" style="width:50%"></div>';try{S.ov[t]=await api('/api/overview/'+encodeURIComponent(t))}catch(e){S.ov[t]={name:t,connected:false,error:e.message}}}
  try{S.hist=(await api('/api/alerts/history')).events}catch(e){S.hist=S.hist||[]}
  const o=S.ov[t],ta=S.alerts.filter(a=>a.tenant===t);S.artQ=S.artQ||'';S.artS=S.artS||'ALL';
  const h=health(o),q=o.quality||{},badq=Object.entries(q).filter(([k,v])=>!v.ok);
  const arts=(o.artifacts||[]).filter(a=>(S.artS==='ALL'||(S.artS==='OK'?a.Status==='STARTED':a.Status!=='STARTED'))&&(!S.artQ||(a.Id+a.Name).toLowerCase().includes(S.artQ.toLowerCase())));
  const ns=(o.artifacts||[]).filter(a=>a.Status!=='STARTED').length,ev=(S.hist||[]).filter(e=>e.tenant===t).slice(0,8);
  el.innerHTML=`<div class="head"><div class="grow"><h2>Monitoring</h2><div class="sub">Counts are exact values from the tenant. Anything the tenant does not allow us to read is shown as n/a, never as zero.${S.autoOn?' Refreshing every 20 seconds.':''}</div></div><label class="tog" style="margin:0"><input type="checkbox" id="autoR" ${S.autoOn?'checked':''}><span>Auto refresh</span></label><button class="btn ghost sm" id="monR">Refresh now</button></div>
  <div class="seg" style="margin-bottom:16px">${S.tenants.map(x=>`<button class="${x.name===t?'on':''}" data-t="${esc(x.name)}">${esc(x.name)} <small>${x.stage}</small></button>`).join('')}</div>
  ${!o.connected?`<div class="card" style="border-color:var(--bad)"><h3 style="color:var(--bad)">Tenant unreachable</h3>${esc(o.error||'')}<div class="chips" style="margin-top:10px"><button class="btn lil sm" data-a="diag" data-p="${esc(t)}">Run diagnostics</button></div></div>`:`
  ${badq.length?`<div class="banner w" style="margin-bottom:14px"><b>Some data could not be read from ${esc(t)}.</b>${badq.map(([k,v])=>`<div class="tiny">${SEC[k]||k}: ${esc(v.error)}</div>`).join('')}<div class="chips" style="margin-top:8px"><button class="btn lil sm" data-a="diag" data-p="${esc(t)}">Run diagnostics</button></div></div>`:''}
  ${o.sample_note?`<div class="tiny" style="margin-bottom:8px">${esc(o.sample_note)}</div>`:''}
  <div class="grid kpis"><div class="card kpi" style="--c:${hcol(h)}"><div class="k-ico">H</div>${h==null?`<div class="k-val na">${esc(o.health_label||'n/a')}</div>`:`<div class="k-val" data-count="${h}">0</div>`}<div class="k-lab">Health score</div></div>
  <div class="card kpi" style="--c:#4b8bf6"><div class="k-ico">M</div>${o.messages_24h==null?'<div class="k-val na">n/a</div>':`<div class="k-val" data-count="${o.messages_24h}">0</div>`}<div class="k-lab">Messages 24h</div></div>
  <div class="card kpi" style="--c:var(--red)"><div class="k-ico">!</div>${o.failed_24h==null?'<div class="k-val na">n/a</div>':`<div class="k-val" data-count="${o.failed_24h}">0</div>`}<div class="k-lab">Failed 24h</div></div>
  <div class="card kpi" style="--c:var(--warn)"><div class="k-ico">R</div>${!o.by_status||o.by_status.RETRY==null?'<div class="k-val na">n/a</div>':`<div class="k-val" data-count="${o.by_status.RETRY}">0</div>`}<div class="k-lab">In retry</div></div>
  <div class="card kpi" style="--c:var(--lil)"><div class="k-ico">X</div>${q.artifacts&&!q.artifacts.ok?'<div class="k-val na">n/a</div>':`<div class="k-val" data-count="${ns}">0</div>`}<div class="k-lab">Artifacts not started</div></div>
  <div class="card kpi" style="--c:var(--lil2)"><div class="k-ico">L</div><div class="k-val" data-count="${o.latency_ms||0}">0</div><div class="k-lab">API latency ms</div></div></div>
  <div class="grid two"><div class="card"><h3>Messages per hour, last 24 hours</h3>${volChart(o.series,o.failed_series)}<h3 style="margin-top:14px">Status breakdown</h3>${statusBar(o.by_status)}</div>
  <div class="card"><h3>Alerts for ${esc(t)} <span class="chip ${ta.some(a=>a.severity==='critical')?'b':'ok'}">${ta.length}</span></h3><div class="feed" style="max-height:200px">${alertsHtml(ta)}</div><h3 style="margin-top:14px">Alert timeline</h3><div class="feed" style="max-height:150px">${ev.length?ev.map(e=>`<div class="ev"><i style="background:${e.type==='raised'?(e.severity==='critical'?'var(--bad)':'var(--warn)'):'var(--ok)'}"></i><div><b>${e.type==='raised'?'Raised':'Resolved'}</b> ${esc(e.title)}<div class="tiny">${ago(e.ts)} - ${esc(e.detail)}</div></div></div>`).join(''):'<div class="sub">No alert changes recorded yet.</div>'}</div></div></div>
  <div class="grid two"><div class="card"><h3>Busiest interfaces (24h)</h3>${flowTable(o.by_flow)}</div><div class="card"><h3>Certificates</h3>${q.certs&&!q.certs.ok?'<div class="sub">Not readable: '+esc(q.certs.error)+'</div>':certsHtml((o.certs||[]).map(c=>({...c,t:t})))}<h3 style="margin-top:18px">Queues</h3>${q.queues&&!q.queues.ok?'<div class="sub">Not readable: '+esc(q.queues.error)+'</div>':(o.queues||[]).length?(o.queues||[]).map(x=>`<div class="row"><span style="flex:1">${esc(x.Name)}</span><span class="chip">${esc(x.State)}</span><span class="chip ${x.NumberOfMessages&&/error/i.test(x.Name)?'b':'l'}">${x.NumberOfMessages}</span></div>`).join(''):'<div class="sub">No queues.</div>'}</div></div>
  <div class="card" style="margin-top:16px"><div class="chips" style="justify-content:space-between;margin-bottom:8px"><h3 style="margin:0">Runtime artifacts (${(o.artifacts||[]).length})</h3><div class="chips"><input id="artQ" placeholder="Filter" style="width:140px;padding:6px 9px" value="${esc(S.artQ)}"><select id="artS" style="width:120px;padding:6px 9px">${['ALL','OK','ISSUES'].map(x=>`<option ${S.artS===x?'selected':''}>${x}</option>`).join('')}</select></div></div>
  ${q.artifacts&&!q.artifacts.ok?'<div class="sub">Not readable: '+esc(q.artifacts.error)+'</div>':`<div class="tw" style="max-height:330px"><table><tr><th>Artifact</th><th>Type</th><th>Version</th><th>Deployed</th><th>Status</th></tr>${arts.map(a=>`<tr><td>${esc(a.Name||a.Id)}<div class="tiny">${esc(a.Id)}</div></td><td>${esc(String(a.Type||'').replace('INTEGRATION_FLOW','iFlow').replace('VALUE_MAPPING','Value mapping').replace('SCRIPT_COLLECTION','Script'))}</td><td>${esc(a.Version)}</td><td class="tiny">${esc(a.DeployedBy||'')}<br>${esc((a.DeployedOn||'').slice(0,16).replace('T',' '))}</td><td><span class="chip ${a.Status==='STARTED'?'ok':a.Status==='STARTING'?'run':'b'}">${esc(a.Status)}</span></td></tr>`).join('')||'<tr><td colspan="5" class="tiny">Nothing matches</td></tr>'}</table></div>`}</div>
  <div class="card" style="margin-top:16px"><h3>Failure patterns</h3>${q.patterns&&!q.patterns.ok?'<div class="sub">Not readable: '+esc(q.patterns.error)+'</div>':(o.patterns||[]).length?(o.patterns||[]).slice(0,6).map(p=>`<div class="row"><span class="chip ${p.severity}">${p.severity}</span><b style="width:210px">${esc(p.iflow)}</b><span class="chip">x${p.count}</span><span class="muted" style="flex:1">${esc(p.domain)} / ${esc(p.subtype)}: ${esc(p.recommended_fix)}</span><button class="btn ghost sm" data-ex="${esc(p.iflow)}">Explain</button></div>`).join(''):'<div class="sub">No failures in the sampled window.</div>'}<div class="chips" style="margin-top:10px"><button class="btn lil sm" data-a="failTo" data-p="${esc(t)}">Open failure handling</button></div></div>`}`;
  S.monBusy=false;
  $$('.seg button',el).forEach(b=>b.onclick=()=>{S.monTenant=b.dataset.t;updCtx();rMon()});
  $$('[data-ex]',el).forEach(b=>b.onclick=()=>explainModal(t,b.dataset.ex));
  $('#monR').onclick=async()=>{try{S.ov[t]=await api('/api/overview/'+encodeURIComponent(t)+'?refresh=1')}catch(e){}rMon()};
  const aq=$('#artQ');if(aq){aq.oninput=()=>{S.artQ=aq.value;clearTimeout(S._aq);S._aq=setTimeout(()=>{rMon().then(()=>{const n=$('#artQ');if(n){n.focus();n.setSelectionRange(99,99)}})},250)}}const as=$('#artS');if(as)as.onchange=()=>{S.artS=as.value;rMon()};
  $('#autoR').onchange=e=>{S.autoOn=e.target.checked;clearInterval(S.autoT);if(S.autoOn)S.autoT=setInterval(async()=>{if(S.view!=='mon')return;try{S.ov[S.monTenant]=await api('/api/overview/'+encodeURIComponent(S.monTenant)+'?refresh=1');api('/api/alerts').then(x=>S.alerts=x.alerts);rMon()}catch(e){}},20000);rMon()};
  if(S.autoOn&&!S.autoT)$('#autoR').onchange({target:{checked:true}});
  animateAll(el)}
/* ---------- transport ---------- */
function reason(src,t){if(!src||t.name===src.name)return 'Source';const si=stageIdx(src.stage),ti=stageIdx(t.stage);if(ti<si)return 'Backward not allowed';const regs=new Set(S.tenants.map(x=>x.stage)),sk=STAGES.slice(si+1,ti).filter(x=>regs.has(x));return sk.length?'Pass through '+sk.join(', ')+' first':''}
async function rTrans(){
  const el=$('#v-trans');
  if(S.tenants.length<2){el.innerHTML=`<div class="empty card"><div class="orb"></div><h2>${S.tenants.length?'Connect a second tenant':'No tenants yet'}</h2><p>A transport needs a source and a target. Bind another instance (for example cpi-qa), or load the demo landscape.</p><div class="chips" style="justify-content:center"><button class="btn" data-a="go" data-p="tenants">How to connect</button><button class="btn ghost" data-a="loadDemo">Load demo tenants</button></div></div>`;return}
  const st=S.tr=S.tr||{src:null,tgt:null,pkg:null,arts:[],plan:null,needs:false,busy:false,err:'',deploy:true,deps:true,sim:false,mode:'package'};
  const sorted=[...S.tenants].sort((a,b)=>stageIdx(a.stage)-stageIdx(b.stage));
  if(!st.src||!T(st.src))st.src=sorted[0].name;
  if(st.tgt&&(!T(st.tgt)||reason(T(st.src),T(st.tgt))))st.tgt=null;
  if(!st.tgt){const c=sorted.find(t=>!reason(T(st.src),t));st.tgt=c&&c.name}
  if(!S.pkData[st.src]){try{S.pkData[st.src]=(await api('/api/tenants/'+encodeURIComponent(st.src)+'/packages')).packages}catch(e){S.pkData[st.src]=[];st.err=e.message}}
  const pk=S.pkData[st.src]||[];
  const tile=(t,role)=>{const o=S.ov[t.name],rs=role==='tgt'?reason(T(st.src),t):'',sel=(role==='src'?st.src:st.tgt)===t.name;return `<div class="opt ${rs?'dis':''} ${sel?'on':''}" data-r="${role}" data-t="${esc(t.name)}"><b>${esc(t.name)}</b><small>${t.stage} ${o&&o.connected?'- '+(o.artifacts||[]).length+' artifacts':''}${rs&&rs!=='Source'?'<br>'+esc(rs):''}</small></div>`};
  const jl=S.jobs.filter(j=>j.kind==='move').slice(0,6);
  el.innerHTML=`<div class="head"><div class="grow"><h2>Transport</h2><div class="sub">Move packages or single iFlows between tenants. Dependencies are checked, the target is snapshotted, and a failed verification rolls back automatically.</div></div></div>
  <div class="card"><h3>1. Route</h3><div class="route"><div><div class="tiny" style="margin-bottom:6px">SOURCE</div><div class="pick">${sorted.map(t=>tile(t,'src')).join('')}</div></div>
  <div class="arrow"><svg viewBox="0 0 120 40" width="120"><path d="M4,20 H100" stroke="var(--lil2)" stroke-width="3" stroke-dasharray="6 7" class="flow2"/><path d="M96,8 L114,20 L96,32" fill="none" stroke="var(--red)" stroke-width="3"/><circle r="5" fill="#ff000f"><animate attributeName="cx" values="6;100" dur="1.6s" repeatCount="indefinite"/><animate attributeName="cy" values="20;20" dur="1.6s" repeatCount="indefinite"/></circle></svg></div>
  <div><div class="tiny" style="margin-bottom:6px">TARGET</div><div class="pick">${sorted.filter(t=>t.name!==st.src).map(t=>tile(t,'tgt')).join('')}</div></div></div></div>
  <div class="card" style="margin-top:16px"><div class="chips" style="justify-content:space-between"><h3 style="margin:0">2. Content from ${esc(st.src)}</h3><div class="seg"><button class="${st.mode==='package'?'on':''}" data-m="package">Whole package</button><button class="${st.mode==='iflows'?'on':''}" data-m="iflows">Selected iFlows</button></div></div>
  ${st.err?`<div class="err">${esc(st.err)}</div>`:''}<div class="pkl">${pk.map(p=>`<div class="pkrow ${st.pkg===p.Id?'on':''}" data-p="${esc(p.Id)}"><div class="chips" style="justify-content:space-between"><div><b>${esc(p.Name)}</b><div class="tiny">${esc(p.Id)} - v${esc(p.Version)}</div></div><div class="chips"><span class="chip l">${p.counts.iflows} iFlows</span><span class="chip">${p.counts.valuemaps} VM</span><span class="chip">${p.counts.scripts} scripts</span></div></div>
  ${st.pkg===p.Id&&st.mode==='iflows'?`<div class="ifl">${p.artifacts.iflows.map(a=>`<label class="tog"><input type="checkbox" class="iflc" value="${esc(a.Id)}" ${st.arts.includes(a.Id)?'checked':''}><span>${esc(a.Name)} <span class="tiny">${esc(a.Id)} v${esc(a.Version)}</span></span></label>`).join('')||'<div class="tiny">No iFlows</div>'}</div>`:''}</div>`).join('')||'<div class="empty">No packages in this tenant.</div>'}</div></div>
  <div class="card" style="margin-top:16px"><h3>3. Analyze and run</h3><div class="chips"><label class="tog"><input type="checkbox" id="trD" ${st.deploy?'checked':''}><span>Deploy and verify</span></label><label class="tog"><input type="checkbox" id="trP" ${st.deps?'checked':''}><span>Include missing value mappings and scripts</span></label>${st.tgt&&T(st.tgt).demo?`<label class="tog"><input type="checkbox" id="trS" ${st.sim?'checked':''}><span>Demo: simulate failed health check (shows rollback)</span></label>`:''}</div>
  <div class="chips" style="margin:10px 0"><button class="btn lil" id="trA" ${st.pkg&&st.tgt&&!st.busy?'':'disabled'}>Analyze</button><button class="btn" id="trGo" ${st.plan&&st.plan.ready&&!st.busy?'':'disabled'}>${st.needs?'Request approval':'Start transport'}</button></div>
  ${st.busy?'<div class="skel"></div><div class="skel" style="width:60%"></div>':''}<div>${planHtml(st.plan)}</div>
  ${st.needs?`<div class="banner w" style="margin:10px 0">Four-eyes rule for ${esc(T(st.tgt).stage)}: a different person with the Approve permission must approve this before it runs.</div>`:''}<div class="err" id="trErr"></div></div>
  <div class="card" style="margin-top:16px"><h3>Recent transports</h3>${jl.length?jl.map(j=>`<div class="row" style="cursor:pointer" data-a="openJob" data-p="${j.id}"><span class="chip ${jchip(j.status)}">${statusLabel(j.status)}</span><b style="flex:1">${esc(j.title)}</b><span class="tiny">${ago(j.created)}</span></div>`).join(''):'<div class="sub">None yet.</div>'}</div>`;
  $$('.opt',el).forEach(o=>o.onclick=()=>{if(o.classList.contains('dis'))return;if(o.dataset.r==='src'){st.src=o.dataset.t;st.pkg=null;st.arts=[];st.tgt=null}else st.tgt=o.dataset.t;st.plan=null;st.needs=false;st.err='';rTrans()});
  $$('.seg button',el).forEach(b=>b.onclick=()=>{st.mode=b.dataset.m;st.plan=null;rTrans()});
  $$('.pkrow',el).forEach(r=>r.onclick=e=>{if(e.target.closest('.ifl'))return;st.pkg=r.dataset.p;st.arts=[];st.plan=null;st.needs=false;rTrans()});
  $$('.iflc',el).forEach(c=>c.onchange=()=>{st.arts=$$('.iflc:checked',el).map(x=>x.value);st.plan=null;$('#trA').disabled=!st.arts.length;$('#trGo').disabled=true});
  ['trD','trP','trS'].forEach(id=>{const e=$('#'+id);if(e)e.onchange=()=>{st.deploy=$('#trD').checked;st.deps=$('#trP').checked;st.sim=$('#trS')?$('#trS').checked:false;st.plan=null;rTrans()}});
  const body=()=>({source:st.src,target:st.tgt,package_id:st.pkg,artifacts:st.mode==='iflows'?st.arts.map(i=>({kind:'iflow',id:i})):null,deploy:st.deploy,include_deps:st.deps,simulate_failure:st.sim});
  if(st.mode==='iflows'&&st.pkg&&!st.arts.length&&$('#trA'))$('#trA').disabled=true;
  $('#trA').onclick=async()=>{st.busy=true;st.err='';rTrans();try{const r=await api('/api/plan',body());st.plan=r.plan;st.needs=r.needs_approval}catch(e){st.err=e.message}st.busy=false;rTrans()};
  $('#trGo').onclick=async()=>{$('#trGo').disabled=true;try{await startJob('move',body());S.pkData={}}catch(e){$('#trErr').textContent=e.message;$('#trGo').disabled=false}}}

/* ---------- iFlow builder ---------- */
let TPL=null;
const GEN=['Understanding the requirement','Designing the integration flow','Generating Groovy scripts','Creating value mappings','Configuring security material','Writing documentation','Running quality checks'];
function flowViz(b){const sp=b.spec,items=[sp.schedule?'Timer '+sp.schedule.n+' '+sp.schedule.unit:'HTTPS in',sp.sender_label,'Groovy enrich',sp.convert==='xml2json'?'XML to JSON':sp.convert==='json2xml'?'JSON to XML':null,sp.receiver_label+' ('+sp.auth+')'].filter(Boolean);
  return `<div class="fviz">${items.map((x,i)=>`<div class="fn" style="animation-delay:${i*120}ms">${esc(x)}</div>${i<items.length-1?'<div class="fa"></div>':''}`).join('')}</div><div class="fviz err2"><div class="fn bad">Exception subprocess</div><div class="fa"></div><div class="fn bad">Capture error</div><div class="fa"></div><div class="fn bad">Escalate</div></div>`}
function dl(url,name){return fetch(url,{headers:authHeaders()}).then(r=>{if(!r.ok)throw new Error('Download failed');return r.blob()}).then(b=>{const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),2000)}).catch(e=>toast(e.message,'bad'))}
async function openHtml(url){try{const r=await fetch(url,{headers:authHeaders()});if(!r.ok)throw new Error('Not available');const b=await r.blob();window.open(URL.createObjectURL(b),'_blank')}catch(e){toast(e.message,'bad')}}
async function rBuild(){
  const el=$('#v-build');
  if(!TPL){try{TPL=await api('/api/builder/templates')}catch(e){TPL={templates:[],systems:{}}}}
  const sys=Object.entries(TPL.systems);
  el.innerHTML=`<div class="head"><div class="grow"><h2>iFlow Builder</h2><div class="sub">Describe the integration in plain language. You get the iFlow, Groovy scripts, value mapping, security parameters and documentation as one package.</div></div></div>
  <div class="grid two" style="grid-template-columns:1fr 1.25fr;margin-top:0"><div><div class="card"><h3>Requirement</h3><textarea id="bq" rows="5" placeholder="Read employee data from SuccessFactors, convert XML to JSON, send it to Salesforce with OAuth, with exception handling">${esc(S.bprompt||'')}</textarea>
  <div class="f2" style="margin-top:8px"><div><label class="tiny">Sender</label><select id="bs"><option value="auto">Auto detect</option>${sys.map(([k,v])=>`<option value="${k}">${esc(v)}</option>`).join('')}</select></div><div><label class="tiny">Receiver</label><select id="br"><option value="auto">Auto detect</option>${sys.map(([k,v])=>`<option value="${k}">${esc(v)}</option>`).join('')}</select></div>
  <div><label class="tiny">Authentication</label><select id="ba"><option value="auto">Auto</option><option value="oauth">OAuth 2.0</option><option value="basic">Basic</option><option value="cert">Client certificate</option></select></div><div><label class="tiny">Conversion</label><select id="bc"><option value="auto">Auto</option><option value="xml2json">XML to JSON</option><option value="json2xml">JSON to XML</option><option value="none">None</option></select></div></div>
  <div class="chips" style="margin-top:12px"><button class="btn" id="bgo">Generate package</button></div></div>
  <div class="card" style="margin-top:16px"><h3>Start from a template</h3><div class="tpl">${TPL.templates.map(t=>`<div class="tp" data-p="${esc(t.prompt)}"><b>${esc(t.title)}</b><div class="chips" style="margin-top:6px">${t.tags.map(x=>`<span class="chip l">${esc(x)}</span>`).join('')}</div></div>`).join('')}</div></div></div>
  <div id="bout">${S.build&&S.build.files?bOut(S.build):`<div class="card empty"><div class="orb"></div>Your generated package appears here.<div class="tiny" style="margin-top:8px">Generated content is a draft for a developer to review. It always lands in DEV first.</div></div>`}</div></div>`;
  $$('.tp',el).forEach(t=>t.onclick=()=>{$('#bq').value=t.dataset.p;S.bprompt=t.dataset.p;$('#bq').focus()});
  $('#bq').oninput=()=>S.bprompt=$('#bq').value;
  $('#bgo').onclick=async()=>{const q=$('#bq').value.trim();if(q.length<10)return toast('Describe the integration in a sentence','bad');
    $('#bgo').disabled=true;$('#bout').innerHTML=`<div class="card"><h3>Generating</h3>${GEN.map((g,i)=>`<div class="step" id="gs${i}"><div class="ic">${i+1}</div><div><b>${g}</b></div></div>`).join('')}</div>`;
    let i=0;const tm=setInterval(()=>{if(i>0)$('#gs'+(i-1)).className='step ok';if(i<GEN.length){$('#gs'+i).className='step running'}i++},380);
    const t0=Date.now();try{const ov={sender:$('#bs').value,receiver:$('#br').value,auth:$('#ba').value,convert:$('#bc').value};const r=await api('/api/builder/generate',{requirement:q,...ov});await sleep(Math.max(0,GEN.length*380+200-(Date.now()-t0)));clearInterval(tm);S.build=r;$('#bout').innerHTML=bOut(r);wireOut(r)}catch(e){clearInterval(tm);$('#bout').innerHTML=`<div class="card"><span style="color:var(--bad)">${esc(e.message)}</span></div>`}$('#bgo').disabled=false};
  if(S.build&&S.build.files)wireOut(S.build)}
function bOut(b){const f=Object.keys(b.files);S.bfile=S.bfile&&b.files[S.bfile]?S.bfile:f[0];
  return `<div class="card nf"><div class="chips" style="justify-content:space-between"><div><h3 style="margin:0">${esc(b.iflow_id)}</h3><div class="tiny">Package ${esc(b.package_id)} - ${esc(b.spec.sender_label)} to ${esc(b.spec.receiver_label)}</div></div><span class="chip l">AI generated draft</span></div>${flowViz(b)}
  <div class="lint">${b.lint.map(l=>`<div class="issue"><i style="color:${l.level==='ok'?'var(--ok)':l.level==='warn'?'var(--warn)':'var(--bad)'}">${l.level==='ok'?'\u2713':l.level==='warn'?'!':'\u2715'}</i><span>${esc(l.text)}</span></div>`).join('')}</div>
  <div class="tabs">${f.map(n=>`<button class="${n===S.bfile?'on':''}" data-f="${esc(n)}">${esc(n)}</button>`).join('')}</div><pre class="code" id="bcode">${esc(b.files[S.bfile])}</pre>
  <div class="chips" style="margin-top:12px"><button class="btn lil" id="bdl">Download package (zip)</button><button class="btn ghost" id="bcp">Copy file</button><select id="bt" style="width:180px">${S.tenants.filter(t=>t.stage==='DEV').map(t=>`<option>${esc(t.name)}</option>`).join('')||'<option value="">No DEV tenant</option>'}</select><button class="btn" id="bim" ${S.tenants.some(t=>t.stage==='DEV')?'':'disabled'}>Import into DEV</button></div>
  <div class="tiny" style="margin-top:8px">Import creates the package, script collection, value mapping and iFlow. It does not deploy: create the credential aliases first, then review in the iFlow designer and move DEV to QA from Transport.</div></div>`}
function wireOut(b){const o=$('#bout');$$('.tabs button',o).forEach(x=>x.onclick=()=>{S.bfile=x.dataset.f;$$('.tabs button',o).forEach(y=>y.classList.toggle('on',y===x));$('#bcode').textContent=b.files[S.bfile]});
  $('#bdl').onclick=()=>dl('/api/builder/'+b.id+'/download',b.iflow_id+'.zip');$('#bcp').onclick=()=>{navigator.clipboard&&navigator.clipboard.writeText(b.files[S.bfile]);toast('Copied','ok')};
  $('#bim').onclick=async()=>{const tn=$('#bt').value;if(!tn)return;$('#bim').disabled=true;try{const r=await api('/api/builder/'+b.id+'/import',{tenant:tn});toast('Imported '+r.artifacts.length+' artifacts into '+tn,'ok');S.pkData={}}catch(e){toast(e.message,'bad')}$('#bim').disabled=false}}

/* ---------- agent / MCP ---------- */
async function rAgent(){
  const el=$('#v-agent');el.innerHTML='<div class="skel"></div>';
  let d;try{d=await api('/api/agent/tools')}catch(e){el.innerHTML=`<div class="card">${esc(e.message)}</div>`;return}
  const url=location.origin+'/mcp',cfg=JSON.stringify({mcpServers:{'cpi-copilot':{url,headers:{Authorization:'Bearer <your access key>'}}}},null,2);
  el.innerHTML=`<div class="head"><div class="grow"><h2>Agent and MCP</h2><div class="sub">One set of tools powers the copilot chat and any MCP client. Changes always need confirm=true, and gated stages need an approver.</div></div></div>
  <div class="grid two" style="margin-top:0"><div class="card"><h3>MCP server</h3><div class="row"><span class="chip ok">Live</span><code>${esc(url)}</code></div><div class="tiny" style="margin:8px 0">Protocol: Model Context Protocol, JSON-RPC 2.0 over HTTP. Use it from Claude Desktop, VS Code, SAP Joule or any agent framework.</div><pre class="cmd">${esc(cfg)}</pre><div class="chips"><button class="btn ghost sm" id="cpm">Copy client config</button></div></div>
  <div class="card"><h3>Use with SAP Joule Studio</h3><ol class="tiny" style="margin:0;padding-left:18px;line-height:1.8"><li>In Joule Studio, add an MCP server and paste the URL on the left</li><li>Authentication: bearer token = your access key (or an API gateway in front)</li><li>Joule agents now call the ${TOOLN} tools below: monitor, analyze, transport, retry, generate</li><li>Writes always need confirm=true and an approver for UAT, PRE-PROD and PROD</li></ol><h3 style="margin-top:14px">Live tool calls</h3><div class="feed" id="calls" style="max-height:230px">${callsHtml(d.calls)}</div></div></div>
  <div class="card" style="margin-top:16px"><h3>Tools (${d.tools.length})</h3><div class="tools">${d.tools.map(t=>`<div class="tool"><div class="chips" style="justify-content:space-between"><b>${esc(t.name)}</b><span class="chip ${t.write?'w':'ok'}">${t.write?'changes data':'read only'}</span></div><div class="tiny" style="margin:6px 0">${esc(t.description)}</div><div class="tiny">${Object.keys(t.inputSchema.properties).map(k=>`<span class="chip">${esc(k)}${(t.inputSchema.required||[]).includes(k)?'*':''}</span>`).join(' ')}</div><button class="btn ghost sm" style="margin-top:8px" data-t="${esc(t.name)}">Try it</button></div>`).join('')}</div></div>`;
  $('#cpm').onclick=()=>{navigator.clipboard&&navigator.clipboard.writeText(cfg);toast('Copied','ok')};
  $$('.tool button',el).forEach(b=>b.onclick=()=>{const t=d.tools.find(x=>x.name===b.dataset.t);const ex={};Object.entries(t.inputSchema.properties).forEach(([k,v])=>{if((t.inputSchema.required||[]).includes(k))ex[k]=v.type==='boolean'?false:v.type==='array'?[]:(k.includes('tenant')||k==='source'||k==='target')?(S.tenants[0]||{}).name||'':''});
    openModal(`<h3>${esc(t.name)}</h3><div class="sub">${esc(t.description)}</div><label>Arguments (JSON)</label><textarea id="targ" rows="5" style="font-family:Consolas,monospace">${esc(JSON.stringify(ex,null,2))}</textarea><pre class="code" id="tout" style="max-height:260px;display:none"></pre><div class="acts"><button class="btn ghost" data-a="closeModal">Close</button><button class="btn" id="trun">Run</button></div>`);
    $('#trun').onclick=async()=>{let a;try{a=JSON.parse($('#targ').value||'{}')}catch(e){return toast('Invalid JSON','bad')}$('#trun').disabled=true;try{const r=await api('/api/agent/call',{name:t.name,args:a});$('#tout').style.display='block';$('#tout').textContent=JSON.stringify(r,null,2).slice(0,6000)}catch(e){$('#tout').style.display='block';$('#tout').textContent=e.message}$('#trun').disabled=false}});
  S.autoT=setInterval(async()=>{if(S.view!=='agent')return;try{const x=await api('/api/agent/tools');$('#calls').innerHTML=callsHtml(x.calls)}catch(e){}},4000)}
function callsHtml(c){return c.length?c.slice().reverse().slice(0,20).map(x=>`<div class="ev"><i style="background:${x.ok?'var(--ok)':'var(--bad)'}"></i><div><b>${esc(x.tool)}</b> <span class="chip">${esc(x.via)}</span> ${x.write?'<span class="chip w">write</span>':''}<div class="tiny">${esc(JSON.stringify(x.args))} - ${x.ms} ms - ${ago(x.ts)}</div></div></div>`).join(''):'<div class="sub">No calls yet. Ask the copilot something or try a tool.</div>'}


/* =================== v0.7: insight, approvals, drift, trust, panel =================== */
function diagHtml(checks){
  const tok=checks.find(c=>c.scopes);
  return `${tok?`<div class="tiny" style="margin-bottom:8px">Roles granted to this service instance: ${tok.scopes.length?tok.scopes.map(s=>`<span class="chip l">${esc(s)}</span>`).join(' '):'none visible in the token'}</div>`:''}<div class="tw" style="max-height:340px"><table><tr><th>Check</th><th>Result</th><th>ms</th><th>Rows</th><th>Needs role</th><th>Detail</th></tr>${checks.map(c=>`<tr><td>${esc(c.name)}</td><td><span class="chip ${c.ok?'ok':c.status===403?'w':'b'}">${c.ok?'OK':c.status===403?'Refused (403)':c.status===404?'Not found':'Failed'+(c.status?' ('+c.status+')':'')}</span></td><td>${c.ms}</td><td>${c.rows==null?'-':c.rows}</td><td class="tiny">${esc(c.role||'-')}</td><td class="tiny">${esc(c.ok?'':c.message)}</td></tr>`).join('')}</table></div>`}
async function diagModal(name){
  openModal(`<h3>Diagnostics: ${esc(name)}</h3><div class="sub">Probing every API the platform uses...</div><div class="skel"></div><div class="skel" style="width:60%"></div>`);
  try{const r=await api('/api/tenants/'+encodeURIComponent(name)+'/diagnostics'),bad=r.checks.filter(c=>!c.ok);
    openModal(`<h3>Diagnostics: ${esc(name)} <span class="chip ${bad.length?'w':'ok'}">${bad.length?bad.length+' issue(s)':'all checks passed'}</span></h3><div class="sub">Each check calls one Integration Suite API with the tenant's own credentials. Refused means the service instance is missing a role.</div>${diagHtml(r.checks)}
    ${bad.some(c=>c.status===403)?`<div class="banner w" style="margin-top:12px"><b>How to fix a refused check</b><pre class="cmd">cf update-service ${esc(name)} -c cpi-roles-ext.json\ncf unbind-service cpi-copilot-api ${esc(name)}\ncf bind-service cpi-copilot-api ${esc(name)}\ncf restage cpi-copilot-api</pre><div class="tiny">The role must be in the token, so the binding is recreated. If the update is rejected, remove the role name that your tenant does not know from cpi-roles-ext.json.</div></div>`:''}
    ${r.checks.every(c=>c.ok)?'<div class="banner ok" style="margin-top:12px">Everything is readable. If counts are still zero, the tenant simply has no traffic or no deployed artifacts in the selected window.</div>':''}<div class="acts"><button class="btn ghost" data-a="closeModal">Close</button><button class="btn" id="dgAgain">Run again</button></div>`);
    $('#dgAgain').onclick=()=>diagModal(name)}catch(e){openModal(`<h3>Diagnostics: ${esc(name)}</h3><div class="err">${esc(e.message)}</div><div class="acts"><button class="btn ghost" data-a="closeModal">Close</button></div>`)}}
function reviewHtml(r,compact){
  const lv={error:['\u2715','var(--bad)'],warn:['!','var(--warn)'],info:['i','var(--lil2)']},col=r.score>=85?'#22c55e':r.score>=60?'#f59e0b':'#ff4d5e';
  const fl=compact?r.findings.slice(0,5):r.findings;
  return `<div class="rv"><div class="rvh">${ring(r.score,col)}<div><div class="tiny">${esc(r.tenant||'')} ${r.package_id?'/ '+esc(r.package_id):''}</div><b>${esc(r.id)}</b><div class="chips" style="margin-top:6px"><span class="chip b">${r.counts.error} errors</span><span class="chip w">${r.counts.warn} warnings</span><span class="chip l">${r.counts.info} notes</span></div></div></div>
  <p style="margin:10px 0;white-space:normal">${esc(r.summary)}</p>
  ${r.steps.length?`<div class="chips" style="margin-bottom:8px">${r.steps.filter(s=>!['startEvent','endEvent'].includes(s.type)).slice(0,compact?8:30).map(s=>`<span class="chip">${esc(s.name)}</span>`).join('<span class="tiny">\u2192</span>')}</div>`:''}
  ${fl.length?fl.map(f=>`<div class="issue"><i style="color:${lv[f.level][1]}">${lv[f.level][0]}</i><span>${esc(f.text)}</span></div>`).join(''):'<div class="issue"><i style="color:var(--ok)">\u2713</i><span>No findings</span></div>'}
  ${compact?'':`${r.adapters.length?`<h3 style="margin-top:14px">Adapters</h3><div class="tw" style="max-height:200px"><table><tr><th>Direction</th><th>Adapter</th><th>Protocol</th><th>Address</th><th>Auth</th><th>Credential</th></tr>${r.adapters.map(a=>`<tr><td>${esc(a.direction)}</td><td>${esc(a.adapter)}</td><td>${esc(a.protocol)}</td><td class="tiny">${esc(a.address)}</td><td>${esc(a.auth)}</td><td>${esc(a.credential)}</td></tr>`).join('')}</table></div>`:''}
  ${r.credentials.length||r.parameters.length?`<div class="chips" style="margin-top:10px">${r.credentials.map(c=>`<span class="chip ok" title="credential alias">${esc(c)}</span>`).join('')}${r.parameters.map(c=>`<span class="chip l" title="externalised parameter">{{${esc(c)}}}</span>`).join('')}</div>`:''}
  ${r.scripts.length?`<div class="tiny" style="margin-top:10px">Scripts: ${r.scripts.map(s=>esc(s.name)+' ('+s.lines+' lines)').join(', ')}</div>`:''}`}</div>`}
async function explainModal(t,iflow){
  openModal(`<h3>Explain and review: ${esc(iflow)}</h3><div class="sub">Exporting the iFlow and analysing it...</div><div class="skel"></div><div class="skel" style="width:70%"></div>`);
  try{const r=await api('/api/iflow/explain',{tenant:t,iflow});openModal(`<h3>Explain and review</h3>${reviewHtml(r)}<div class="tiny" style="margin-top:10px">Static analysis of the exported artifact. Nothing was changed on the tenant.</div><div class="acts"><button class="btn ghost" id="rvCp">Copy summary</button><button class="btn" data-a="closeModal">Close</button></div>`);
    $('#rvCp').onclick=()=>{navigator.clipboard&&navigator.clipboard.writeText(r.summary+'\n'+r.findings.map(f=>'- ['+f.level+'] '+f.text).join('\n'));toast('Copied','ok')}}
  catch(e){openModal(`<h3>Explain and review</h3><div class="err">${esc(e.message)}</div><div class="acts"><button class="btn ghost" data-a="closeModal">Close</button></div>`)}}
function traceHtml(r){
  const mx=Math.max(1,...r.steps.map(s=>s.ms||0)),L=r.log;
  return `<div class="rv"><div class="chips"><span class="chip ${L.Status==='COMPLETED'?'ok':L.Status==='FAILED'?'b':'w'}">${esc(L.Status)}</span><b>${esc(L.IntegrationFlowName)}</b><span class="tiny">${esc((L.LogEnd||'').replace('T',' ').replace('Z',' UTC'))} - ${L.ProcessingMs==null?'':L.ProcessingMs+' ms'}</span></div>
  <div class="tiny" style="margin:6px 0">Message ${esc(r.guid)}${L.CorrelationId?' | correlation '+esc(L.CorrelationId):''}${L.ApplicationMessageId?' | application id '+esc(L.ApplicationMessageId):''}</div>
  ${r.error?`<pre class="code" style="max-height:140px;border-radius:10px">${esc(r.error)}</pre>`:''}
  ${(r.headers||[]).length?`<div class="chips" style="margin:8px 0">${r.headers.map(h=>`<span class="chip l">${esc(h.name)}: ${esc(h.value)}</span>`).join('')}</div>`:''}
  ${r.steps.length?`<h3 style="margin:12px 0 6px">Step timeline</h3>${r.steps.map(s=>`<div class="row"><span style="width:150px;overflow:hidden;text-overflow:ellipsis">${esc(s.step)}</span><div class="bar"><i data-w="${Math.max(2,(s.ms||0)/mx*100)}%" style="background:${s.status==='FAILED'?'var(--red)':s.status==='COMPLETED'?'var(--lil)':'var(--bd)'}"></i></div><span class="tiny" style="width:60px;text-align:right">${s.ms==null?'-':s.ms+' ms'}</span><span class="chip ${s.status==='FAILED'?'b':s.status==='COMPLETED'?'ok':''}" style="width:90px;text-align:center">${esc(s.status||'')}</span></div>`).join('')}`:''}
  ${Object.keys(r.partial||{}).length?`<div class="tiny" style="margin-top:8px;color:var(--warn)">Not all parts could be read: ${Object.entries(r.partial).map(([k,v])=>k+' ('+esc(String(v).slice(0,80))+')').join('; ')}</div>`:''}</div>`}
async function traceModal(t,guid){
  openModal(`<h3>Message trace</h3><div class="skel"></div><div class="skel" style="width:60%"></div>`);
  try{const r=await api('/api/tenants/'+encodeURIComponent(t)+'/messages/'+encodeURIComponent(guid));openModal(`<h3>Message trace</h3>${traceHtml(r)}<div class="acts"><button class="btn ghost" data-a="closeModal">Close</button>${r.log&&r.log.IntegrationFlowName?`<button class="btn lil" id="trEx">Explain iFlow</button>`:''}</div>`);animateAll($('#mbox'));if($('#trEx'))$('#trEx').onclick=()=>explainModal(t,r.log.IntegrationFlowName)}
  catch(e){openModal(`<h3>Message trace</h3><div class="err">${esc(e.message)}</div><div class="acts"><button class="btn ghost" data-a="closeModal">Close</button></div>`)}}
async function drawSearch(t){
  const body=$('#fbody'),f=S.srch=S.srch||{iflow:'',status:'',corr:'',app:'',guid:'',hours:24};
  body.innerHTML=`<div class="card"><div class="f4"><div><label class="tiny">iFlow (exact id)</label><input id="sI" value="${esc(f.iflow)}"></div><div><label class="tiny">Status</label><select id="sS">${['','COMPLETED','FAILED','RETRY','ESCALATED','PROCESSING','ABANDONED'].map(x=>`<option value="${x}" ${f.status===x?'selected':''}>${x||'Any'}</option>`).join('')}</select></div><div><label class="tiny">Correlation id</label><input id="sC" value="${esc(f.corr)}"></div><div><label class="tiny">Application message id</label><input id="sA" value="${esc(f.app)}"></div><div><label class="tiny">Message guid</label><input id="sG" value="${esc(f.guid)}"></div><div><label class="tiny">Time window</label><select id="sH">${[[1,'1 hour'],[6,'6 hours'],[24,'24 hours'],[72,'3 days'],[168,'7 days']].map(([v,l])=>`<option value="${v}" ${+f.hours===v?'selected':''}>${l}</option>`).join('')}</select></div></div><div class="chips" style="margin-top:12px"><button class="btn" id="sGo">Search</button><span class="tiny">Click a row for the full trace with step timeline.</span></div><div id="sRes" style="margin-top:12px"></div></div>`;
  const run=async()=>{Object.assign(f,{iflow:$('#sI').value.trim(),status:$('#sS').value,corr:$('#sC').value.trim(),app:$('#sA').value.trim(),guid:$('#sG').value.trim(),hours:$('#sH').value});
    const q=new URLSearchParams({iflow:f.iflow,status:f.status,correlation_id:f.corr,app_msg_id:f.app,guid:f.guid,hours:f.hours,top:100});$('#sRes').innerHTML='<div class="skel"></div>';
    try{const r=(await api('/api/tenants/'+encodeURIComponent(t)+'/messages?'+q)).messages;$('#sRes').innerHTML=r.length?`<div class="tiny" style="margin-bottom:6px">${r.length} message(s)${r.length>=100?' (first 100)':''}</div><div class="tw" style="max-height:440px"><table><tr><th>Status</th><th>Interface</th><th>End time</th><th>ms</th><th>Correlation</th><th>Message</th></tr>${r.map(m=>`<tr class="clk" data-g="${esc(m.MessageGuid)}"><td><span class="chip ${m.Status==='COMPLETED'?'ok':m.Status==='FAILED'?'b':'w'}">${esc(m.Status)}</span></td><td>${esc(m.IntegrationFlowName)}</td><td>${esc((m.LogEnd||'').replace('T',' ').replace('Z',''))}</td><td>${m.ProcessingMs==null?'-':m.ProcessingMs}</td><td class="tiny">${esc(m.CorrelationId||'')}</td><td class="tiny">${esc(String(m.MessageGuid).slice(0,16))}</td></tr>`).join('')}</table></div>`:'<div class="sub">No messages match. The filters are combined with AND.</div>';
      $$('#sRes tr[data-g]').forEach(r=>r.onclick=()=>traceModal(t,r.dataset.g))}catch(e){$('#sRes').innerHTML=`<span style="color:var(--bad)">${esc(e.message)}</span>`}};
  $('#sGo').onclick=run;$$('#fbody input').forEach(i=>i.onkeydown=e=>{if(e.key==='Enter')run()});run()}

async function rDrift(){
  const el=$('#v-drift');
  if(S.tenants.length<2){el.innerHTML=`<div class="empty card"><div class="orb"></div><h2>Landscape drift needs two tenants</h2><p>It compares package and artifact versions across DEV, QA, UAT and PROD. Connect a second tenant or load the demo landscape.</p><div class="chips" style="justify-content:center"><button class="btn" data-a="go" data-p="tenants">How to connect</button><button class="btn ghost" data-a="loadDemo">Load demo tenants</button></div></div>`;return}
  el.innerHTML=`<div class="head"><div class="grow"><h2>Landscape drift</h2><div class="sub">Which artifacts differ between tenants, and what has not been promoted yet.</div></div></div><div class="card"><div class="skel"></div><div class="skel" style="width:70%"></div></div>`;
  let d;try{d=await api('/api/drift')}catch(e){el.innerHTML=`<div class="card" style="color:var(--bad)">${esc(e.message)}</div>`;return}
  const f=S.driftF=S.driftF||{state:'',q:''},T2=d.tenants,rows=d.rows.filter(r=>(!f.state||r.state===f.state)&&(!f.q||(r.id+r.name+r.package).toLowerCase().includes(f.q.toLowerCase()))),sm=d.summary,tot=sm.in_sync+sm.drift+sm.missing;
  const vk=v=>String(v||'0').split(/[.\-]/).map(x=>+x||0);
  const behind=(v,l)=>{const a=vk(v),b=vk(l);for(let i=0;i<Math.max(a.length,b.length);i++){if((a[i]||0)!==(b[i]||0))return(a[i]||0)<(b[i]||0)}return false};
  el.innerHTML=`<div class="head"><div class="grow"><h2>Landscape drift</h2><div class="sub">${tot} artifacts across ${T2.length} tenants. Versions are compared, content is not.</div></div><button class="btn ghost sm" id="drR">Refresh</button></div>
  ${Object.keys(d.errors||{}).length?`<div class="banner w" style="margin-bottom:12px"><b>Some tenants could not be read:</b> ${Object.entries(d.errors).map(([k,v])=>`<div class="tiny">${esc(k)}: ${esc(v)}</div>`).join('')}</div>`:''}
  <div class="grid kpis"><div class="card kpi" style="--c:var(--lil)"><div class="k-ico">A</div><div class="k-val" data-count="${tot}">0</div><div class="k-lab">Artifacts</div></div><div class="card kpi" style="--c:var(--ok)"><div class="k-ico">=</div><div class="k-val" data-count="${sm.in_sync}">0</div><div class="k-lab">In sync</div></div><div class="card kpi" style="--c:var(--warn)"><div class="k-ico">\u2260</div><div class="k-val" data-count="${sm.drift}">0</div><div class="k-lab">Versions differ</div></div><div class="card kpi" style="--c:var(--red)"><div class="k-ico">-</div><div class="k-val" data-count="${sm.missing}">0</div><div class="k-lab">Missing in a tenant</div></div></div>
  <div class="card" style="margin-top:16px"><div class="chips" style="justify-content:space-between;margin-bottom:10px"><div class="seg">${[['','All'],['drift','Versions differ'],['missing','Missing'],['in_sync','In sync']].map(([k,l])=>`<button class="${f.state===k?'on':''}" data-st="${k}">${l}</button>`).join('')}</div><input id="drQ" placeholder="Filter by package or artifact" style="width:260px" value="${esc(f.q)}"></div>
  <div class="tw" style="max-height:560px"><table><tr><th>Package</th><th>Type</th><th>Artifact</th>${T2.map(t=>`<th>${esc(t.name)}<div class="tiny">${t.stage}</div></th>`).join('')}<th>State</th></tr>${rows.map(r=>`<tr><td>${esc(r.package)}</td><td>${esc(r.kind)}</td><td>${esc(r.name)}<div class="tiny">${esc(r.id)}</div></td>${T2.map(t=>{const v=r.versions[t.name];return `<td>${v?`<span class="chip ${behind(v,r.latest)?'w':'ok'}">${esc(v)}</span>`:'<span class="chip">-</span>'}</td>`}).join('')}<td><span class="chip ${r.state==='in_sync'?'ok':r.state==='drift'?'w':'b'}">${r.state==='in_sync'?'In sync':r.state==='drift'?'Versions differ':'Missing'}</span></td></tr>`).join('')||`<tr><td colspan="${T2.length+4}" class="tiny">Nothing matches</td></tr>`}</table></div><div class="tiny" style="margin-top:8px">Missing usually means not promoted yet. Open Transport to move it along the promotion path.</div></div>`;
  $$('[data-st]',el).forEach(b=>b.onclick=()=>{f.state=b.dataset.st;rDrift()});const q=$('#drQ');q.oninput=()=>{f.q=q.value;clearTimeout(S._dq);S._dq=setTimeout(()=>rDrift().then(()=>{const n=$('#drQ');if(n){n.focus();n.setSelectionRange(99,99)}}),300)};
  $('#drR').onclick=()=>rDrift();animateAll(el)}

async function rApprovals(){
  const el=$('#v-approvals');let a;try{a=S.approvals=await api('/api/approvals')}catch(e){el.innerHTML=`<div class="card" style="color:var(--bad)">${esc(e.message)}</div>`;return}
  badge(a);const L=a.approvals,sc={PENDING:'w',APPROVED:'ok',REJECTED:'b',EXPIRED:'',FAILED:'b',INVALID:'b'};
  el.innerHTML=`<div class="head"><div class="grow"><h2>Approvals</h2><div class="sub">Four-eyes control for UAT, PRE-PROD and PROD. The requester cannot approve their own change, the parameters are locked at request time, and agents cannot approve.</div></div></div>
  ${a.can_approve?'':'<div class="banner w" style="margin-bottom:14px">You can see requests, but only a signed-in person with the Approve permission can decide. Use the approver identity.</div>'}
  <div class="grid" style="gap:12px">${L.map(r=>{const can=r.status==='PENDING'&&a.can_approve&&(S.me.sandbox||r.requester!==S.me.user);
  return `<div class="card"><div class="chips" style="justify-content:space-between"><b>${esc(r.title)}</b><span><span class="chip l">${esc(r.stage)}</span> <span class="chip ${sc[r.status]||''}">${esc(r.status)}</span></span></div>
  <div class="tiny" style="margin:6px 0">Requested by <b>${esc(r.requester)}</b> ${ago(r.created)}${r.status==='PENDING'?' - expires '+new Date(r.expires*1000).toLocaleString():''}${r.decided_by?' - decided by <b>'+esc(r.decided_by)+'</b> '+ago(r.decided_at):''}${r.reason?' - '+esc(r.reason):''}</div>
  <div class="chips">${Object.entries(r.summary||{}).map(([k,v])=>`<span class="chip">${esc(k)}: ${esc(v)}</span>`).join('')}<span class="chip" title="Parameters are hash-locked">lock ${esc(r.params_hash.slice(0,8))}</span></div>
  <div class="chips" style="margin-top:10px">${can?`<button class="btn" data-ap="${r.id}" data-d="1">Approve</button><button class="btn ghost" data-ap="${r.id}" data-d="0">Reject</button>`:r.status==='PENDING'?`<span class="tiny">${r.requester===S.me.user?'Waiting for a different person to approve':'You do not have the Approve permission'}</span>`:''}${S.me.sandbox&&r.status==='PENDING'?'<span class="tiny">Sandbox: you act as a simulated approver</span>':''}${r.job?`<button class="btn lil sm" data-a="openJob" data-p="${r.job}">Open operation</button>`:''}</div></div>`}).join('')||'<div class="card empty"><div class="orb"></div>No approval requests yet.<div class="tiny" style="margin-top:8px">A move to UAT, PRE-PROD or PROD, and retries in PROD, create a request here.</div></div>'}</div>`;
  $$('[data-ap]',el).forEach(b=>b.onclick=()=>{const ok=b.dataset.d==='1';openModal(`<h3>${ok?'Approve':'Reject'} request</h3><div class="sub">${esc((L.find(x=>x.id===b.dataset.ap)||{}).title||'')}</div><label>Reason (optional)</label><input id="apR" maxlength="300"><div class="err" id="apE"></div><div class="acts"><button class="btn ghost" data-a="closeModal">Cancel</button><button class="btn" id="apGo">${ok?'Approve and run':'Reject'}</button></div>`);
    $('#apGo').onclick=async()=>{$('#apGo').disabled=true;try{const r=await api('/api/approvals/'+b.dataset.ap+'/decision',{approve:ok,reason:$('#apR').value});closeModal();toast(ok?'Approved, operation started':'Rejected','ok');if(ok&&r.job){S.selJob=r.job;go('ops')}else rApprovals()}catch(e){$('#apE').textContent=e.message;$('#apGo').disabled=false}}})}

function rAbout(){
  const el=$('#v-about'),m=S.me;
  const seg=[['\u25C9','Monitoring','Health, hourly volume, status breakdown, busiest interfaces, certificates, queues and an alert timeline. Unreadable data is shown as unknown, never as zero.'],
  ['\u21C4','Transport','Move packages or single iFlows along DEV, QA, UAT, PRE-PROD and PROD with dependency checks, snapshot, verification and automatic rollback.'],
  ['\u2260','Landscape drift','One matrix that shows what differs between tenants and what has not been promoted.'],
  ['\u26A0','Failure handling','Patterns with root cause, message search and step-by-step trace, queue retry and move, incident drafts.'],
  ['\u2726','iFlow Builder and review','Generate an iFlow package from a requirement, and explain or review any existing iFlow with static analysis.'],
  ['\u2699','Agent and MCP','A chat panel on every screen and an MCP server with '+TOOLN+' scope-checked tools for SAP Joule Studio and other agents.']];
  el.innerHTML=`<div class="about-hero card"><div class="logo big"><i>AI</i><div><b>${esc(m.product)}</b><small>Integration Operations Platform for SAP Integration Suite</small></div></div>
  <p>One governed control plane to monitor, repair, move and build integrations across every tenant, usable from a web app, a copilot panel on every screen and any MCP client such as SAP Joule Studio.</p>
  <div class="chips"><span class="chip l">Version ${esc(m.version)}</span><span class="chip">Profile ${esc(m.profile)}</span><span class="chip ok">${TOOLN} MCP tools</span></div>
  <div class="by">Design and developed by <b>${esc(m.author)}</b></div></div>
  <div class="grid tiles" style="margin-top:16px">${seg.map((s,i)=>`<div class="card hov" style="--d:${i*50}ms"><div class="k-ico" style="--c:var(--lil)">${s[0]}</div><b>${esc(s[1])}</b><div class="tiny" style="margin-top:6px;line-height:1.55">${esc(s[2])}</div></div>`).join('')}</div>
  <div class="grid two"><div class="card"><h3>Where it goes beyond a general assistant</h3><ul class="ul">
  <li><b>Governed change:</b> approvals are real four-eyes between two signed-in people, enforced in code, with automatic rollback.</li>
  <li><b>One policy for humans and agents:</b> every MCP tool is scope-checked, writes need confirmation, and agents can never approve.</li>
  <li><b>Honest data:</b> per-API diagnostics name the missing role, and unreadable values are never shown as zero.</li>
  <li><b>Cross-tenant view:</b> drift matrix, one briefing, one alert timeline for the whole landscape.</li>
  <li><b>Evidence on demand:</b> hash-chained audit and a printable security and compliance evidence pack.</li>
  <li><b>iFlow review:</b> exception handling, hard-coded endpoints, payload logging and unsafe code are flagged before promotion.</li></ul>
  <div class="tiny">It complements SAP Joule rather than replacing it: Joule helps design, this platform operates and governs.</div></div>
  <div class="card"><h3>Security and compliance</h3><ul class="ul">
  <li>Named identities, signed expiring sessions, lockout after repeated failures</li>
  <li>Strict Content-Security-Policy, HSTS, no inline scripts, no cross-origin access</li>
  <li>Outbound URL allow-list against server-side request forgery</li>
  <li>Secrets stay on the server and are redacted from logs</li>
  <li>Hash-chained audit with export, verification and SIEM-ready JSON lines</li>
  <li>Pinned dependencies and a software bill of materials</li>
  <li>Mapping to ISO 27001, SOC 2, GDPR, OWASP and SOX ITGC in the evidence pack</li></ul>
  <div class="chips" style="margin-top:10px"><button class="btn lil sm" data-a="go" data-p="audit">Open trust center</button><button class="btn ghost sm" data-a="evidence">Evidence pack</button></div></div></div>
  <div class="card" style="margin-top:16px"><h3>Standards used</h3><div class="chips">${['SAP Cloud Integration OData V2 API','OAuth 2.0 client credentials','Model Context Protocol (JSON-RPC 2.0)','HTTP security headers','Hash-chained audit log','Process Integration Runtime service plan api'].map(x=>`<span class="chip">${x}</span>`).join('')}</div>
  <div class="tiny" style="margin-top:10px">Not independently penetration tested or certified. Validate retry, move and import on a real DEV tenant before relying on them.</div></div>`;
  animateAll(el)}

/* ---------- copilot panel ---------- */
function ctxNow(){const v=S.view;const tn=v==='mon'?S.monTenant:v==='fail'?S.failTenant:v==='packages'?S.pkTenant:v==='trans'&&S.tr?S.tr.src:'';return {view:v||'',tenant:tn||''}}
function updCtx(){const c=ctxNow(),e=$('#pCtx');if(e)e.textContent='Context: '+({dash:'Mission control',mon:'Monitoring',trans:'Transport',drift:'Landscape drift',build:'iFlow Builder',fail:'Failures',approvals:'Approvals',agent:'Agent and MCP',packages:'Packages',ops:'Operations',tenants:'Connect',audit:'Trust center',about:'About'}[c.view]||c.view)+(c.tenant?' | '+c.tenant:'')}
function initPanel(){
  if(!S._pbound){S._pbound=true;$('#fab').onclick=togglePanel;$('#pClose').onclick=closePanel;$('#pNew').onclick=()=>{S.chatHist=[];sessionStorage.removeItem('chat');S._pinit=false;initPanel()};$('#csend').onclick=()=>sendChat();$('#cin').onkeydown=e=>{if(e.key==='Enter')sendChat()};$('#micBtn').onclick=mic;
    $('#sugg').addEventListener('click',e=>{const b=e.target.closest('[data-s]');if(b)sendChat(b.dataset.s)})}
  if(S._pinit)return;S._pinit=true;S.chatHist=JSON.parse(sessionStorage.getItem('chat')||'[]');$('#msgs').innerHTML='';
  if(!S.chatHist.length)addMsg('a','Hello. I am your integration copilot. I remember the tenant we talk about, I know which screen you are on, and I use the same governed tools as the rest of the app. Changes always show a plan first.');
  else S.chatHist.forEach(h=>addMsg(h.who,esc(h.text)));
  renderSugg(prompts())}
function openPanel(){initPanel();$('#copilot').classList.add('on');document.body.classList.add('pop');updCtx();setTimeout(()=>$('#cin').focus(),60)}
function closePanel(){$('#copilot').classList.remove('on');document.body.classList.remove('pop')}
function togglePanel(){$('#copilot').classList.contains('on')?closePanel():openPanel()}
function mic(){const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR)return toast('Voice input is not supported in this browser','bad');const r=new SR();r.lang=navigator.language||'en-US';r.onresult=e=>{$('#cin').value=e.results[0][0].transcript;sendChat()};r.onerror=()=>toast('Could not hear anything','bad');r.onend=()=>$('#micBtn').classList.remove('rec');$('#micBtn').classList.add('rec');r.start()}

/* ---------- actions (no inline handlers: strict CSP) ---------- */
const ACT={go:p=>go(p),closeModal:()=>closeModal(),clearDemo:()=>clearDemo(),loadDemo:()=>loadDemo(),reload:()=>loadTenants(true),openJob:p=>openJob(p),openReport:()=>openReport(),rmT:p=>rmT(p),tenantModal:()=>tenantModal(),testT:p=>testT(p),
  pkTo:p=>{S.pkTenant=p;go('packages')},failTo:p=>{S.failTenant=p;S.failData=null;go('fail')},diag:p=>diagModal(p),askCopilot:p=>{openPanel();sendChat(p)},evidence:()=>openHtml('/api/evidence.html'),
  auditExport:()=>dl('/api/audit/export','audit.jsonl'),auditVerify:async()=>{try{const v=await api('/api/audit/verify');toast(v.intact?'Audit chain intact ('+v.checked+' events)':'Audit chain BROKEN at event '+v.broken_at,v.intact?'ok':'bad')}catch(e){toast(e.message,'bad')}}};
document.addEventListener('click',e=>{const el=e.target.closest('[data-a]');if(!el)return;const f=ACT[el.dataset.a];if(f){e.preventDefault();f(el.dataset.p)}});

/* ---------- sign in ---------- */
localStorage.removeItem('auth');
$('#gateGo').onclick=async()=>{const v=$('#gateKey').value.trim();if(!v)return($('#gateErr').textContent='Enter your access key');$('#gateGo').disabled=true;$('#gateErr').textContent='';
  try{const r=await fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key:v})});const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.detail||'Sign-in failed');$('#gateKey').value='';await enter({type:'session',value:j.token})}catch(e){$('#gateErr').textContent=e.message}$('#gateGo').disabled=false};
$('#gateKey').onkeydown=e=>{if(e.key==='Enter')$('#gateGo').click()};
$('#gateSandbox').onclick=()=>{const id=Array.from(crypto.getRandomValues(new Uint8Array(10))).map(b=>b.toString(36).padStart(2,'0')).join('').slice(0,16);enter({type:'sandbox',value:id})};
$('#logoutBtn').onclick=async()=>{try{if(S.auth&&S.auth.type==='session')await api('/api/logout',{})}catch(e){}sessionStorage.removeItem('auth');sessionStorage.removeItem('chat');S.auth=null;clearInterval(pollT);closePanel();showGate('')};
addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key==='/'){e.preventDefault();if(S.auth)togglePanel()}});

/* ---------- boot ---------- */
(async function(){const ab=await fetch('/api/about').then(r=>r.json()).catch(()=>({sandbox:true}));if(!ab.sandbox){$('#gateSandbox').style.display='none';$('#gateOr').style.display='none'}if(S.auth)enter(S.auth);else showGate('')})();
