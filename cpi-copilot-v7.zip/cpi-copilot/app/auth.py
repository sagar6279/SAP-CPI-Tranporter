import hmac, re, time
from fastapi import HTTPException, Request
import config, audit, security

ALL = config.ALL_SCOPES


class User:
    def __init__(self, name, scopes, sandbox=False, via="key"):
        self.name, self.scopes, self.sandbox, self.via = name, set(scopes), sandbox, via
    def has(self, scope):
        return scope in self.scopes


def client_ip(request: Request):
    parts = [p.strip() for p in request.headers.get("x-forwarded-for", "").split(",") if p.strip()]
    if parts:
        return parts[-1]
    return request.client.host if request.client else "unknown"


def match_key(given):
    found = None
    for ident in config.identities():
        if hmac.compare_digest(ident["key"].encode(), (given or "").encode()):
            found = ident
    return found


def authenticate(request: Request) -> User:
    if config.LOCAL_DEV:
        return User("local-dev", ["Display", "Develop", "Transport", "Remediate", "Admin", "Approve"], via="local")
    sess = request.headers.get("x-demo-session", "")
    if sess and config.SANDBOX and re.fullmatch(r"[A-Za-z0-9]{8,40}", sess):
        return User("sandbox-" + sess[:6], ALL, sandbox=True, via="sandbox")
    ip = client_ip(request)
    hdr = request.headers.get("authorization", "")
    tok = hdr[7:].strip() if hdr.lower().startswith("bearer ") else ""
    given = request.headers.get("x-api-key", "").strip()

    if tok.startswith("st."):
        d = security.verify_session(tok)
        if not d:
            raise HTTPException(401, "Session expired. Sign in again.")
        u = User(d["n"], d["s"], via="session")
        if d["e"] - time.time() < config.SESSION_TTL_MIN * 30:
            request.state.new_token = security.issue_session(d["n"], d["s"])[0]
        return u

    key = given or (tok if tok and tok.count(".") != 2 else "")
    if key:
        security.check_lock(ip)
        ident = match_key(key)
        if ident:
            return User(ident["name"], ident["scopes"], via="key")
        security.record_fail(ip)
        audit.record("access-key", "authenticate", "-", "DENY", reason="bad access key", ip=ip)
        raise HTTPException(401, "Invalid access key")

    if tok and tok.count(".") == 2:
        creds = config.xsuaa_credentials()
        if not creds:
            raise HTTPException(401, "Token authentication is not configured")
        try:
            from sap import xssec
            ctx = xssec.create_security_context(tok, creds)
        except Exception as e:
            audit.record("unknown", "authenticate", "-", "DENY", reason=str(e)[:200], ip=ip)
            raise HTTPException(401, "Invalid token")
        prefix = creds["xsappname"] + "."
        return User(ctx.get_logon_name() or ctx.get_email() or "unknown", [s for s in ALL if ctx.check_scope(prefix + s)], via="xsuaa")

    audit.record("anonymous", "authenticate", "-", "DENY", reason="missing credentials", ip=ip)
    raise HTTPException(401, "Authentication required")
