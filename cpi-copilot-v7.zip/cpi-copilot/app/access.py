from fastapi import HTTPException
import audit
from store import store

def visible(user):
    out = {}
    for k, v in store.all().items():
        if v.get("demo"):
            if store.demo_on(user.name):
                out[k] = v
        elif not user.sandbox:
            out[k] = v
    return out

def tenant_for(user, name):
    t = store.get(name)
    if not t or (t.get("demo") and not store.demo_on(user.name)):
        raise HTTPException(404, "Tenant '%s' is not registered" % name)
    if user.sandbox and not t.get("demo"):
        audit.record(user.name, "tenant.access", name, "DENY", reason="sandbox user, real tenant")
        raise HTTPException(403, "Sandbox sessions can only use demo tenants")
    return t
