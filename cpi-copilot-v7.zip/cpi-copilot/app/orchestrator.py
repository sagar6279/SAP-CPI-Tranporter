"""Copilot agent: understands the request, remembers context, calls tools, shows its tool trace, proposes follow-ups and actions that need confirmation.
Replace understand() with an LLM function-calling loop (SAP Generative AI Hub) without changing the tools or the policy engine."""
import re, time, difflib
import access, tools, builder
from store import store

ALIAS = {"production": "PROD", "prod": "PROD", "preprod": "PREPROD", "pre-prod": "PREPROD", "uat": "UAT", "qa": "QA", "quality": "QA", "test": "QA", "dev": "DEV", "development": "DEV"}
TOK = r"[\w.\-]+"
_MEM = {}


def resolve(token, tenants):
    t = (token or "").strip(" '\"?.,")
    for k in tenants:
        if k.lower() == t.lower():
            return k, None
    st = ALIAS.get(t.lower())
    if st:
        c = [k for k, v in tenants.items() if v["stage"] == st]
        if len(c) == 1:
            return c[0], None
        if len(c) > 1:
            return None, "More than one %s tenant exists (%s). Use the exact name." % (st, ", ".join(c))
    return None, "Tenant '%s' is not connected. Connected: %s" % (t, ", ".join(tenants) or "none")


def _find_tenant(t, low, tenants):
    mt = re.search(r"\b(?:in|on|of|for|from|at)\s+(" + TOK + r")\s*[?.!]*$", t)
    if mt:
        tn, _ = resolve(mt.group(1), tenants)
        if tn:
            return tn
    for k in sorted(tenants, key=len, reverse=True):
        if k.lower() in low:
            return k
    for a, st in sorted(ALIAS.items(), key=lambda x: -len(x[0])):
        if re.search(r"\b" + re.escape(a) + r"\b", low):
            c = [k for k, v in tenants.items() if v["stage"] == st]
            if len(c) == 1:
                return c[0]
    return None


def handle(user, text, ctx=None):
    tenants = access.visible(user)
    trace = []
    C = lambda name, **a: tools.call(user, name, a, "chat", trace)
    t, low = text.strip(), text.lower().strip()
    mem = _MEM.setdefault(user.name, {})
    ctx = ctx or {}
    def out(reply, suggestions=None, **kw):
        _MEM[user.name] = mem
        return {"reply": reply, "trace": trace, "suggestions": (suggestions or [])[:4], **kw}

    if re.search(r"\b(what can you do|help|skills|capabilities|how do i use)\b", low) and len(low) < 60:
        return out("I can monitor, explain, move and repair your SAP Integration Suite landscape. Ask me in plain language, I remember the tenant we are talking about.\n"
                   "- Monitor: daily briefing, alerts, health of a tenant, certificates, queues\n- Analyse: failure patterns, search or trace a message, explain and review an iFlow\n"
                   "- Compare: drift between DEV, QA and PROD\n- Change (with approval): move packages or iFlows, retry or move queue messages\n- Build: create an iFlow from a requirement\n- Check access: diagnose why data is empty",
                   ["Give me the daily briefing", "Any alerts?", "Compare tenants for drift", "Diagnose the connection"])

    if re.search(r"\b(create|build|generate|make|design)\b.*\b(iflow|integration flow|interface|integration)\b", low):
        if not user.has("Develop"):
            return out("Not permitted: you need the Develop permission.")
        r = C("generate_iflow", requirement=t)
        return out("I generated %s with %d quality checks. Review the files on the iFlow Builder page, then import to DEV." % (r["iflow_id"], len(r["lint"])), ["Open in iFlow Builder"],
                   blocks=[{"type": "build", "build": r}], proposals=[{"kind": "build_open", "label": "Open in iFlow Builder", "params": {"build": r["id"]}}])

    if not tenants:
        return out("No tenants are connected yet. Bind a Process Integration Runtime instance to this app (see the Connect page), or load the demo tenants.", ["How do I connect a tenant?"])

    tn = _find_tenant(t, low, tenants)
    explicit = bool(tn)
    if not tn and len(tenants) == 1:
        tn = next(iter(tenants))
    if not tn and ctx.get("tenant") in tenants:
        tn = ctx["tenant"]
    if not tn and mem.get("tenant") in tenants and re.search(r"\b(there|that|same|again|also|too|it)\b|^(and|what about)\b", low):
        tn = mem["tenant"]
    def need_tenant(what):
        return out("Which tenant should I use for %s? Connected: %s." % (what, ", ".join(tenants)), ["%s in %s" % (what.capitalize(), k) for k in list(tenants)[:4]])

    if re.search(r"\b(briefing|good morning|daily summary|what.s happening|what happened|status of everything|landscape summary|summari[sz]e (the )?(day|landscape|today))\b", low):
        b = C("daily_briefing")
        return out(b["headline"], ["Any alerts?", "Compare tenants for drift", "Management report"], blocks=[{"type": "briefing", "briefing": b}])

    if re.search(r"\b(executive|management)\b.*\b(report|summary)\b|\breport\b.*\b(management|executive)\b", low):
        r = C("executive_report")
        return out("Landscape summary: %d tenants, %d operations (%d succeeded, %d rolled back, %d failed)." % (len(r["tenants"]), r["operations"]["total"], r["operations"]["success"], r["operations"]["rolled_back"], r["operations"]["failed"]),
                   ["Any alerts?", "Give me the daily briefing"], blocks=[{"type": "table", "columns": ["Tenant", "Stage", "Health", "Failed 24h", "Critical", "Top issue"], "rows": [[x["tenant"], x["stage"], x["health"], x["failed_24h"] if x["failed_24h"] is not None else "n/a", x["critical"], x["top_issue"]] for x in r["tenants"]]}])

    if re.search(r"\balerts?\b|what.s wrong|anything (critical|broken)", low):
        a = C("list_alerts")["alerts"]
        s = ["Give me the daily briefing"] + (["Diagnose the connection of %s" % a[0]["tenant"]] if a else [])
        return out("%d active alerts across %d tenants." % (len(a), len(tenants)), s, blocks=[{"type": "alerts", "items": a[:12]}])

    if re.search(r"\b(drift|out of sync|in sync|not promoted|version differences?|compare (the )?(tenants|environments|landscape|packages))\b", low):
        if len(tenants) < 2:
            return out("Drift needs at least two tenants. Only %s is connected." % next(iter(tenants)))
        r = C("landscape_drift")
        s = r["summary"]
        rows = [[x["package"], x["kind"], x["id"]] + [(x["versions"].get(n["name"]) or "-") for n in r["tenants"]] + [x["state"].replace("_", " ")] for x in r["rows"] if x["state"] != "in_sync"][:15]
        return out("%d artifacts: %d in sync, %d drifted, %d missing in at least one tenant." % (sum(s.values()), s["in_sync"], s["drift"], s["missing"]), ["Move a package", "Any alerts?"],
                   blocks=[{"type": "table", "columns": ["Package", "Type", "Id"] + [n["name"] for n in r["tenants"]] + ["State"], "rows": rows}] if rows else [])

    if re.search(r"\b(pending approvals?|approvals?|waiting for approval|who needs to approve)\b", low):
        a = C("list_approvals")["approvals"]
        return out("%d approval request(s). Approving is done by a different person on the Approvals page." % len(a), ["Any alerts?"],
                   blocks=[{"type": "table", "columns": ["Request", "Stage", "By", "Status"], "rows": [[x["title"], x["stage"], x["requester"], x["status"]] for x in a[:10]]}] if a else [])

    if re.search(r"\b(diagnos\w*|permissions?|roles?|test (the )?(connection|api)|check (the )?(connection|access)|connection (check|test)|why .*\b(empty|zero|no data|nothing|0)\b|cannot read|can.t read|not reading)\b", low):
        if not tn:
            return need_tenant("diagnostics")
        mem["tenant"] = tn
        r = C("diagnose_tenant", tenant=tn)
        if "error" in r:
            return out(r["error"])
        bad = [c for c in r["checks"] if not c["ok"]]
        msg = ("All %d checks passed for %s." % (len(r["checks"]), tn)) if not bad else "%d of %d checks failed for %s. The missing role is shown per check." % (len(bad), len(r["checks"]), tn)
        return out(msg, ["Show tenant health", "Any alerts?"], blocks=[{"type": "diag", "checks": r["checks"]}])

    m = re.search(r"\b(?:move|transport|promote|copy|migrate|push)\s+(?:the\s+)?(?:(package|iflow|integration flow|artifact)\s+)?[\"']?(.+?)[\"']?\s*(?:(package|iflow|integration flow)\s+)?from\s+(" + TOK + r")\s+(?:to|into)\s+(" + TOK + ")", t, re.I)
    if m and not re.search(r"\bfailed\b|\bmessages?\b", m.group(2), re.I):
        kind = (m.group(1) or m.group(3) or "").lower()
        name = m.group(2).strip()
        s, e1 = resolve(m.group(4), tenants)
        d, e2 = resolve(m.group(5), tenants)
        if e1 or e2:
            return out(e1 or e2)
        pk = C("list_packages", tenant=s).get("packages", [])
        nrm = lambda x: re.sub(r"[^a-z0-9]", "", x.lower())
        pkg, iflow = None, None
        for p in pk:
            if kind in ("", "package") and nrm(name) in (nrm(p["Id"]), nrm(p["Name"])):
                pkg = p
        if not pkg:
            for p in pk:
                for i in p["iflows"]:
                    if nrm(i) == nrm(name):
                        pkg, iflow = p, i
        if not pkg and kind in ("", "package"):
            for p in pk:
                if nrm(name) and (nrm(name) in nrm(p["Id"]) or nrm(name) in nrm(p["Name"])):
                    pkg = p
        if not pkg:
            for p in pk:
                for i in p["iflows"]:
                    if nrm(name) and nrm(name) in nrm(i):
                        pkg, iflow = p, i
        if not pkg:
            sug = difflib.get_close_matches(name, [p["Name"] for p in pk] + [i for p in pk for i in p["iflows"]], n=3, cutoff=0.4)
            return out("I could not find '%s' in %s.%s" % (name, s, (" Did you mean: " + ", ".join(sug) + "?") if sug else ""), ["Packages in %s" % s])
        mem["tenant"] = s
        r = C("plan_move", source=s, target=d, package_id=pkg["Id"], iflow_ids=[iflow] if iflow else None)
        if "error" in r:
            return out(r["error"])
        what = ("iFlow %s (package %s)" % (iflow, pkg["Name"])) if iflow else "package " + pkg["Name"]
        prop = {"kind": "move", "label": "Move %s to %s" % (what, d), "needs_approval": r["needs_approval"],
                "params": {"source": s, "target": d, "package_id": pkg["Id"], "artifacts": [{"kind": "iflow", "id": iflow}] if iflow else None, "deploy": True, "include_deps": True}}
        return out("Plan to move %s from %s to %s. Risk: %s.%s" % (what, s, d, r["plan"]["risk"], " A second person must approve before it runs." if r["needs_approval"] else ""),
                   ["Explain iFlow %s" % iflow] if iflow else ["Compare tenants for drift"], blocks=[{"type": "plan", "plan": r["plan"]}], proposals=[prop] if r["plan"]["ready"] else [])

    mq = re.search(r"\bmove\b.*?\bfailed\b.*?\bfrom\s+(" + TOK + r")\s+to\s+(" + TOK + r")\s+(?:in|on)\s+(" + TOK + ")", t, re.I)
    mr = re.search(r"\b(retry|reprocess|resend|redrive)\b.*?\bfailed\b", t, re.I)
    if mq:
        q_tn, err = resolve(mq.group(3), tenants)
        if err:
            return out(err)
        return out("Ready to move failed messages from %s to %s in %s." % (mq.group(1), mq.group(2), q_tn),
                   proposals=[{"kind": "retry", "label": "Move failed messages %s to %s" % (mq.group(1), mq.group(2)), "needs_approval": tenants[q_tn]["stage"] == "PROD",
                               "params": {"tenant": q_tn, "queue": mq.group(1), "target_queue": mq.group(2), "mode": "move"}}])
    if mr:
        if not tn:
            return need_tenant("retry")
        mem["tenant"] = tn
        qs = C("list_queues", tenant=tn).get("queues", [])
        props = [{"kind": "retry", "label": "Retry failed messages in %s" % q["Name"], "needs_approval": tenants[tn]["stage"] == "PROD", "params": {"tenant": tn, "queue": q["Name"], "mode": "retry"}}
                 for q in qs if q["NumberOfMessages"] and "error" in str(q["Name"]).lower()]
        if not props:
            return out("No error queues with failed messages in %s." % tn, ["Show failed messages in %s" % tn])
        return out("Found %d error queue(s) with failed messages in %s." % (len(props), tn), ["Analyze issues in %s" % tn], blocks=[{"type": "table", "columns": ["Queue", "Messages"], "rows": [[q["Name"], q["NumberOfMessages"]] for q in qs]}], proposals=props)

    mx = re.search(r"\b(?:explain|review|describe|audit|analy[sz]e|what does|check)\s+(?:the\s+)?(?:iflow|integration flow)\s+[\"']?([\w.\- ]+?)[\"']?(?:\s+(?:in|on|from)\s+" + TOK + r")?\s*[?.!]*$", t, re.I) or \
         re.search(r"\b(?:explain|review|describe|audit|check)\s+(?:the\s+)?[\"']?([\w.\-]+)[\"']?\s+(?:iflow|integration flow)", t, re.I)
    if mx:
        if not tn:
            return need_tenant("explain an iFlow")
        mem["tenant"] = tn
        r = C("explain_iflow", tenant=tn, iflow=mx.group(1).strip())
        if "error" in r:
            return out(r["error"])
        return out(r["summary"], ["Move iFlow %s from %s to %s" % (r["id"], tn, "QA"), "Show failed messages for %s" % r["id"]], blocks=[{"type": "review", "review": r}])

    mc = re.search(r"\bcorrelation(?:\s*id)?\s*[:=]?\s*[\"']?([A-Za-z0-9_.\-:]{4,})", t, re.I)
    mg = re.search(r"\b(?:guid|message\s*id|trace)\s*[:=]?\s*[\"']?([A-Za-z0-9_.\-:]{10,})", t, re.I)
    ms = re.search(r"\b(?:messages?|logs?)\b.*\b(?:of|for|from)\s+(?:iflow\s+)?[\"']?([\w.\-]+)[\"']?(?:\s+(?:in|on)\s+" + TOK + r")?\s*[?.!]*$", t, re.I)
    if (mc or mg) and re.search(r"\b(find|search|trace|look ?up|show|get|where)\b", low):
        if not tn:
            return need_tenant("a message search")
        mem["tenant"] = tn
        if mg:
            r = C("get_message_trace", tenant=tn, message_guid=mg.group(1))
            if "error" in r:
                return out(r["error"])
            return out("Trace of message %s: %s in %s." % (mg.group(1)[:14], r["log"]["Status"], r["log"]["IntegrationFlowName"]), ["Analyze issues in %s" % tn], blocks=[{"type": "trace", "trace": r}])
        r = C("search_messages", tenant=tn, correlation_id=mc.group(1), hours=168)
        if "error" in r:
            return out(r["error"])
        return out("%d message(s) with correlation id %s in %s (last 7 days)." % (r["count"], mc.group(1), tn), [], blocks=[{"type": "table", "columns": ["Interface", "Status", "Time", "Message"], "rows": [[x["IntegrationFlowName"], x["Status"], x["LogEnd"], str(x["MessageGuid"])[:16]] for x in r["messages"]]}] if r["count"] else [])
    if ms and not re.search(r"\bfailed\b", low) and tn:
        r = C("search_messages", tenant=tn, iflow=ms.group(1), hours=24)
        if "error" not in r:
            mem["tenant"] = tn
            return out("%d message(s) of %s in the last 24 hours." % (r["count"], ms.group(1)), ["Explain iFlow %s" % ms.group(1)], blocks=[{"type": "table", "columns": ["Status", "Time", "Duration ms", "Message"], "rows": [[x["Status"], x["LogEnd"], x["ProcessingMs"], str(x["MessageGuid"])[:16]] for x in r["messages"][:20]]}] if r["count"] else [])

    if re.search(r"\bpackages?\b", low):
        if not tn:
            return need_tenant("packages")
        mem["tenant"] = tn
        pk = C("list_packages", tenant=tn).get("packages", [])
        return out("%d packages in %s." % (len(pk), tn), ["Compare tenants for drift"] if len(tenants) > 1 else [], blocks=[{"type": "table", "columns": ["Package", "Id", "iFlows", "Value maps"], "rows": [[p["Name"], p["Id"], len(p["iflows"]), len(p["valuemaps"])] for p in pk]}])

    if re.search(r"\b(send|email|mail|notify|draft)\b.*\b(incident|summary|team|operations)\b|\bincident summary\b", low):
        best = None
        for n in ([tn] if explicit and tn else list(tenants)):
            r = C("draft_incident_email", tenant=n)
            if "subject" in r:
                best = r; break
        if not best:
            return out("No failures found, nothing to report.")
        return out("Incident summary drafted. Use the Failures page to send it through the webhook.", ["Any alerts?"], blocks=[{"type": "email", **best}])

    if re.search(r"\bcertificates?\b|\bkeystore\b", low):
        if not tn:
            return need_tenant("certificates")
        mem["tenant"] = tn
        o = C("get_tenant_overview", tenant=tn)
        cs = o.get("certs", [])
        return out("%d certificates in %s, %d expire within 30 days." % (len(cs), tn, len([c for c in cs if c["days"] < 30])) if cs else "No certificate data for %s%s." % (tn, (": " + o.get("certs_error", "")) if o.get("certs_error") else ""),
                   [], blocks=[{"type": "table", "columns": ["Alias", "Days left", "Expires"], "rows": [[c["alias"], c["days"], c.get("expires")] for c in cs[:12]]}] if cs else [])

    if re.search(r"\btenants?\b|landscape|environments?|connected", low) and not explicit:
        r = C("list_tenants")["tenants"]
        return out("%d tenants connected." % len(r), ["Give me the daily briefing"], blocks=[{"type": "table", "columns": ["Tenant", "Stage", "Source"], "rows": [[x["name"], x["stage"], x["source"]] for x in r]}])

    if tn:
        if re.search(r"analy|issues?|fix|root|cause", low):
            mem["tenant"] = tn
            r = C("analyze_failures", tenant=tn)
            if "error" in r:
                return out("Not permitted: " + r["error"])
            top = r["patterns"][0]["iflow"] if r["patterns"] else None
            return out("%d failure patterns in %s." % (len(r["patterns"]), tn), (["Explain iFlow %s" % top, "Retry failed messages in %s" % tn, "Draft incident summary"] if top else []), blocks=[{"type": "findings", "items": r["patterns"]}])
        if re.search(r"\b(failed|failures?|errors?)\b", low):
            mem["tenant"] = tn
            r = C("analyze_failures", tenant=tn, top=30)
            if "error" in r:
                return out("Not permitted: " + r["error"])
            return out("%d failed messages in %s." % (len(r["messages"]), tn), ["Analyze issues in %s" % tn, "Retry failed messages in %s" % tn],
                       blocks=[{"type": "table", "columns": ["Interface", "Category", "Message", "Time"], "rows": [[x["IntegrationFlowName"], x["domain"], str(x["MessageGuid"])[:14], x["LogEnd"]] for x in r["messages"]]}])
        if re.search(r"health|status|monitor|overview|how is|how are", low):
            mem["tenant"] = tn
            o = C("get_tenant_overview", tenant=tn)
            if "error" in o:
                return out(o["error"])
            if not o.get("connected"):
                return out("%s is unreachable: %s" % (tn, o.get("error")), ["Diagnose the connection of %s" % tn])
            bad = [a["Id"] for a in o.get("artifacts", []) if a["Status"] != "STARTED"]
            qlt = [k for k, v in (o.get("quality") or {}).items() if not v.get("ok")]
            msgs = "%s messages in 24h, %s failed" % ((format(o["messages_24h"], ",") if o.get("messages_24h") is not None else "unknown"), (o.get("failed_24h") if o.get("failed_24h") is not None else "unknown"))
            return out("%s (%s): %s, %d artifacts, %d not started%s. Health: %s. Latency %s ms.%s" % (tn, o["stage"], msgs, len(o.get("artifacts", [])), len(bad), (": " + ", ".join(bad)) if bad else "", o.get("health_label"), o.get("latency_ms"),
                       (" Could not read: %s." % ", ".join(qlt)) if qlt else ""), (["Diagnose the connection of %s" % tn] if qlt else ["Analyze issues in %s" % tn, "Show certificates in %s" % tn]))

    ex = list(tenants)[:2]
    a, b = (ex + ex)[:2]
    return out("I did not understand that yet. Try one of these:", ["Give me the daily briefing", "Any alerts?", "Show failed messages in %s" % a, "Compare tenants for drift"] if len(tenants) > 1 else ["Give me the daily briefing", "Any alerts?", "Show failed messages in %s" % a, "Diagnose the connection"])
