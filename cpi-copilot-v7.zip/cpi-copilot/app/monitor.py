"""Monitoring: accurate per-tenant overview (unknown is never shown as zero), health score, alerts, alert history."""
import threading, time
from concurrent.futures import ThreadPoolExecutor
import config
from agents import failure
from clients import client_for
from cpi_client import CPIError

_cache = {}
_hist, _state, _samples = [], {}, {}
_HL = threading.Lock()
_sent = {}


def _section(fn):
    try:
        return fn(), {"ok": True}
    except CPIError as e:
        return None, {"ok": False, "error": str(e), "status": e.status}
    except Exception as e:
        return None, {"ok": False, "error": type(e).__name__ + ": " + str(e)[:160]}


def health(o):
    """Returns (score or None, label). None means there is nothing to judge, never a fake 100."""
    if not o.get("connected"):
        return 0, "Unreachable"
    m, f, arts = o.get("messages_24h"), o.get("failed_24h"), o.get("artifacts") or []
    if m is None and not arts and not o.get("quality", {}).get("artifacts", {}).get("ok"):
        return None, "No data"
    if (m or 0) == 0 and not arts:
        return None, "Idle"
    score = 100.0
    if m and f is not None:
        score -= min(60.0, f / m * 100 * 3)
    score -= min(40, 8 * len([a for a in arts if a["Status"] not in ("STARTED", "STARTING")]))
    score = max(0.0, round(score, 1))
    return score, ("Healthy" if score >= 90 else "Degraded" if score >= 75 else "Critical")


def overview(t, refresh=False):
    hit = _cache.get(t["name"])
    if hit and not refresh and time.time() - hit[0] < 25:
        return hit[1]
    out = {"name": t["name"], "stage": t["stage"], "source": t["source"], "connected": True, "ts": time.time()}
    try:
        c = client_for(t["name"])
        out["latency_ms"] = c.ping()["latency_ms"]
        sections = {"stats": lambda: c.message_stats(24), "sample": lambda: c.message_sample(24), "artifacts": c.runtime_artifacts,
                    "certs": lambda: c.cert_expiry()[:12], "queues": c.queues, "patterns": lambda: failure.analyze(c, t["stage"], 10)["patterns"]}
        with ThreadPoolExecutor(max_workers=6) as ex:
            futs = {k: ex.submit(_section, fn) for k, fn in sections.items()}
            res, q = {}, {}
            for k, fu in futs.items():
                res[k], q[k] = fu.result()
        out["quality"] = q
        st, sm = res["stats"], res["sample"]
        out["messages_24h"] = st["total"] if st else None
        out["by_status"] = st["by_status"] if st else None
        out["failed_24h"] = (st["by_status"].get("FAILED") if st else None)
        out["series"] = sm["series"] if sm else None
        out["failed_series"] = sm["failed_series"] if sm else None
        out["by_flow"] = sm["by_flow"] if sm else {}
        out["sample_note"] = ("Hourly chart is based on the latest %d log entries (limit reached)" % sm["sampled"]) if sm and sm["capped"] else None
        for k, dflt in (("artifacts", []), ("certs", []), ("queues", []), ("patterns", [])):
            out[k] = res[k] if res[k] is not None else dflt
        for k in ("artifacts", "certs", "queues", "patterns"):
            if not q[k]["ok"]:
                out[k + "_error"] = q[k]["error"]
    except CPIError as e:
        out.update(connected=False, error=str(e), quality={})
    except Exception as e:
        out.update(connected=False, error=type(e).__name__ + ": " + str(e)[:200], quality={})
    out["health"], out["health_label"] = health(out)
    al = alerts_for(out)
    out["alert_count"] = len(al)
    track(out, al)
    _cache[t["name"]] = (time.time(), out)
    return out


def forget(name):
    _cache.pop(name, None)

def clear():
    _cache.clear()


def alerts_for(o):
    a = []
    n, st = o["name"], o["stage"]
    def add(sev, title, detail, action):
        a.append({"severity": sev, "tenant": n, "stage": st, "title": title, "detail": detail, "action": action})
    if not o.get("connected"):
        add("critical", "Tenant unreachable", o.get("error", ""), "Check the service key, roles and network on the Connect page")
        return a
    q = o.get("quality") or {}
    for k, label, role in (("stats", "Message statistics", "MonitoringDataRead"), ("artifacts", "Runtime artifacts", "MonitoringDataRead"), ("queues", "JMS queues", "DataStoresAndQueuesRead"), ("certs", "Keystore", "")):
        if k in q and not q[k]["ok"]:
            add("warning", "Cannot read: " + label, q[k]["error"][:160], "Open Connect and run diagnostics" + ((" (role %s)" % role) if role else ""))
    m, f = o.get("messages_24h"), o.get("failed_24h")
    if m and f is not None:
        if f / m > 0.10:
            add("critical", "High failure rate", "%.1f%% of %d messages failed in 24h" % (f / m * 100, m), "Open Failures, check the top pattern")
        elif f / m > 0.05:
            add("warning", "Elevated failure rate", "%.1f%% of %d messages failed in 24h" % (f / m * 100, m), "Open Failures")
    for c in o.get("certs") or []:
        if c["days"] < 0:
            add("critical", "Certificate expired: " + str(c["alias"]), "Expired %d days ago" % -c["days"], "Renew and upload the certificate")
        elif c["days"] < 15:
            add("critical", "Certificate expires soon: " + str(c["alias"]), "%d days left" % c["days"], "Renew and upload the certificate")
        elif c["days"] < config.MIN_CERT_DAYS:
            add("warning", "Certificate expiring: " + str(c["alias"]), "%d days left" % c["days"], "Plan renewal")
    for x in o.get("artifacts") or []:
        if x["Status"] not in ("STARTED", "STARTING"):
            add("critical" if st == "PROD" else "warning", "Artifact not started: " + str(x["Id"]), "Status " + str(x["Status"]), "Redeploy or inspect the runtime error")
    for qq in o.get("queues") or []:
        if qq["NumberOfMessages"] and "error" in str(qq["Name"]).lower():
            add("warning", "Messages in error queue " + str(qq["Name"]), "%d messages waiting" % qq["NumberOfMessages"], "Retry or move them from Failures")
    for p in (o.get("patterns") or [])[:3]:
        if p["severity"] in ("P1", "P2"):
            add("critical" if p["severity"] == "P1" else "warning", "%s: %s" % (p["iflow"], p["subtype"]), "%d occurrences - %s" % (p["count"], p["recommended_fix"]), "Open Failures")
    return a


def all_alerts(tenants):
    with ThreadPoolExecutor(max_workers=6) as ex:
        ovs = list(ex.map(lambda t: overview(t), tenants))
    order = {"critical": 0, "warning": 1}
    return sorted([x for o in ovs for x in alerts_for(o)], key=lambda x: order[x["severity"]]), ovs


# ---------- history ----------
def track(o, alerts):
    now, name = time.time(), o["name"]
    keys = {(name, a["title"]): a for a in alerts}
    with _HL:
        prev = {k for k in _state if k[0] == name}
        for k, a in keys.items():
            if k not in _state:
                _state[k] = {"first": now, "sev": a["severity"]}
                _hist.append({"ts": now, "type": "raised", "severity": a["severity"], "tenant": name, "title": a["title"], "detail": a["detail"]})
                _notify(name, a)
            _state[k]["last"] = now
        for k in prev - set(keys):
            _hist.append({"ts": now, "type": "resolved", "severity": _state[k]["sev"], "tenant": name, "title": k[1], "detail": "Condition cleared after %d min" % int((now - _state[k]["first"]) / 60)})
            del _state[k]
        del _hist[:-400]
        if o.get("connected"):
            _samples.setdefault(name, []).append({"ts": now, "total": o.get("messages_24h"), "failed": o.get("failed_24h"), "alerts": len(alerts)})
            del _samples[name][:-500]


def _notify(name, a):
    if not (config.NOTIFY_ON_CRITICAL and config.NOTIFY_WEBHOOK_URL and a["severity"] == "critical") or name.startswith("ACME-"):
        return
    key = (name, a["title"])
    if time.time() - _sent.get(key, 0) < 3600:
        return
    _sent[key] = time.time()
    def go():
        try:
            import httpx
            httpx.post(config.NOTIFY_WEBHOOK_URL, json={"text": "[CRITICAL][%s] %s - %s" % (name, a["title"], a["detail"])}, timeout=10)
        except Exception:
            pass
    threading.Thread(target=go, daemon=True).start()


def history(names, n=60):
    with _HL:
        return [e for e in _hist if e["tenant"] in names][-n:][::-1]


def trend(name):
    with _HL:
        return list(_samples.get(name, []))[-120:]


def start_poller():
    if config.POLL_SECONDS <= 0:
        return
    from store import store
    def loop():
        time.sleep(25)
        while True:
            try:
                for t in list(store.all().values()):
                    if not t.get("demo"):
                        overview(t, refresh=True)
            except Exception:
                pass
            time.sleep(max(60, config.POLL_SECONDS))
    threading.Thread(target=loop, daemon=True, name="poller").start()
