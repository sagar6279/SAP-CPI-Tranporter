"""Background job engine with live step progress (used for transports, retries, moves)."""
import copy, threading, time, traceback, uuid
import audit

_JOBS = {}
_ORDER = []
_LOCK = threading.RLock()
_LOCKS = {}

def tenant_lock(name):
    with _LOCK:
        return _LOCKS.setdefault(name, threading.Lock())

class Ctx:
    def __init__(self, job):
        self.job = job

    def steps(self, items):
        with _LOCK:
            self.job["steps"] = [{"name": n, "detail": d, "status": "pending", "t": None} for n, d in items]

    def add(self, name, detail="", status="pending"):
        with _LOCK:
            self.job["steps"].append({"name": name, "detail": detail, "status": status, "t": time.time() if status == "running" else None})
            return len(self.job["steps"]) - 1

    def set(self, i, status, detail=None):
        with _LOCK:
            s = self.job["steps"][i]
            s["status"] = status
            if detail is not None:
                s["detail"] = detail
            s["t"] = time.time()

    def start(self, i, detail=None): self.set(i, "running", detail)
    def ok(self, i, detail=None): self.set(i, "ok", detail)
    def warn(self, i, detail=None): self.set(i, "warn", detail)
    def fail(self, i, detail=None): self.set(i, "bad", detail)
    def skip(self, i, detail=None): self.set(i, "skip", detail)

    def log(self, msg):
        with _LOCK:
            self.job["log"].append({"t": time.time(), "m": msg})

    def result(self, **kw):
        with _LOCK:
            self.job["result"].update(kw)

    def status(self, s):
        with _LOCK:
            self.job["status"] = s


def submit(kind, title, user, params, fn, meta=None):
    job = {"id": uuid.uuid4().hex[:10], "kind": kind, "title": title, "user": user.name, "params": params, "meta": meta or {},
           "status": "queued", "steps": [], "log": [], "result": {}, "created": time.time(), "finished": None}
    with _LOCK:
        _JOBS[job["id"]] = job
        _ORDER.append(job["id"])
        for old in _ORDER[:-200]:
            _JOBS.pop(old, None)
        del _ORDER[:-200]
    ctx = Ctx(job)

    def run():
        job["status"] = "running"
        audit.record(user.name, "job." + kind, title, "START", job=job["id"])
        try:
            fn(ctx)
            if job["status"] == "running":
                job["status"] = "success"
        except Exception as e:
            ctx.log("Unhandled error: %s" % e)
            ctx.result(error=str(e)[:400])
            traceback.print_exc()
            job["status"] = "failed"
            for s in job["steps"]:
                if s["status"] == "running":
                    s["status"] = "bad"; s["detail"] = str(e)[:200]
        job["finished"] = time.time()
        audit.record(user.name, "job." + kind, title, job["status"].upper(), job=job["id"], result=job["result"])

    threading.Thread(target=run, daemon=True).start()
    return job

def get(jid):
    with _LOCK:
        j = _JOBS.get(jid)
        return copy.deepcopy(j) if j else None

def list_jobs(user=None, limit=40):
    with _LOCK:
        out = []
        for jid in reversed(_ORDER):
            j = _JOBS.get(jid)
            if j and (user is None or j["user"] == user):
                out.append(copy.deepcopy(j))
            if len(out) >= limit:
                break
        return out
