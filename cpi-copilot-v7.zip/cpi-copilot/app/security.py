"""Security primitives: signed sessions, brute-force lockout, SSRF-safe tenant URLs, secret redaction."""
import base64, hashlib, hmac, ipaddress, json, re, secrets, threading, time
from urllib.parse import urlparse
from fastapi import HTTPException
import config

_REVOKED = set()
_FAIL = {}
_L = threading.Lock()


def _b64(b):
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()

def _unb64(s):
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))

def _sig(p):
    return _b64(hmac.new(config.SESSION_SECRET.encode(), p.encode(), hashlib.sha256).digest())


def issue_session(name, scopes):
    exp = int(time.time()) + config.SESSION_TTL_MIN * 60
    payload = json.dumps({"n": name, "s": sorted(scopes), "e": exp, "i": secrets.token_hex(6)}, separators=(",", ":")).encode()
    p = _b64(payload)
    return "st." + p + "." + _sig(p), exp


def verify_session(tok):
    try:
        _, p, sig = tok.split(".")
        if not hmac.compare_digest(sig, _sig(p)):
            return None
        d = json.loads(_unb64(p))
        if d["e"] < time.time() or d["i"] in _REVOKED:
            return None
        return d
    except Exception:
        return None


def revoke(tok):
    d = verify_session(tok)
    if d:
        _REVOKED.add(d["i"])
    return bool(d)


LOCK_AFTER, LOCK_WINDOW = 5, 300

def check_lock(ip):
    now = time.time()
    with _L:
        recent = [t for t in _FAIL.get(ip, []) if now - t < LOCK_WINDOW]
        _FAIL[ip] = recent
        if len(recent) >= LOCK_AFTER:
            raise HTTPException(429, "Too many failed attempts. Try again in a few minutes.")

def record_fail(ip):
    with _L:
        _FAIL.setdefault(ip, []).append(time.time())
        if len(_FAIL) > 5000:
            for k in list(_FAIL)[:1000]:
                _FAIL.pop(k, None)

def clear_fail(ip):
    with _L:
        _FAIL.pop(ip, None)


def validate_tenant_url(u, what="URL"):
    """Only https, no IP literals, no localhost, host must end with an allowed SAP domain (SSRF protection)."""
    p = urlparse((u or "").strip())
    if p.scheme != "https" or not p.hostname:
        raise ValueError(what + " must start with https://")
    host = p.hostname.lower()
    try:
        ipaddress.ip_address(host)
        raise ValueError(what + ": IP addresses are not allowed")
    except ValueError as e:
        if "not allowed" in str(e):
            raise
    if host in ("localhost",) or host.endswith((".local", ".internal", ".localhost")):
        raise ValueError(what + ": internal hosts are not allowed")
    if not any(host.endswith(s) for s in config.ALLOWED_SUFFIXES):
        raise ValueError("%s: host must end with %s (set ALLOWED_TENANT_SUFFIXES to extend)" % (what, " or ".join(config.ALLOWED_SUFFIXES)))
    if p.username or p.password:
        raise ValueError(what + ": credentials in URL are not allowed")
    return u.strip()


_SENS = re.compile(r"(secret|password|passwd|token|api[-_]?key|authorization|clientsecret|private|cookie|session)", re.I)
_PAT = [(re.compile(r"(?i)(bearer\s+)[A-Za-z0-9._\-~+/=]{8,}"), r"\1***"),
        (re.compile(r"(?i)((?:password|passwd|secret|token|apikey|api_key|client_secret)\s*[=:]\s*)[^\s,;&\"']+"), r"\1***")]

def redact(o, depth=0):
    if depth > 6:
        return "..."
    if isinstance(o, dict):
        return {k: ("***" if _SENS.search(str(k)) else redact(v, depth + 1)) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [redact(v, depth + 1) for v in o][:50]
    if isinstance(o, str):
        s = o
        for rx, rep in _PAT:
            s = rx.sub(rep, s)
        return s[:500]
    return o
