"""In-memory demo tenants that behave like Cloud Integration tenants (used by the sandbox and for tests)."""
import io, random, time, zipfile, threading, copy

CATALOG = {
    "OrderToCash": {"Name": "Order to Cash", "ShortText": "Sales order and invoice integration", "Vendor": "ACME",
                    "iflows": {"CustomerOrder": ("Customer Order Replication", ["S4_ORDER_CRED"], ["https://s4.acme.example/sap/opu/odata/sap/API_SALES_ORDER_SRV"], ["PlantCodes"]),
                               "S4_Invoice_IDoc": ("S/4 Invoice IDoc", ["S4_IDOC_CRED"], ["https://s4.acme.example/sap/bc/idoc_xml"], ["PaymentTerms"]),
                               "OrderStatus_Notify": ("Order Status Notification", ["SERVICENOW_OAUTH"], ["https://acme.service-now.example/api/now/table/incident"], [])},
                    "vms": {"PlantCodes": "Plant Codes", "PaymentTerms": "Payment Terms"}, "scripts": {"CommonUtils": "Common Utils"}},
    "HRSync": {"Name": "HR Data Sync", "ShortText": "SuccessFactors to Salesforce employee sync", "Vendor": "ACME",
               "iflows": {"EmployeeSF_to_Salesforce": ("Employee SF to Salesforce", ["SF_ODATA_CRED", "SALESFORCE_OAUTH"], ["https://api.successfactors.example/odata/v2/User", "https://acme.my.salesforce.example/services/data"], ["CountryCodes"]),
                          "Payroll_Export": ("Payroll Export", ["PAYROLL_SFTP"], ["sftp://payroll.acme.example"], [])},
               "vms": {"CountryCodes": "Country Codes"}, "scripts": {}},
    "VendorMgmt": {"Name": "Vendor Management", "ShortText": "Vendor master data synchronisation", "Vendor": "ACME",
                   "iflows": {"VendorSync": ("Vendor Sync", ["S4_VENDOR_CRED"], ["https://s4.acme.example/sap/opu/odata/sap/API_BUSINESS_PARTNER"], ["VendorCategories"]),
                              "VendorBank_Validate": ("Vendor Bank Validate", ["AZURE_BANKAPI"], ["https://bank.azure.example/validate"], [])},
                   "vms": {"VendorCategories": "Vendor Categories"}, "scripts": {"CommonUtils": "Common Utils"}},
    "Finance": {"Name": "Finance Postings", "ShortText": "GL and payment status integration", "Vendor": "ACME",
                "iflows": {"GL_Posting": ("GL Posting", ["S4_FIN_CRED"], ["https://s4.acme.example/sap/opu/odata/sap/API_JOURNAL_ENTRY"], []),
                           "Payment_Status_Notify": ("Payment Status Notify", ["SERVICENOW_OAUTH"], ["https://acme.service-now.example/api/now/table/incident"], ["PaymentTerms"])},
                "vms": {"PaymentTerms": "Payment Terms"}, "scripts": {"CommonUtils": "Common Utils"}},
}
LAYOUT = {"DEV": ["OrderToCash", "HRSync", "VendorMgmt", "Finance"], "QA": ["OrderToCash", "HRSync", "VendorMgmt"],
          "UAT": ["OrderToCash", "HRSync"], "PREPROD": ["OrderToCash"], "PROD": ["OrderToCash"]}
ERRORS = [
    ("S4_Invoice_IDoc", "javax.net.ssl.SSLHandshakeException: PKIX path building failed: sun.security.provider.certpath.SunCertPathBuilderException: unable to find valid certification path to requested target", 1.0),
    ("EmployeeSF_to_Salesforce", "HTTP 401 Unauthorized: invalid_client - client credentials are invalid for https://acme.my.salesforce.example", 0.7),
    ("VendorSync", "java.net.SocketTimeoutException: Read timed out while calling https://s4.acme.example/sap/opu/odata/sap/API_BUSINESS_PARTNER", 0.6),
    ("CustomerOrder", "org.xml.sax.SAXParseException: cvc-complex-type.2.4.b: schema validation failed, mandatory element Plant is missing", 0.5),
    ("OrderStatus_Notify", "HTTP 429 Too Many Requests from ServiceNow, rate limit exceeded", 0.4),
    ("GL_Posting", "OData error 500 from /sap/opu/odata/sap/API_JOURNAL_ENTRY: posting period closed", 0.3),
]


def make_content(kind, aid, name, version, creds=(), endpoints=(), vms=()):
    from xml.sax.saxutils import escape
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("META-INF/MANIFEST.MF", "Bundle-SymbolicName: %s\nBundle-Version: %s\nBundle-Name: %s\n" % (aid, version, name))
        if kind == "iflow":
            P = lambda k, v: "<ifl:property><key>%s</key><value>%s</value></ifl:property>" % (k, escape(str(v)))
            ext = lambda *p: "<bpmn2:extensionElements>" + "".join(p) + "</bpmn2:extensionElements>"
            exc = (sum(map(ord, aid)) % 3) != 0
            flows = '<bpmn2:messageFlow id="MF_in" name="HTTPS" sourceRef="P_S" targetRef="Start">%s</bpmn2:messageFlow>' % ext(P("ComponentType", "HTTPS"), P("direction", "Sender"), P("authenticationType", "RoleBased"))
            for i, e in enumerate(endpoints or ["https://receiver.example/api"]):
                c = creds[i] if i < len(creds) else (creds[0] if creds else "")
                auth = "OAuth2ClientCredentials" if c else "None"
                flows += '<bpmn2:messageFlow id="MF_out%d" name="HTTP" sourceRef="Send" targetRef="P_R">%s</bpmn2:messageFlow>' % (i, ext(P("Name", "HTTP"), P("direction", "Receiver"), P("MessageProtocol", "REST"), P("address", e), P("authenticationType", auth), P("credentialName", c), P("httpRequestTimeout", "60000" if i == 0 else "")))
            vm_steps = "".join('<bpmn2:callActivity id="VM%d" name="Map values">%s</bpmn2:callActivity>' % (i, ext(P("activityType", "ValueMapping"), P("valueMappingId", v))) for i, v in enumerate(vms))
            sub = ('<bpmn2:subProcess id="Err" name="Exception Subprocess" triggeredByEvent="true">%s<bpmn2:startEvent id="ES" name="Error Start"/></bpmn2:subProcess>' % ext(P("activityType", "ErrorEventSubProcessTemplate"))) if exc else ""
            x = ('<?xml version="1.0" encoding="UTF-8"?><bpmn2:definitions xmlns:bpmn2="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:ifl="http:///com.sap.ifl.model/Ifl.xsd" id="D">'
                 '<bpmn2:collaboration id="C"><bpmn2:participant id="P_S" ifl:type="EndpointSender" name="Sender"/><bpmn2:participant id="P_R" ifl:type="EndpointRecevier" name="Receiver"/>%s</bpmn2:collaboration>'
                 '<bpmn2:process id="Pr"><bpmn2:startEvent id="Start" name="Start"/><bpmn2:callActivity id="Enr" name="Set properties">%s</bpmn2:callActivity>%s'
                 '<bpmn2:callActivity id="Scr" name="Enrich">%s</bpmn2:callActivity><bpmn2:serviceTask id="Send" name="Send to receiver">%s</bpmn2:serviceTask><bpmn2:endEvent id="End" name="End"/>%s</bpmn2:process></bpmn2:definitions>') % (
                flows, ext(P("activityType", "Enricher")), vm_steps, ext(P("activityType", "Script"), P("script", "Main.groovy")), ext(P("activityType", "ExternalCall")), sub)
            z.writestr("src/main/resources/scenarioflows/integrationflow/%s.iflw" % aid, x)
            z.writestr("src/main/resources/script/Main.groovy", "import com.sap.gateway.ip.core.customdev.util.Message\ndef Message processData(Message message) {\n  return message\n}\n")
        else:
            z.writestr("src/main/resources/content/%s.xml" % aid, "<content id='%s' version='%s'/>" % (aid, version))
    return buf.getvalue()


class DemoCPI:
    demo = True

    def __init__(self, name, stage, seed):
        self.name, self.stage = name, stage
        self.rnd = random.Random(seed)
        self.lock = threading.RLock()
        self.pk = {}            # package id -> meta
        self.art = {}           # (kind,id) -> {Name, Version, PackageId, content}
        self.runtime = {}       # id -> status
        self.fail_ids = set()   # artifact ids that fail health check after deploy
        self.latency = 120 + seed % 200
        si = ["DEV", "QA", "UAT", "PREPROD", "PROD"].index(stage)
        self.creds = {"S4_ORDER_CRED", "S4_IDOC_CRED", "S4_VENDOR_CRED", "S4_FIN_CRED", "SF_ODATA_CRED", "SERVICENOW_OAUTH", "AZURE_BANKAPI"}
        if stage in ("PREPROD", "PROD"):
            self.creds.discard("SERVICENOW_OAUTH")
        if stage != "DEV":
            self.creds.add("SALESFORCE_OAUTH")
        base_days = [45, 120, 80, 21, 14][si]
        self.certs = [("sf_api_root", base_days - 5), ("s4_tls", base_days + 40), ("vendor_gateway", base_days + 150), ("azure_blob", base_days + 260)]
        self.msgs24 = int([1800, 4200, 6100, 11800, 54000][si] * (0.9 + self.rnd.random() * 0.2))
        self.series = [int(self.msgs24 / 24 * (0.5 + self.rnd.random())) for _ in range(24)]
        for pid in LAYOUT[stage]:
            c = CATALOG[pid]
            ver = "1.0.%d" % (self.rnd.randint(3, 9) if stage != "PROD" else self.rnd.randint(0, 2))
            self.pk[pid] = {"Id": pid, "Name": c["Name"], "Version": ver, "ShortText": c["ShortText"], "Vendor": c["Vendor"], "Mode": "EDIT_ALLOWED"}
            for aid, (nm, cr, ep, vm) in c["iflows"].items():
                self._put("iflow", aid, nm, pid, ver, cr, ep, vm)
            for aid, nm in c["vms"].items():
                self._put("vm", aid, nm, pid, ver)
            for aid, nm in c["scripts"].items():
                self._put("script", aid, nm, pid, ver)
        # failed messages
        self.failed = []
        n = [34, 21, 14, 9, 7][si]
        for i in range(n):
            cand = [e for e in ERRORS if e[0] in {a for (k, a) in self.art if k == "iflow"} and self.rnd.random() < e[2] + 0.2]
            if not cand:
                continue
            e = self.rnd.choice(cand)
            self.failed.append({"MessageGuid": "AF%s%02d" % (format(self.rnd.getrandbits(52), "x"), i), "IntegrationFlowName": e[0], "Status": "FAILED",
                                "LogEnd": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() - self.rnd.randint(60, 80000))),
                                "CorrelationId": "CID" + format(self.rnd.getrandbits(40), "x"), "Sender": "SRC_" + e[0][:6], "Receiver": "RCV_" + e[0][:6], "_err": e[1]})
        self.failed.sort(key=lambda m: m["LogEnd"], reverse=True)
        # queues
        self.q = {"Order_Inbound": [], "Order_Error": [], "HR_Inbound": [], "HR_Error": []}
        for i in range(max(3, n // 2)):
            q = self.rnd.choice(["Order_Error", "HR_Error"])
            self.q[q].append({"JmsMessageId": "ID:%s" % format(self.rnd.getrandbits(64), "x"), "Status": "FAILED", "RetryCount": self.rnd.randint(1, 9),
                              "Created": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(time.time() - self.rnd.randint(300, 70000))),
                              "Sender": "SRC_" + q[:2], "Error": self.rnd.choice(["HTTP 503 from receiver", "SocketTimeoutException", "401 Unauthorized"])})
        for i in range(self.rnd.randint(0, 4)):
            self.q["Order_Inbound"].append({"JmsMessageId": "ID:%s" % format(self.rnd.getrandbits(64), "x"), "Status": "WAITING", "RetryCount": 0,
                                            "Created": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime()), "Sender": "SRC_Or", "Error": None})

    def _put(self, kind, aid, name, pid, ver, cr=(), ep=(), vm=()):
        self.art[(kind, aid)] = {"Name": name, "Version": ver, "PackageId": pid, "content": make_content(kind, aid, name, ver, cr, ep, vm)}
        if kind in ("iflow", "vm", "script"):
            self.runtime[aid] = "STARTED"

    # ---- same interface as CPIClient ----
    def ping(self):
        time.sleep(0.15)
        return {"ok": True, "latency_ms": self.latency}

    def packages(self):
        return [dict(p) for p in self.pk.values()]

    def package_artifacts(self, pid):
        out = {"iflows": [], "valuemaps": [], "scripts": []}
        key = {"iflow": "iflows", "vm": "valuemaps", "script": "scripts"}
        for (k, a), v in self.art.items():
            if v["PackageId"] == pid:
                out[key[k]].append({"Id": a, "Name": v["Name"], "Version": v["Version"]})
        return out

    def export(self, kind, aid, version="active"):
        time.sleep(0.2)
        return self.art[(kind, aid)]["content"]

    def artifact_info(self, kind, aid, version="active"):
        v = self.art.get((kind, aid))
        return {"Id": aid, "Name": v["Name"], "Version": v["Version"], "PackageId": v["PackageId"]} if v else None

    def package_info(self, pid):
        return dict(self.pk[pid]) if pid in self.pk else None

    def create_package(self, meta):
        time.sleep(0.2)
        with self.lock:
            self.pk[meta["Id"]] = {"Id": meta["Id"], "Name": meta.get("Name"), "Version": meta.get("Version") or "1.0.0", "ShortText": meta.get("ShortText"), "Vendor": meta.get("Vendor"), "Mode": "EDIT_ALLOWED"}

    def import_artifact(self, kind, aid, name, pid, content):
        time.sleep(0.45)
        with self.lock:
            old = self.art.get((kind, aid))
            ver = old["Version"] if old else "1.0.0"
            parts = ver.split(".")
            parts[-1] = str(int(parts[-1]) + 1) if old else parts[-1]
            self.art[(kind, aid)] = {"Name": name, "Version": ".".join(parts), "PackageId": pid, "content": content}

    def deploy(self, kind, aid):
        time.sleep(0.3)
        with self.lock:
            self.runtime[aid] = "STARTING"
        threading.Timer(1.2, self._finish_deploy, args=(aid,)).start()

    def _finish_deploy(self, aid):
        with self.lock:
            self.runtime[aid] = "ERROR" if aid in self.fail_ids else "STARTED"

    def undeploy(self, aid):
        with self.lock:
            self.runtime.pop(aid, None)

    def runtime_artifacts(self):
        out = []
        for (k, a), v in self.art.items():
            if a in self.runtime:
                out.append({"Id": a, "Name": v["Name"], "Version": v["Version"], "Type": {"iflow": "INTEGRATION_FLOW", "vm": "VALUE_MAPPING", "script": "SCRIPT_COLLECTION"}[k], "Status": self.runtime[a], "DeployedBy": "demo.user", "DeployedOn": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() - 86400 * 3))})
        return out

    def runtime_status(self, aid):
        s = self.runtime.get(aid)
        if s is None:
            return {"Status": "NOT_DEPLOYED", "Error": None}
        return {"Status": s, "Error": ("Health check failed: HTTP 503 from endpoint" if s == "ERROR" else None)}

    def message_counts(self, hours=24):
        return self.msgs24, len(self.failed) * 3 + 2

    def failed_messages(self, top=50, hours=None, iflow=None):
        return self.search_messages(iflow=iflow, status="FAILED", hours=hours or 24, top=top)

    def error_text(self, guid):
        for m in self.failed:
            if m["MessageGuid"] == guid:
                return m["_err"]
        return ""

    def cert_expiry(self):
        return sorted([{"alias": a, "type": "Certificate", "days": d, "expires": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() + d * 86400))} for a, d in self.certs], key=lambda x: x["days"])

    def credential_aliases(self):
        return set(self.creds)

    def queues(self):
        return [{"Name": n, "State": "Started", "NumberOfMessages": len(m), "SizeInBytes": len(m) * 4096, "Exclusive": False} for n, m in self.q.items()]

    def queue_messages(self, queue, top=100):
        return copy.deepcopy(self.q.get(queue, []))[:top]

    def retry_messages(self, queue, ids):
        time.sleep(0.4)
        done = 0
        with self.lock:
            for m in list(self.q.get(queue, [])):
                if m["JmsMessageId"] in ids:
                    m["RetryCount"] += 1
                    if self.rnd.random() < 0.82:
                        self.q[queue].remove(m); done += 1
        return done

    def move_messages(self, source, target, ids):
        time.sleep(0.4)
        n = 0
        with self.lock:
            for m in list(self.q.get(source, [])):
                if m["JmsMessageId"] in ids:
                    self.q[source].remove(m); m["Status"] = "WAITING"; m["RetryCount"] = 0; m["Error"] = None
                    self.q.setdefault(target, []).append(m); n += 1
        return n

    # ---- accuracy-related additions (same interface as CPIClient) ----
    def _mpl_list(self):
        if getattr(self, "_mpl", None) is None:
            rnd = random.Random(self.latency)
            flows = [a for (k, a) in self.art if k == "iflow"]
            rows = []
            now = time.time()
            for m in self.failed:
                rows.append({"MessageGuid": m["MessageGuid"], "IntegrationFlowName": m["IntegrationFlowName"], "Status": "FAILED", "LogEnd": m["LogEnd"],
                             "LogStart": m["LogEnd"], "ProcessingMs": rnd.randint(40, 900), "CorrelationId": m["CorrelationId"], "ApplicationMessageId": "APP-" + m["CorrelationId"][-6:],
                             "Sender": m["Sender"], "Receiver": m["Receiver"], "_err": m["_err"]})
            for i in range(120):
                t = now - rnd.randint(30, 80000)
                f = rnd.choice(flows) if flows else "Flow"
                rows.append({"MessageGuid": "OK%s%03d" % (format(rnd.getrandbits(48), "x"), i), "IntegrationFlowName": f, "Status": rnd.choice(["COMPLETED"] * 14 + ["RETRY", "PROCESSING"]),
                             "LogEnd": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(t)), "LogStart": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(t - 1)), "ProcessingMs": rnd.randint(30, 1500),
                             "CorrelationId": "CID" + format(rnd.getrandbits(40), "x"), "ApplicationMessageId": "APP-%06d" % rnd.randint(0, 999999), "Sender": "SRC_" + f[:6], "Receiver": "RCV_" + f[:6], "_err": None})
            rows.sort(key=lambda r: r["LogEnd"], reverse=True)
            self._mpl = rows
        return self._mpl

    def message_stats(self, hours=24):
        failed = len(self.failed) * 3 + 2
        retry, proc = 2 + len(self.failed) // 6, 1
        return {"hours": hours, "total": self.msgs24, "by_status": {"COMPLETED": self.msgs24 - failed - retry - proc, "FAILED": failed, "RETRY": retry, "ESCALATED": 0, "PROCESSING": proc, "ABANDONED": 0}, "errors": {}}

    def message_sample(self, hours=24, cap=3000):
        failed_share = (len(self.failed) * 3 + 2) / max(1, self.msgs24)
        fs = [int(v * failed_share * (0.6 + self.rnd.random() * 0.8)) for v in self.series]
        flows = [a for (k, a) in self.art if k == "iflow"]
        by = {}
        for i, f in enumerate(flows):
            tot = int(self.msgs24 / max(1, len(flows)) * (1.3 - i * 0.15))
            by[f] = {"total": max(tot, 1), "failed": sum(1 for m in self.failed if m["IntegrationFlowName"] == f) * 3}
        return {"series": list(self.series), "failed_series": fs, "by_flow": by, "sampled": sum(self.series), "capped": False}

    def search_messages(self, iflow=None, status=None, correlation_id=None, app_msg_id=None, guid=None, hours=24, top=50):
        out = []
        for r in self._mpl_list():
            if iflow and r["IntegrationFlowName"] != iflow: continue
            if status and r["Status"] != status.upper(): continue
            if correlation_id and r["CorrelationId"] != correlation_id: continue
            if app_msg_id and r["ApplicationMessageId"] != app_msg_id: continue
            if guid and r["MessageGuid"] != guid: continue
            out.append({k: v for k, v in r.items() if not k.startswith("_")})
        return out[:max(1, min(int(top), 200))]

    def message_detail(self, guid):
        for r in self._mpl_list():
            if r["MessageGuid"] == guid:
                bad = r["Status"] == "FAILED"
                names = ["Start", "Set properties", "Enrich and trace", "Convert", "Send", "End"]
                steps = []
                for i, n in enumerate(names):
                    st = "COMPLETED"
                    if bad and n == "Send": st = "FAILED"
                    if bad and n == "End": st = "SKIPPED"
                    steps.append({"step": n, "status": st, "ms": 5 + i * 11 if st != "SKIPPED" else None})
                return {"guid": guid, "partial": {}, "log": {k: v for k, v in r.items() if not k.startswith("_")}, "error": r["_err"], "headers": [{"name": "Entity", "value": "order"}, {"name": "CorrelationId", "value": r["CorrelationId"]}], "steps": steps}
        return None

    def diagnose(self):
        names = [("OAuth token", "token endpoint", ""), ("Design time: packages", "/IntegrationPackages", "WorkspacePackagesEdit"), ("Runtime: deployed artifacts", "/IntegrationRuntimeArtifacts", "MonitoringDataRead"),
                 ("Monitoring: message logs", "/MessageProcessingLogs", "MonitoringDataRead"), ("Monitoring: message count", "/MessageProcessingLogs/$count", "MonitoringDataRead"),
                 ("Security: keystore", "/KeystoreEntries", ""), ("Security: user credentials", "/UserCredentials", ""), ("JMS: message queues", "/MessagingQueues", "DataStoresAndQueuesRead")]
        res = [{"name": n, "path": p, "ok": True, "status": 200, "ms": 40 + i * 13, "rows": (len(self.pk) if "packages" in n else len(self.runtime) if "artifacts" in n else None), "role": r, "message": "Simulated tenant"} for i, (n, p, r) in enumerate(names)]
        res[0]["scopes"] = ["MonitoringDataRead", "WorkspacePackagesEdit", "WorkspaceArtifactsDeploy", "DataStoresAndQueuesRead"]
        return res


_DEMO = {}

def build_demo():
    from store import STAGES
    d = {}
    if _DEMO:
        return {n: {"name": n, "stage": c.stage, "url": "https://demo-" + c.stage.lower() + ".it-cpi.example", "source": "demo", "demo": True} for n, c in _DEMO.items()}
    for i, st in enumerate(STAGES):
        name = "ACME-" + st
        c = DemoCPI(name, st, 100 + i * 17)
        _DEMO[name] = c
        d[name] = {"name": name, "stage": st, "url": "https://demo-" + st.lower() + ".it-cpi.example", "source": "demo", "demo": True}
    return d

def get(name):
    return _DEMO[name]
