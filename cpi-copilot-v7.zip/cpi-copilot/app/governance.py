"""Trust center: live control status computed from the real configuration, compliance mapping and the printable evidence pack."""
import os, platform, time
from html import escape
import audit, config
from store import store

REFS = {
    "transport": {"iso": "A.8.24, A.5.14", "soc2": "CC6.7", "owasp": "A02", "gdpr": "Art. 32"},
    "identity": {"iso": "A.5.16, A.8.5", "soc2": "CC6.1, CC6.2", "owasp": "A07", "gdpr": "Art. 32"},
    "keys": {"iso": "A.5.17", "soc2": "CC6.1", "owasp": "A07", "gdpr": "Art. 32"},
    "session": {"iso": "A.8.5", "soc2": "CC6.1", "owasp": "A07", "gdpr": "Art. 32"},
    "brute": {"iso": "A.8.5", "soc2": "CC6.1", "owasp": "A07", "gdpr": "Art. 32"},
    "authz": {"iso": "A.5.15, A.5.18, A.8.2, A.8.3", "soc2": "CC6.3", "owasp": "A01", "gdpr": "Art. 25, 32"},
    "four": {"iso": "A.5.3, A.8.32", "soc2": "CC6.3, CC8.1", "owasp": "A01, A08", "gdpr": "Art. 32", "sox": "ITGC change"},
    "path": {"iso": "A.8.31, A.8.32", "soc2": "CC8.1", "owasp": "A04", "sox": "ITGC change"},
    "rollback": {"iso": "A.8.32, A.8.14", "soc2": "CC8.1, A1.2", "sox": "ITGC change"},
    "ro": {"iso": "A.8.32", "soc2": "CC8.1"},
    "secrets": {"iso": "A.5.23, A.8.24", "soc2": "CC6.1", "owasp": "A02", "gdpr": "Art. 32"},
    "ssrf": {"iso": "A.8.20, A.8.26", "soc2": "CC6.6", "owasp": "A10"},
    "input": {"iso": "A.8.26, A.8.28", "soc2": "CC6.6", "owasp": "A03", "gdpr": "Art. 32"},
    "csp": {"iso": "A.8.28", "soc2": "CC6.6", "owasp": "A05, A03"},
    "audit": {"iso": "A.8.15", "soc2": "CC7.2, CC4.1", "owasp": "A09, A08", "gdpr": "Art. 30, 32", "sox": "ITGC logging"},
    "persist": {"iso": "A.8.15", "soc2": "CC7.2", "owasp": "A09", "sox": "ITGC logging"},
    "redact": {"iso": "A.8.15, A.5.34", "soc2": "CC6.1", "owasp": "A09", "gdpr": "Art. 5(1)(c), 32"},
    "supply": {"iso": "A.8.28, A.5.21", "soc2": "CC7.1", "owasp": "A06, A08"},
    "sandbox": {"iso": "A.8.31", "soc2": "CC6.1"},
    "minim": {"iso": "A.5.34, A.8.11", "soc2": "P3.1", "owasp": "", "gdpr": "Art. 5(1)(c), 25"},
}


def _sbom():
    out = []
    p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "requirements.txt")
    try:
        for line in open(p, encoding="utf-8"):
            line = line.strip()
            if line and not line.startswith("#"):
                n, _, v = line.partition("==")
                out.append({"name": n, "version": v or "unpinned", "pinned": bool(v)})
    except Exception:
        pass
    return out


def controls():
    ids = config.identities()
    xs = bool(config.xsuaa_credentials())
    named = len({i["name"] for i in ids})
    can_approve = xs or any("Approve" in i["scopes"] for i in ids)
    shortest = min([len(i["key"]) for i in ids] or [0])
    ok_chain, n_ev, bad = audit.verify()
    ui_t = [t for t in store.all().values() if t["source"] == "ui"]
    C = []
    def add(cid, name, status, detail):
        C.append({"id": cid, "name": name, "status": status, "detail": detail, "refs": REFS.get(cid, {})})
    add("transport", "Transport security", "ok", "TLS terminated by the SAP BTP router, HSTS sent, no cross-origin access (no CORS), cache disabled for API responses.")
    if xs:
        add("identity", "Identity and sign-in", "ok", "XSUAA / IAS tokens with role collections are accepted. Named access keys remain as a fallback.")
    elif named >= 2:
        add("identity", "Identity and sign-in", "warn", "%d named identities (%s). Actions and approvals are attributable per identity. Single sign-on with IAS or Entra ID is recommended for production." % (named, ", ".join(sorted({i["name"] for i in ids}))))
    elif named == 1:
        add("identity", "Identity and sign-in", "bad" if config.STRICT else "warn", "One shared key: every action is attributed to the same identity. Set APPROVER_KEY and VIEWER_KEY, or bind XSUAA.")
    else:
        add("identity", "Identity and sign-in", "bad", "No credentials configured. Only sandbox sessions can sign in.")
    add("keys", "Key strength", "ok" if shortest >= 24 else ("warn" if shortest >= 16 else "bad") if ids else "info",
        "Shortest configured key has %d characters (24 or more recommended). Keys are compared in constant time and never logged." % shortest if ids else "No keys configured.")
    add("session", "Session handling", "ok", "Signed expiring tokens (%d min, sliding renewal), revoked on sign-out. The browser keeps the token in sessionStorage, never the key.%s" % (config.SESSION_TTL_MIN, "" if config.SESSION_SECRET_PERSISTENT else " SESSION_SECRET is not set: sessions end when the app restarts."))
    add("brute", "Brute-force protection", "ok", "5 failed sign-ins in 5 minutes lock the client address (HTTP 429).")
    add("authz", "Authorization", "ok", "Seven scopes (Display, Develop, Transport, TransportProd, Remediate, Admin, Approve). Every tool and API checks its scope. Read-only identities are supported.")
    add("four", "Four-eyes approval", "ok" if can_approve else "warn", "A different signed-in person with the Approve scope must approve UAT, PRE-PROD and PROD changes. Parameters are hash-locked, requests expire after %d h, agents cannot approve." % config.APPROVAL_TTL_HOURS if can_approve else "No approver identity is configured, so gated changes cannot complete. Set APPROVER_KEY or bind XSUAA.")
    add("path", "Promotion path", "ok", "No backward moves and no skipped stages when an intermediate tenant is connected.")
    add("rollback", "Verification and rollback", "ok", "Target snapshot, runtime verification and automatic rollback on every move. One change per tenant at a time.")
    add("ro", "Read-only switch", "info", "ON: all changes are blocked in UI, API and MCP." if config.READ_ONLY else "OFF: changes are allowed after policy and approval. Set READ_ONLY=1 to freeze.")
    add("secrets", "Tenant secrets", "warn" if ui_t else "ok", ("%d tenant(s) added in the UI keep secrets in server memory. Prefer service bindings." % len(ui_t)) if ui_t else "Tenant credentials come from service bindings. They stay on the server and are never sent to the browser, logs or other tenants.")
    add("ssrf", "Outbound request protection", "ok", "Tenant and token URLs must be https and end with %s. IP addresses, localhost and internal hosts are rejected. Redirects are not followed." % " or ".join(config.ALLOWED_SUFFIXES))
    add("input", "Input validation and limits", "ok", "Request size limits, strict identifiers, escaped OData literals, per-user rate limits for tools and changes, zip and XML parsing limits (defusedxml).")
    add("csp", "Browser hardening", "ok", "Content-Security-Policy with script-src 'self' (no inline scripts), frame-ancestors none, nosniff, no-referrer, Permissions-Policy. Inline styles are still allowed.")
    add("audit", "Audit chain integrity", "ok" if ok_chain else "bad", ("%d events retained, hash chain intact." % n_ev) if ok_chain else "Hash chain broken at event %s." % bad)
    add("persist", "Audit persistence", "warn", "Events are kept in memory and written as JSON lines (type=audit) to the application log for SIEM collection. Export and verify endpoints exist. A persistent store is required for production.")
    add("redact", "Log redaction", "ok", "Secrets, tokens, passwords and authorization values are masked in audit events and logs.")
    add("supply", "Supply chain", "ok" if all(d["pinned"] for d in _sbom()) else "warn", "Dependencies are pinned to exact versions (see the SBOM section). Uploaded zip and XML content is size limited and parsed safely.")
    add("sandbox", "Sandbox sessions", "warn" if (config.SANDBOX and config.STRICT) else "info", "Enabled: simulated tenants only, no access to real tenants." if config.SANDBOX else "Disabled.")
    add("minim", "Data minimisation", "ok", "Message payloads are never stored or logged. Only log metadata and error text are read from tenants.")
    sc = [c for c in C if c["status"] != "info"]
    score = round(100 * sum(1 if c["status"] == "ok" else 0.5 if c["status"] == "warn" else 0 for c in sc) / max(1, len(sc)))
    return {"profile": config.PROFILE, "score": score, "controls": C, "counts": {s: len([c for c in C if c["status"] == s]) for s in ("ok", "warn", "bad", "info")}}


FRAMEWORKS = [("iso", "ISO/IEC 27001:2022 Annex A"), ("soc2", "SOC 2 Trust Services Criteria"), ("gdpr", "GDPR"), ("owasp", "OWASP Top 10 (2021)"), ("sox", "SOX ITGC")]
GAPS = ["Single sign-on (IAS, Entra ID) is not bound by default: the pilot uses named access keys.",
        "Audit events, jobs and approvals are held in memory; a restart clears them. Events are also written to the application log.",
        "Inline styles are still allowed by the Content-Security-Policy.",
        "The platform has not been independently penetration tested or certified.",
        "Queue retry and move, package import and deploy were verified against a simulator and mock tenants. Validate on a real DEV tenant before relying on them.",
        "No LLM is connected: the copilot is rule based, so it cannot misinterpret instructions through prompt injection, but it also understands fewer phrasings."]


def evidence_html(who):
    g = controls()
    ok_chain, n_ev, bad = audit.verify()
    h = audit.head()
    st = {"ok": "Active", "warn": "Partial", "bad": "Gap", "info": "Info"}
    rows = "".join("<tr><td>%s</td><td><b>%s</b></td><td>%s</td></tr>" % (escape(c["name"]), st[c["status"]], escape(c["detail"])) for c in g["controls"])
    ctl = {c["id"]: c for c in g["controls"]}
    fw = ""
    for key, title in FRAMEWORKS:
        fr = []
        refmap = {}
        for cid, refs in REFS.items():
            for r in [x.strip() for x in refs.get(key, "").split(",") if x.strip()]:
                refmap.setdefault(r, []).append(cid)
        for r in sorted(refmap):
            sts = [ctl[c]["status"] for c in refmap[r] if c in ctl]
            s = "Active" if sts and all(x in ("ok", "info") for x in sts) else "Partial" if sts and any(x in ("ok", "warn") for x in sts) else "Gap"
            fr.append("<tr><td>%s</td><td>%s</td><td>%s</td></tr>" % (escape(r), escape(", ".join(ctl[c]["name"] for c in refmap[r] if c in ctl)), s))
        fw += "<h3>%s</h3><table><tr><th>Reference</th><th>Supported by platform controls</th><th>Status</th></tr>%s</table>" % (escape(title), "".join(fr))
    sb = "".join("<tr><td>%s</td><td>%s</td></tr>" % (escape(d["name"]), escape(d["version"])) for d in _sbom())
    gaps = "".join("<li>%s</li>" % escape(x) for x in GAPS)
    return """<!doctype html><html><head><meta charset="utf-8"><title>Security and compliance evidence - %(p)s</title><style>
body{font-family:Segoe UI,Arial,sans-serif;margin:34px;color:#161b2e;max-width:1100px}h1{margin:0 0 4px}h2{margin-top:30px;border-bottom:2px solid #161b2e;padding-bottom:4px}h3{margin-top:20px}
table{border-collapse:collapse;width:100%%;margin:8px 0}th,td{border:1px solid #d5d9e6;padding:7px 10px;text-align:left;font-size:12.5px;vertical-align:top}th{background:#f1f3fa}
.k{display:inline-block;margin:10px 16px 0 0;padding:10px 16px;border-radius:10px;background:#f1f3fa}.k b{font-size:22px;display:block}.n{color:#5b6585;font-size:12px}code{background:#f1f3fa;padding:2px 6px;border-radius:5px}</style></head><body>
<h1>Security and compliance evidence</h1><div class="n">%(p)s %(v)s - designed and developed by %(a)s - generated %(t)s for %(w)s</div>
<div class="k"><b>%(score)s%%</b>control score</div><div class="k"><b>%(prof)s</b>security profile</div><div class="k"><b>%(ok)s / %(warn)s / %(bad)s</b>active / partial / gaps</div><div class="k"><b>%(chain)s</b>audit chain</div>
<p class="n">Indicative mapping prepared by the application owner. It shows which technical controls support each requirement. It is not a certification and not legal advice. Compliance owners must confirm the scope for each client.</p>
<h2>1. Control status (live from configuration)</h2><table><tr><th>Control</th><th>Status</th><th>How it works</th></tr>%(rows)s</table>
<h2>2. Framework mapping</h2>%(fw)s
<h2>3. Audit evidence</h2><p>Events recorded since start: <b>%(et)s</b>, retained: <b>%(er)s</b>. Hash chain verification: <b>%(chain)s</b>. Head hash: <code>%(hh)s</code><br>Store the head hash with your records to prove later that earlier events were not altered. Full export: <code>/api/audit/export</code>.</p>
<h2>4. Data handling and responsibility</h2><table><tr><th>Topic</th><th>Statement</th></tr>
<tr><td>Data read from tenants</td><td>Package and artifact metadata, runtime status, message log metadata and error text, certificate expiry, queue counts. Payloads are not read or stored.</td></tr>
<tr><td>Data stored by the platform</td><td>In memory only: sessions, jobs, approvals, audit chain, alert history. No database, no files.</td></tr>
<tr><td>Secrets</td><td>Tenant OAuth credentials come from service bindings. They are used server side and never returned to the browser or written to logs.</td></tr>
<tr><td>SAP BTP responsibility</td><td>Platform, runtime and network security, TLS termination, patching of the stack and buildpack.</td></tr>
<tr><td>Application responsibility</td><td>Authentication, authorization, approval workflow, input validation, audit, dependency management.</td></tr>
<tr><td>Customer responsibility</td><td>Identity provider and role assignment, least-privilege roles on each Process Integration Runtime instance, key rotation, log retention.</td></tr></table>
<h2>5. Known gaps</h2><ul>%(gaps)s</ul>
<h2>6. Software bill of materials</h2><table><tr><th>Package</th><th>Version</th></tr>%(sb)s</table><div class="n">Python %(py)s</div>
<p class="n">Print this page to save it as PDF.</p></body></html>""" % {
        "p": config.PRODUCT, "v": config.VERSION, "a": config.AUTHOR, "t": time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime()), "w": escape(who), "score": g["score"], "prof": g["profile"],
        "ok": g["counts"]["ok"], "warn": g["counts"]["warn"], "bad": g["counts"]["bad"], "chain": "intact" if ok_chain else "BROKEN", "rows": rows, "fw": fw, "et": h["events_total"], "er": h["retained"],
        "hh": h["head_hash"], "gaps": gaps, "sb": sb, "py": platform.python_version()}


def sbom():
    return {"product": config.PRODUCT, "version": config.VERSION, "python": platform.python_version(), "components": _sbom()}
