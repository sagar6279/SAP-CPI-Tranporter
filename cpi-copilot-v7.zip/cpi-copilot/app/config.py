import json, os, re, secrets

PRODUCT = "CPI Copilot"
VERSION = "0.7.0"
AUTHOR = "Pushapgiri Sagarareddy"

def _bool(name, default):
    return os.environ.get(name, "1" if default else "0").strip() == "1"

PROFILE = os.environ.get("SECURITY_PROFILE", "pilot").strip().lower()
if PROFILE not in ("pilot", "strict"):
    PROFILE = "pilot"
STRICT = PROFILE == "strict"

LOCAL_DEV = os.environ.get("LOCAL_DEV") == "1"
SANDBOX = _bool("SANDBOX", not STRICT)
ALLOW_UI_TENANTS = _bool("ALLOW_UI_TENANTS", not STRICT)
READ_ONLY = _bool("READ_ONLY", False)
SESSION_TTL_MIN = int(os.environ.get("SESSION_TTL_MIN", "30" if STRICT else "480"))
SESSION_SECRET_PERSISTENT = bool(os.environ.get("SESSION_SECRET"))
SESSION_SECRET = os.environ.get("SESSION_SECRET") or secrets.token_hex(32)
MIN_CERT_DAYS = int(os.environ.get("MIN_CERT_DAYS", "30"))
VERIFY_TIMEOUT = int(os.environ.get("VERIFY_TIMEOUT", "90"))
POLL_SECONDS = int(os.environ.get("POLL_SECONDS", "120"))
NOTIFY_WEBHOOK_URL = os.environ.get("NOTIFY_WEBHOOK_URL", "")
NOTIFY_ON_CRITICAL = _bool("NOTIFY_ON_CRITICAL", False)
ALLOWED_SUFFIXES = [s.strip().lower() for s in os.environ.get("ALLOWED_TENANT_SUFFIXES", ".hana.ondemand.com,.cloud.sap").split(",") if s.strip()]
APPROVAL_TTL_HOURS = int(os.environ.get("APPROVAL_TTL_HOURS", "24"))

ALL_SCOPES = ["Display", "Develop", "Transport", "TransportProd", "Remediate", "Admin", "Approve"]
OP_SCOPES = [s.strip() for s in os.environ.get("OPERATOR_SCOPES", "Display,Develop,Transport,Remediate,Admin").split(",") if s.strip()]


def identities():
    """Named identities from environment keys. Each key is one person or role, so actions and approvals are attributable."""
    out = []
    def add(env, name, scopes):
        v = os.environ.get(env, "").strip()
        if v:
            out.append({"name": name, "key": v, "scopes": list(scopes), "env": env})
    add("ACCESS_KEY", "operator", OP_SCOPES)
    add("DEMO_API_KEY", "operator", OP_SCOPES)
    add("ADMIN_KEY", "admin", ALL_SCOPES)
    add("APPROVER_KEY", "approver", ["Display", "Approve"])
    add("VIEWER_KEY", "viewer", ["Display"])
    return out


def vcap():
    try:
        return json.loads(os.environ.get("VCAP_SERVICES", "{}"))
    except Exception:
        return {}

def xsuaa_credentials():
    v = vcap().get("xsuaa", [])
    return v[0]["credentials"] if v else None

def _ok(c):
    return isinstance(c, dict) and all(c.get(k) for k in ("url", "tokenurl", "clientid", "clientsecret")) \
        and "..." not in c["url"] and "..." not in c["tokenurl"]

def _norm(c):
    o = c.get("oauth") if isinstance(c.get("oauth"), dict) else c
    n = {"url": o.get("url") or c.get("url"), "tokenurl": o.get("tokenurl") or "", "clientid": o.get("clientid"), "clientsecret": o.get("clientsecret")}
    return n if _ok(n) else None

def discover():
    """Tenants found automatically from the service bindings (Process Integration Runtime) of this app."""
    out = {}
    for label, lst in vcap().items():
        if label in ("xsuaa", "application-logs", "user-provided"):
            continue
        for s in lst:
            c = s.get("credentials") or {}
            n = _norm(c)
            if n and (label == "it-rt" or "oauth" in c):
                out[s.get("instance_name") or s.get("name")] = {**n, "tags": s.get("tags", []), "auto": True}
    return out

def tenants():
    out = {}
    for svc in vcap().get("user-provided", []):
        if svc.get("name") == os.environ.get("CPI_TENANTS_SERVICE", "cpi-copilot-tenants"):
            for k, v in (svc.get("credentials") or {}).items():
                if isinstance(v, dict):
                    n = _norm(v)
                    if n:
                        out[k] = {**n, "stage": v.get("stage")}
    raw = os.environ.get("CPI_TENANTS_JSON")
    try:
        for k, v in (json.loads(raw) if raw else {}).items():
            n = _norm(v)
            if n:
                out[k] = {**n, "stage": v.get("stage")}
    except Exception:
        pass
    return out
