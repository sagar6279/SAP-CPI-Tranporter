"""Insight: iFlow review (static analysis), landscape drift across tenants, daily briefing."""
import io, re, time, zipfile, threading
from concurrent.futures import ThreadPoolExecutor
from defusedxml import ElementTree as ET
import monitor
from clients import client_for

NS_B = "http://www.omg.org/spec/BPMN/20100524/MODEL"
NS_I = "http://www.omg.org/spec/BPMN/20100524/MODEL"
IFL_TYPE = "{http:///com.sap.ifl.model/Ifl.xsd}type"
STAGE_ORDER = ["DEV", "QA", "UAT", "PREPROD", "PROD"]


def _local(t):
    return t.split("}")[-1]


def _props(el):
    d = {}
    for ext in el:
        if _local(ext.tag) == "extensionElements":
            for p in ext:
                if _local(p.tag) == "property":
                    k = p.findtext("key")
                    if k:
                        d[k] = p.findtext("value") or ""
    return d


def _cname(props):
    m = re.search(r"cname::([^/]+)", props.get("cmdVariantUri", ""))
    return props.get("activityType") or (m.group(1) if m else "")


GROOVY_RULES = [
    (r"\beval\s*\(|Eval\.|GroovyShell|Runtime\.getRuntime|ProcessBuilder|\.execute\(\)", "error", "Dangerous construct (dynamic evaluation or process execution)"),
    (r"(?i)(password|passwd|secret|apikey|api_key|token)\s*=\s*['\"][^'\"]{4,}['\"]", "error", "Hard-coded secret"),
    (r"addAttachmentAsString|setStringProperty\(\s*['\"]Payload", "warn", "Payload written to the message log (data protection risk)"),
    (r"Thread\.sleep", "warn", "Thread.sleep blocks a runtime thread"),
    (r"println\s", "info", "println output is not visible in message logs, use the message log API"),
]


def review_iflow(content, iid="iFlow"):
    with zipfile.ZipFile(io.BytesIO(content)) as z:
        infos = z.infolist()
        if len(infos) > 2000 or sum(i.file_size for i in infos) > 60 * 1024 * 1024:
            raise ValueError("Artifact is too large to analyse")
        iflw = [i for i in infos if i.filename.endswith(".iflw") and i.file_size < 20 * 1024 * 1024]
        if not iflw:
            raise ValueError("No iFlow definition found in the artifact")
        raw = z.read(iflw[0])
        root = ET.fromstring(raw)
        scripts = [(i.filename.split("/")[-1], z.read(i).decode("utf-8", "ignore")) for i in infos if i.filename.endswith(".groovy") and i.file_size < 2 * 1024 * 1024][:30]
        pp = next((z.read(i).decode("utf-8", "ignore") for i in infos if i.filename.endswith("parameters.prop")), "")
    steps, adapters, findings, creds, parts = [], [], [], set(), []
    exc, timer = False, False
    for el in root.iter():
        tag = _local(el.tag)
        if tag == "participant":
            parts.append({"name": el.get("name"), "type": el.get(IFL_TYPE)})
        elif tag == "messageFlow":
            p = _props(el)
            addr = p.get("httpAddressWithoutQuery") or p.get("address") or p.get("urlPath") or p.get("host") or ""
            ad = {"direction": p.get("direction") or ("Sender" if p.get("ComponentType") else "Receiver"), "adapter": p.get("Name") or p.get("ComponentType") or "?",
                  "protocol": p.get("MessageProtocol") or "", "address": addr, "auth": p.get("authenticationType") or "", "credential": p.get("credentialName") or "", "timeout": p.get("httpRequestTimeout") or ""}
            adapters.append(ad)
            if ad["credential"]:
                creds.add(ad["credential"])
            if ad["direction"] == "Receiver":
                if addr.startswith("http://"):
                    findings.append({"level": "error", "text": "%s receiver uses unencrypted http://" % ad["adapter"]})
                elif addr.startswith("https://"):
                    findings.append({"level": "warn", "text": "%s address is hard-coded, externalise it as a parameter" % ad["adapter"]})
                if ad["auth"] in ("None", "") and ad["adapter"] in ("HTTP", "OData", "SOAP", "SuccessFactors"):
                    findings.append({"level": "warn", "text": "%s receiver has no authentication configured" % ad["adapter"]})
                if ad["auth"] == "Basic":
                    findings.append({"level": "info", "text": "%s uses Basic authentication, prefer OAuth 2.0 where the receiver supports it" % ad["adapter"]})
                if ad["auth"] not in ("None", "", "RoleBased") and not ad["credential"]:
                    findings.append({"level": "warn", "text": "%s has authentication but no credential alias" % ad["adapter"]})
                if ad["adapter"] in ("HTTP", "OData") and not ad["timeout"]:
                    findings.append({"level": "info", "text": "%s has no request timeout set (default applies)" % ad["adapter"]})
        elif tag in ("callActivity", "serviceTask", "scriptTask", "exclusiveGateway", "parallelGateway", "subProcess", "startEvent", "endEvent", "intermediateCatchEvent", "boundaryEvent"):
            p = _props(el)
            kind = _cname(p) or tag
            if tag == "subProcess" and el.get("triggeredByEvent") == "true":
                exc = True
            if tag == "startEvent" and any(_local(c.tag) == "timerEventDefinition" for c in el):
                timer = True
            steps.append({"type": kind, "name": el.get("name") or kind})
    if not exc:
        findings.append({"level": "warn", "text": "No exception subprocess: failures end without custom handling or escalation"})
    if len(steps) > 40:
        findings.append({"level": "info", "text": "Large flow (%d steps): consider splitting with ProcessDirect" % len(steps)})
    sc = []
    for name, src in scripts:
        fl = [{"level": lv, "text": tx} for rx, lv, tx in GROOVY_RULES if re.search(rx, src)]
        sc.append({"name": name, "lines": src.count("\n") + 1, "findings": fl})
        findings += [{"level": x["level"], "text": "%s: %s" % (name, x["text"])} for x in fl]
    if re.search(r"(?im)^(password|secret|token)\w*\s*=\s*\S+", pp):
        findings.append({"level": "error", "text": "parameters.prop contains a secret value"})
    senders = [a for a in adapters if a["direction"] == "Sender"]
    receivers = [a for a in adapters if a["direction"] == "Receiver"]
    trig = "a timer" if timer else ("incoming " + "/".join(sorted({a["adapter"] for a in senders})) + " calls" if senders else "an incoming call")
    types = {}
    for s in steps:
        if s["type"] not in ("startEvent", "endEvent", "subProcess"):
            types[s["type"]] = types.get(s["type"], 0) + 1
    summary = "%s is triggered by %s, runs %d steps%s, and sends to %s. %s." % (
        iid, trig, len([s for s in steps if s["type"] not in ("startEvent", "endEvent")]), (" (" + ", ".join("%s x%d" % (k, v) for k, v in list(types.items())[:5]) + ")") if types else "",
        (", ".join("%s%s" % (a["adapter"], (" (" + a["auth"] + ")") if a["auth"] else "") for a in receivers) or "no receiver found"),
        "It has exception handling" if exc else "It has no exception handling")
    score = max(0, 100 - 25 * sum(f["level"] == "error" for f in findings) - 8 * sum(f["level"] == "warn" for f in findings) - 2 * sum(f["level"] == "info" for f in findings))
    params = sorted(set(re.findall(r"\{\{([A-Za-z0-9_.]+)\}\}", raw.decode("utf-8", "ignore"))))
    return {"id": iid, "summary": summary, "score": score, "parameters": params, "steps": steps[:80], "adapters": adapters, "credentials": sorted(creds), "scripts": sc, "findings": findings[:60],
            "counts": {"error": sum(f["level"] == "error" for f in findings), "warn": sum(f["level"] == "warn" for f in findings), "info": sum(f["level"] == "info" for f in findings)}}


# ---------- drift ----------
_inv_cache = {}


def _inventory(t):
    hit = _inv_cache.get(t["name"])
    if hit and time.time() - hit[0] < 60:
        return hit[1]
    c = client_for(t["name"])
    inv = {}
    for p in c.packages():
        a = c.package_artifacts(p["Id"])
        for key, kind in (("iflows", "iFlow"), ("valuemaps", "Value mapping"), ("scripts", "Script collection")):
            for x in a.get(key, []):
                inv[(p["Id"], kind, x["Id"])] = {"name": x["Name"], "version": x["Version"], "package": p["Name"]}
    _inv_cache[t["name"]] = (time.time(), inv)
    return inv


def _vkey(v):
    return tuple(int(x) if x.isdigit() else 0 for x in re.split(r"[.\-]", str(v or "0")))


def landscape_drift(tenants):
    tenants = sorted(tenants, key=lambda t: (STAGE_ORDER.index(t["stage"]) if t["stage"] in STAGE_ORDER else 9, t["name"]))
    errors, invs = {}, {}
    def get(t):
        try:
            return t["name"], _inventory(t), None
        except Exception as e:
            return t["name"], None, str(e)[:160]
    with ThreadPoolExecutor(max_workers=4) as ex:
        for n, inv, err in ex.map(get, tenants):
            if err:
                errors[n] = err
            else:
                invs[n] = inv
    names = [t["name"] for t in tenants if t["name"] in invs]
    keys = sorted({k for inv in invs.values() for k in inv})
    rows, summ = [], {"in_sync": 0, "drift": 0, "missing": 0}
    for k in keys:
        vers = {n: (invs[n].get(k) or {}).get("version") for n in names}
        present = [v for v in vers.values() if v]
        nm = next((invs[n][k]["name"] for n in names if k in invs[n]), k[2])
        if len(present) < len(names):
            state = "missing"
        elif len(set(present)) > 1:
            state = "drift"
        else:
            state = "in_sync"
        summ[state] += 1
        top = max(present, key=_vkey) if present else None
        rows.append({"package": next((invs[n][k]["package"] for n in names if k in invs[n]), k[0]), "package_id": k[0], "kind": k[1], "id": k[2], "name": nm, "versions": vers, "state": state, "latest": top})
    rows.sort(key=lambda r: ({"drift": 0, "missing": 1, "in_sync": 2}[r["state"]], r["package"], r["id"]))
    return {"tenants": [{"name": t["name"], "stage": t["stage"]} for t in tenants if t["name"] in invs], "rows": rows[:600], "summary": summ, "errors": errors}


# ---------- briefing ----------
def briefing(user_name, tenants, jobs_list, pending):
    alerts, ovs = monitor.all_alerts(tenants)
    crit = [a for a in alerts if a["severity"] == "critical"]
    items = []
    for a in alerts[:8]:
        items.append({"severity": a["severity"], "text": "%s: %s (%s)" % (a["tenant"], a["title"], a["detail"]), "action": a["action"]})
    conn = [o for o in ovs if o.get("connected")]
    tot = sum(o.get("messages_24h") or 0 for o in conn)
    fail = sum(o.get("failed_24h") or 0 for o in conn)
    unknown = [o["name"] for o in conn if o.get("messages_24h") is None]
    names = {t["name"] for t in tenants}
    events = monitor.history(names, 30)
    new_since = [e for e in events if e["type"] == "raised" and time.time() - e["ts"] < 86400]
    done = [j for j in jobs_list if time.time() - j["created"] < 86400]
    parts = ["%d tenant%s connected" % (len(conn), "" if len(conn) == 1 else "s")]
    if tot:
        parts.append("%s messages in 24h, %s failed (%.2f%%)" % (format(tot, ","), format(fail, ","), fail / tot * 100))
    else:
        parts.append("no message traffic in 24h" if not unknown else "message statistics not readable on %s" % ", ".join(unknown))
    headline = ("%d critical" % len(crit) if crit else "No critical alerts") + ", %d warning%s. " % (len(alerts) - len(crit), "" if len(alerts) - len(crit) == 1 else "s") + "; ".join(parts) + "."
    return {"headline": headline, "generated": time.time(), "items": items, "new_alerts_24h": len(new_since), "operations_24h": {"total": len(done), "success": sum(j["status"] == "success" for j in done),
            "rolled_back": sum(j["status"] == "rolled_back" for j in done), "failed": sum(j["status"] == "failed" for j in done)}, "pending_approvals": pending,
            "tenants": [{"name": o["name"], "stage": o["stage"], "health": o.get("health"), "label": o.get("health_label"), "failed": o.get("failed_24h"), "messages": o.get("messages_24h")} for o in ovs]}
