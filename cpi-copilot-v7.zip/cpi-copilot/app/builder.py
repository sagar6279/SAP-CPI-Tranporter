"""AI iFlow Builder: natural language -> design (spec) -> artifacts (iFlow, Groovy, value mapping, parameters, docs) -> lint.
Template based generation (reliable). An LLM (SAP Generative AI Hub) can replace parse_prompt() to fill the same spec."""
import io, re, time, uuid, zipfile, threading
from xml.sax.saxutils import escape

SYSTEMS = {
    "successfactors": {"label": "SuccessFactors", "adapter": "SuccessFactors", "proto": "ODataV2", "addr": "https://api4.successfactors.com/odata/v2/User", "auth": "basic", "kw": ["successfactors", "employee central"]},
    "s4hana": {"label": "SAP S/4HANA", "adapter": "OData", "proto": "ODataV2", "addr": "https://s4.example.com/sap/opu/odata/sap/API_BUSINESS_PARTNER", "auth": "basic", "kw": ["s/4", "s4hana", "s4 ", "ecc"]},
    "salesforce": {"label": "Salesforce", "adapter": "HTTP", "proto": "REST", "addr": "https://example.my.salesforce.com/services/data/v59.0/sobjects/Contact", "auth": "oauth", "kw": ["salesforce", "sfdc"]},
    "servicenow": {"label": "ServiceNow", "adapter": "HTTP", "proto": "REST", "addr": "https://example.service-now.com/api/now/table/incident", "auth": "oauth", "kw": ["servicenow", "service now"]},
    "azure": {"label": "Azure", "adapter": "HTTP", "proto": "REST", "addr": "https://example.azure-api.net/v1/data", "auth": "oauth", "kw": ["azure", "blob", "event hub"]},
    "rest": {"label": "REST API", "adapter": "HTTP", "proto": "REST", "addr": "https://api.example.com/v1/resource", "auth": "oauth", "kw": ["rest api", "https", "webhook"]},
    "soap": {"label": "SOAP service", "adapter": "SOAP", "proto": "SOAP", "addr": "https://soap.example.com/service", "auth": "basic", "kw": ["soap", "wsdl"]},
    "sftp": {"label": "SFTP server", "adapter": "SFTP", "proto": "SFTP", "addr": "sftp.example.com:22/inbound", "auth": "cert", "kw": ["sftp"]},
    "idoc": {"label": "SAP IDoc", "adapter": "IDoc", "proto": "IDoc", "addr": "https://s4.example.com/sap/bc/idoc_xml", "auth": "basic", "kw": ["idoc"]},
}
TEMPLATES = [
    {"id": "sf_sfdc", "title": "SuccessFactors to Salesforce", "prompt": "Read employee data from SuccessFactors, convert XML to JSON, send it to Salesforce with OAuth, with exception handling and retry", "tags": ["HR", "OAuth"]},
    {"id": "s4_sfdc", "title": "S/4HANA to Salesforce", "prompt": "Replicate business partners from S/4HANA to Salesforce every 15 minutes, convert XML to JSON, OAuth, exception handling", "tags": ["O2C", "OData"]},
    {"id": "rest_s4", "title": "REST inbound to S/4HANA", "prompt": "Receive JSON orders over HTTPS, convert JSON to XML and post to S/4HANA with basic authentication and error handling", "tags": ["Inbound", "JSON"]},
    {"id": "s4_sftp", "title": "S/4HANA invoices to SFTP", "prompt": "Read invoices from S/4HANA daily, convert XML to JSON and write a file to SFTP with certificate authentication", "tags": ["Batch", "SFTP"]},
    {"id": "idoc_snow", "title": "IDoc to ServiceNow incident", "prompt": "Receive IDoc from S/4HANA and create an incident in ServiceNow with OAuth and exception handling", "tags": ["Ops", "IDoc"]},
    {"id": "sf_azure", "title": "SuccessFactors to Azure", "prompt": "Read employee data from SuccessFactors every hour and send JSON to Azure with OAuth", "tags": ["HR", "Azure"]},
]
_BUILDS = {}
_LOCK = threading.Lock()


def parse_prompt(text, overrides=None):
    t = " " + text.lower() + " "
    found = {}
    for key, s in SYSTEMS.items():
        for kw in s["kw"]:
            i = t.find(kw)
            if i >= 0:
                found[key] = min(found.get(key, 10 ** 9), i)
    if "rest" in found and any(k in found for k in ("salesforce", "servicenow", "azure")):
        del found["rest"]
    ordered = sorted(found, key=lambda k: found[k])
    verbs = [t.find(v) for v in (" send ", " post ", " write ", " push ", " create ", " upload ", " deliver ") if v in t]
    sp = min(verbs) if verbs else None
    if len(ordered) >= 2:
        if sp is not None:
            before = [k for k in ordered if found[k] < sp]
            after = [k for k in ordered if found[k] >= sp]
            sender, receiver = (before[0] if before else ordered[0]), (after[-1] if after else ordered[-1])
        else:
            sender, receiver = ordered[0], ordered[-1]
    elif len(ordered) == 1:
        sender, receiver = ("rest", ordered[0]) if re.search(r"receive|inbound|expose", t) else (ordered[0], "rest")
    else:
        sender, receiver = "rest", "rest"
    if re.search(r"receive[s]?\s+(?:json|xml|\w+\s+)?(?:orders?|data|messages?)?\s*(?:over|via|through)\s+https", t) and sender == receiver:
        sender = "rest"
    if re.search(r"receive[s]?\s+json[^.]*over\s+https", t) and sender != "rest" and receiver != "rest":
        sender = "rest"
    auth = "oauth" if "oauth" in t else "basic" if "basic" in t else "cert" if re.search(r"certificate|mtls", t) else SYSTEMS[receiver]["auth"]
    conv = "xml2json" if re.search(r"xml\s*(?:to|2|->)\s*json", t) else "json2xml" if re.search(r"json\s*(?:to|2|->)\s*xml", t) else \
        ("xml2json" if SYSTEMS[sender]["proto"] in ("ODataV2", "IDoc") and SYSTEMS[receiver]["proto"] == "REST" else "none")
    sched = None
    m = re.search(r"every\s+(\d+)\s*(minute|min|hour|day)", t)
    if m:
        sched = {"n": int(m.group(1)), "unit": "minute" if m.group(2).startswith("min") else m.group(2)}
    elif re.search(r"\bdaily\b", t):
        sched = {"n": 1, "unit": "day"}
    elif re.search(r"\bhourly\b", t):
        sched = {"n": 1, "unit": "hour"}
    elif SYSTEMS[sender]["adapter"] in ("SuccessFactors", "OData", "SFTP"):
        sched = {"n": 1, "unit": "hour"}
    obj = next((o for o in ("employee", "business partner", "invoice", "order", "vendor", "material", "incident", "customer", "idoc") if o in t), "record")
    spec = {"sender": sender, "receiver": receiver, "auth": auth, "convert": conv, "schedule": sched, "retry": bool(re.search(r"retry|resilien", t)), "entity": obj, "prompt": text}
    if overrides:
        spec.update({k: v for k, v in overrides.items() if v})
    return spec


def _ids(spec):
    s, r = SYSTEMS[spec["sender"]]["label"], SYSTEMS[spec["receiver"]]["label"]
    clean = lambda x: re.sub(r"[^A-Za-z0-9]", "", x.replace("/", ""))
    ent = re.sub(r"[^A-Za-z0-9]", "", spec["entity"].title())
    return "%s_to_%s_%s" % (clean(s), clean(r), ent), "AI_%s_%s" % (clean(s), clean(r)), "%s to %s %s" % (s, r, spec["entity"].title())


def groovy_main(spec):
    return """import com.sap.gateway.ip.core.customdev.util.Message

// Generated by CPI Copilot - review before use.
def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message)
    def body = message.getBody(String) as String

    def corr = message.getHeaders().get('SAP_MessageProcessingLogCustomHeaderProperties') ?: UUID.randomUUID().toString()
    message.setProperty('CorrelationId', corr)
    message.setHeader('X-Correlation-Id', corr)

    if (messageLog != null) {
        messageLog.addCustomHeaderProperty('Entity', '%s')
        messageLog.addCustomHeaderProperty('CorrelationId', corr as String)
        // never log the payload, it can contain personal data
        messageLog.setStringProperty('PayloadSize', (body?.length() ?: 0) as String)
    }
    if (body == null || body.trim().isEmpty()) {
        throw new IllegalStateException('Empty %s payload received from %s')
    }
    return message
}
""" % (spec["entity"], spec["entity"], SYSTEMS[spec["sender"]]["label"])


def groovy_error(spec):
    return """import com.sap.gateway.ip.core.customdev.util.Message

// Exception handler: capture error details without exposing secrets or payload data.
def Message processData(Message message) {
    def ex = message.getProperty('CamelExceptionCaught')
    def messageLog = messageLogFactory.getMessageLog(message)
    def text = ex != null ? ex.getClass().getSimpleName() + ': ' + (ex.getMessage() ?: '') : 'unknown error'
    text = text.replaceAll(/(?i)(authorization|password|secret|token)=\\S+/, '$1=***')
    message.setProperty('ErrorText', text.take(500))
    if (messageLog != null) {
        messageLog.setStringProperty('ErrorSummary', text.take(500))
    }
    message.setBody('{"status":"error"}')
    return message
}
"""


def value_mapping(spec):
    sl, rl = SYSTEMS[spec["sender"]]["label"], SYSTEMS[spec["receiver"]]["label"]
    rows = [("Country", "US", "United States"), ("Country", "DE", "Germany"), ("Country", "IN", "India"), ("Country", "GB", "United Kingdom"), ("Status", "A", "Active"), ("Status", "I", "Inactive")]
    g = {}
    for k, a, b in rows:
        g.setdefault(k, []).append((a, b))
    x = '<?xml version="1.0" encoding="UTF-8"?>\n<valueMaps>\n'
    for k, items in g.items():
        x += '  <valueMap>\n    <group id="%s">\n' % k
        for a, b in items:
            x += '      <entry><value agency="%s" schema="%s">%s</value><value agency="%s" schema="%s">%s</value></entry>\n' % (escape(sl), k, escape(a), escape(rl), k, escape(b))
        x += "    </group>\n  </valueMap>\n"
    return x + "</valueMaps>\n"


def _p(k, v):
    return "<ifl:property><key>%s</key><value>%s</value></ifl:property>" % (k, escape(str(v)))


def _ext(*p):
    return "<bpmn2:extensionElements>" + "".join(p) + "</bpmn2:extensionElements>"


def iflow_xml(spec, iid, name):
    S, R = SYSTEMS[spec["sender"]], SYSTEMS[spec["receiver"]]
    authm = {"oauth": "OAuth2ClientCredentials", "basic": "Basic", "cert": "ClientCertificate"}[spec["auth"]]
    inbound = spec["sender"] in ("rest", "idoc", "soap") and not spec["schedule"]
    I = dict(start="StartEvent_2", cm="CallActivity_Props", pull="ServiceTask_Pull", gr="CallActivity_Script", conv="CallActivity_Convert", push="ServiceTask_Push", end="EndEvent_2",
             esub="SubProcess_Error", es="StartEvent_Err", esc="CallActivity_ErrScript", ee="EndEvent_Err")
    chain = [I["start"], I["cm"]] + ([] if inbound else [I["pull"]]) + [I["gr"]] + ([I["conv"]] if spec["convert"] != "none" else []) + [I["push"], I["end"]]
    seq = "\n  ".join('<bpmn2:sequenceFlow id="SequenceFlow_%d" sourceRef="%s" targetRef="%s"/>' % (i + 1, chain[i], chain[i + 1]) for i in range(len(chain) - 1))
    conv_act = "XmlToJsonConverter" if spec["convert"] == "xml2json" else "JsonToXmlConverter"

    def adapter(sysd, tag, method):
        return "".join([_p("componentVersion", "1.17"), _p("ComponentNS", "sap"), _p("ComponentSWCVName", "external"), _p("direction", "Receiver"), _p("Name", sysd["adapter"]),
                        _p("MessageProtocol", sysd["proto"]), _p("TransportProtocol", "HTTP" if sysd["adapter"] in ("HTTP", "SuccessFactors", "OData") else sysd["adapter"]),
                        _p("cmdVariantUri", "ctype::AdapterVariant/cname::%s/tp::HTTP/mp::%s/direction::Receiver/version::1.17.1" % (sysd["adapter"], sysd["proto"])),
                        _p("httpAddressWithoutQuery", "{{%s_Address}}" % tag), _p("httpMethod", method),
                        _p("authenticationType", authm if tag == "Receiver" else ("Basic" if S["auth"] == "basic" else authm)), _p("credentialName", "{{%s_Credential}}" % tag), _p("httpRequestTimeout", "60000")])
    timer = ""
    if spec["schedule"]:
        unit = {"minute": "minutes", "hour": "hours", "day": "days"}.get(spec["schedule"]["unit"], "hours")
        timer = '<bpmn2:timerEventDefinition id="TimerEventDefinition_1">%s</bpmn2:timerEventDefinition>' % _ext(_p("scheduleKey", "every %d %s" % (spec["schedule"]["n"], unit)))
    x = '<?xml version="1.0" encoding="UTF-8"?>\n<bpmn2:definitions xmlns:bpmn2="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:ifl="http:///com.sap.ifl.model/Ifl.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" id="Definitions_1">\n'
    x += ' <bpmn2:collaboration id="Collaboration_1" name="Default Collaboration">\n  ' + _ext(_p("namespaceMapping", ""), _p("httpSessionHandling", "None"), _p("returnExceptionToSender", "false"), _p("log", "All events"), _p("componentVersion", "1.2"), _p("cmdVariantUri", "ctype::IFlowVariant/cname::IFlowConfiguration/version::1.2.4")) + "\n"
    if inbound:
        x += '  <bpmn2:participant id="Participant_Sender" ifl:type="EndpointSender" name="%s"/>\n' % escape(S["label"])
    x += '  <bpmn2:participant id="Participant_Process" ifl:type="IntegrationProcess" name="Integration Process" processRef="Process_1"/>\n'
    if not inbound:
        x += '  <bpmn2:participant id="Participant_Source" ifl:type="EndpointRecevier" name="%s"/>\n' % escape(S["label"])
    x += '  <bpmn2:participant id="Participant_Target" ifl:type="EndpointRecevier" name="%s"/>\n' % escape(R["label"])
    if inbound:
        x += '  <bpmn2:messageFlow id="MessageFlow_In" name="HTTPS" sourceRef="Participant_Sender" targetRef="%s">%s</bpmn2:messageFlow>\n' % (I["start"], _ext(_p("ComponentType", "HTTPS"), _p("urlPath", "/" + iid.lower()), _p("authenticationType", "RoleBased"), _p("userRole", "ESBMessaging.send"), _p("direction", "Sender")))
    else:
        x += '  <bpmn2:messageFlow id="MessageFlow_Src" name="%s" sourceRef="%s" targetRef="Participant_Source">%s</bpmn2:messageFlow>\n' % (escape(S["adapter"]), I["pull"], _ext(adapter(S, "Source", "GET")))
    x += '  <bpmn2:messageFlow id="MessageFlow_Tgt" name="%s" sourceRef="%s" targetRef="Participant_Target">%s</bpmn2:messageFlow>\n </bpmn2:collaboration>\n' % (escape(R["adapter"]), I["push"], _ext(adapter(R, "Receiver", "POST")))
    x += ' <bpmn2:process id="Process_1" name="Integration Process">\n  ' + _ext(_p("transactionTimeout", "30"), _p("componentVersion", "1.2"), _p("cmdVariantUri", "ctype::FlowelementVariant/cname::IntegrationProcess/version::1.2.1")) + "\n"
    x += '  <bpmn2:startEvent id="%s" name="%s">%s%s</bpmn2:startEvent>\n' % (I["start"], "Timer" if spec["schedule"] else "Start", _ext(_p("componentVersion", "1.0"), _p("cmdVariantUri", "ctype::FlowstepVariant/cname::intermediatetimer/version::1.0" if spec["schedule"] else "ctype::FlowstepVariant/cname::MessageStartEvent/version::1.0")), timer)
    x += '  <bpmn2:callActivity id="%s" name="Set properties">%s</bpmn2:callActivity>\n' % (I["cm"], _ext(_p("activityType", "Enricher"), _p("cmdVariantUri", "ctype::FlowstepVariant/cname::Enricher/version::1.6.1")))
    if not inbound:
        x += '  <bpmn2:serviceTask id="%s" name="Read from %s">%s</bpmn2:serviceTask>\n' % (I["pull"], escape(S["label"]), _ext(_p("activityType", "ExternalCall"), _p("cmdVariantUri", "ctype::FlowstepVariant/cname::ExternalCall/version::1.0.4")))
    x += '  <bpmn2:callActivity id="%s" name="Enrich and trace">%s</bpmn2:callActivity>\n' % (I["gr"], _ext(_p("scriptFunction", "processData"), _p("scriptBundleId", "AI_Common_Script"), _p("activityType", "Script"), _p("subActivityType", "GroovyScript"), _p("script", "Main.groovy"), _p("cmdVariantUri", "ctype::FlowstepVariant/cname::GroovyScript/version::1.1.2")))
    if spec["convert"] != "none":
        x += '  <bpmn2:callActivity id="%s" name="%s">%s</bpmn2:callActivity>\n' % (I["conv"], "XML to JSON" if spec["convert"] == "xml2json" else "JSON to XML", _ext(_p("activityType", conv_act), _p("jsonOutputEncoding", "UTF-8"), _p("suppressRootElem", "true"), _p("cmdVariantUri", "ctype::FlowstepVariant/cname::%s/version::1.0.3" % conv_act)))
    x += '  <bpmn2:serviceTask id="%s" name="Send to %s">%s</bpmn2:serviceTask>\n' % (I["push"], escape(R["label"]), _ext(_p("activityType", "ExternalCall"), _p("cmdVariantUri", "ctype::FlowstepVariant/cname::ExternalCall/version::1.0.4")))
    x += '  <bpmn2:endEvent id="%s" name="End">%s</bpmn2:endEvent>\n  %s\n' % (I["end"], _ext(_p("cmdVariantUri", "ctype::FlowstepVariant/cname::MessageEndEvent/version::1.1.0")), seq)
    x += '  <bpmn2:subProcess id="%s" name="Exception Subprocess" triggeredByEvent="true">%s\n' % (I["esub"], _ext(_p("activityType", "ErrorEventSubProcessTemplate"), _p("cmdVariantUri", "ctype::FlowstepVariant/cname::ErrorEventSubProcessTemplate/version::1.1.0")))
    x += '   <bpmn2:startEvent id="%s" name="Error Start"><bpmn2:errorEventDefinition id="ErrorEventDefinition_1"/></bpmn2:startEvent>\n' % I["es"]
    x += '   <bpmn2:callActivity id="%s" name="Capture error">%s</bpmn2:callActivity>\n' % (I["esc"], _ext(_p("scriptFunction", "processData"), _p("scriptBundleId", "AI_Common_Script"), _p("activityType", "Script"), _p("subActivityType", "GroovyScript"), _p("script", "ErrorHandler.groovy")))
    x += '   <bpmn2:endEvent id="%s" name="Escalate"><bpmn2:errorEventDefinition id="ErrorEventDefinition_2"/></bpmn2:endEvent>\n' % I["ee"]
    x += '   <bpmn2:sequenceFlow id="SequenceFlow_E1" sourceRef="%s" targetRef="%s"/>\n   <bpmn2:sequenceFlow id="SequenceFlow_E2" sourceRef="%s" targetRef="%s"/>\n  </bpmn2:subProcess>\n </bpmn2:process>\n</bpmn2:definitions>\n' % (I["es"], I["esc"], I["esc"], I["ee"])
    return x


def params(spec):
    S, R = SYSTEMS[spec["sender"]], SYSTEMS[spec["receiver"]]
    al = lambda L: re.sub(r"[^A-Z0-9]", "", L.upper()) + "_CREDENTIAL"
    p = ["Receiver_Address=" + R["addr"], "Receiver_Credential=" + al(R["label"]), "Receiver_Timeout=60000"]
    if not (spec["sender"] in ("rest", "idoc", "soap") and not spec["schedule"]):
        p += ["Source_Address=" + S["addr"], "Source_Credential=" + al(S["label"])]
    if spec["schedule"]:
        p.append("Schedule=every %d %s" % (spec["schedule"]["n"], spec["schedule"]["unit"]))
    if spec["retry"]:
        p += ["Retry_Max=3", "Retry_Interval=PT1M"]
    return "\n".join(p) + "\n"


def lint(spec, files, iflw):
    r = []
    ok = lambda t: r.append({"level": "ok", "text": t})
    wn = lambda t, lv="warn": r.append({"level": lv, "text": t})
    ok("Exception subprocess is present") if ("triggeredByEvent" in iflw and "errorEventDefinition" in iflw) else wn("No exception subprocess", "error")
    pp = files["src/main/resources/parameters.prop"]
    wn("Possible hard-coded secret in parameters", "error") if re.search(r"(?im)^(password|secret|token)\w*=", pp) else ok("No secrets in parameters, credentials are referenced by alias")
    g = " ".join(v for k, v in files.items() if k.endswith(".groovy"))
    wn("Groovy contains blocked constructs", "error") if re.search(r"\beval\b|Runtime\.getRuntime|ProcessBuilder|\.execute\(\)", g) else ok("Groovy has no blocked constructs (eval, process execution)")
    wn("Payload is written to the message log", "error") if re.search(r"setStringProperty\('Payload'", g) else ok("Payload is not written to the message log")
    ok("Receiver address and credential alias are externalised parameters")
    if spec["auth"] == "oauth":
        wn("Create the OAuth2 Client Credentials artifact %s_CREDENTIAL in Security Material before deployment" % re.sub(r"[^A-Z0-9]", "", SYSTEMS[spec["receiver"]]["label"].upper()))
    if not spec["retry"]:
        wn("No retry configured. Add JMS retry if the receiver is idempotent")
    return r


def docs(spec, iid, name):
    S, R = SYSTEMS[spec["sender"]], SYSTEMS[spec["receiver"]]
    inbound = spec["sender"] in ("rest", "idoc", "soap") and not spec["schedule"]
    steps = ["Timer" if spec["schedule"] else "Start", "Set properties"] + ([] if inbound else ["Read " + S["label"]]) + ["Enrich (Groovy)"] + (["XML to JSON" if spec["convert"] == "xml2json" else "JSON to XML"] if spec["convert"] != "none" else []) + ["Send " + R["label"], "End"]
    trig = ("every %d %s" % (spec["schedule"]["n"], spec["schedule"]["unit"])) if spec["schedule"] else "inbound HTTPS call"
    return """# %s

Generated by CPI Copilot on %s. AI generated: review by an integration developer is mandatory before promotion.

## Requirement
%s

## Design
- Sender: %s (%s, %s)
- Receiver: %s (%s, %s)
- Authentication to receiver: %s
- Conversion: %s
- Trigger: %s
- Flow: %s

## Interface specification
| Item | Value |
| --- | --- |
| iFlow id | %s |
| Entity | %s |
| Receiver address parameter | Receiver_Address |
| Receiver credential alias | Receiver_Credential |
| Error handling | Exception subprocess, correlation id, error summary in the message log |

## Before first deployment
1. Create the security material for the credential aliases in parameters.prop (never inside the package).
2. Set Receiver_Address and Source_Address for the tenant in the iFlow configuration.
3. Open the iFlow in the designer and verify adapter properties (adapter versions differ per tenant release).
4. Run a test message in DEV, then move DEV to QA with CPI Copilot.

## Runbook
| Symptom | Likely cause | Action |
| --- | --- | --- |
| 401 from receiver | OAuth client or secret expired | Rotate the secret, update the credential alias |
| SSL handshake error | Receiver root CA missing | Upload the certificate to the keystore |
| Timeout | Receiver slow | Raise Receiver_Timeout, retry if idempotent |

## Test cases
1. A valid %s message is delivered and the receiver answers 2xx.
2. An empty payload raises an exception that the exception subprocess captures.
3. Receiver unavailable: the message ends in error and ErrorSummary is visible in the log.
""" % (name, time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime()), spec["prompt"], S["label"], S["adapter"], S["proto"], R["label"], R["adapter"], R["proto"],
       spec["auth"], spec["convert"], trig, " -> ".join(steps), iid, spec["entity"], spec["entity"])


def _zip(files):
    b = io.BytesIO()
    with zipfile.ZipFile(b, "w", zipfile.ZIP_DEFLATED) as z:
        for k, v in files.items():
            z.writestr(k, v)
    return b.getvalue()


def build(prompt, overrides=None):
    spec = parse_prompt(prompt, overrides)
    iid, pkg, name = _ids(spec)
    iflw = iflow_xml(spec, iid, name)
    gm, ge = groovy_main(spec), groovy_error(spec)
    files = {
        "META-INF/MANIFEST.MF": "Manifest-Version: 1.0\nBundle-ManifestVersion: 2\nBundle-Name: %s\nBundle-SymbolicName: %s; singleton:=true\nBundle-Version: 1.0.0\nSAP-BundleType: IntegrationFlow\nSAP-NodeType: IFLMAP\n" % (name, iid),
        "metainfo.prop": "description=%s (AI generated)\n" % name,
        "src/main/resources/scenarioflows/integrationflow/%s.iflw" % iid: iflw,
        "src/main/resources/script/Main.groovy": gm, "src/main/resources/script/ErrorHandler.groovy": ge,
        "src/main/resources/parameters.prop": params(spec),
        "src/main/resources/parameters.propdef": "<?xml version='1.0' encoding='UTF-8'?><parameters><param name='Receiver_Address' type='xs:string'/><param name='Receiver_Credential' type='xs:string'/></parameters>\n"}
    vmx = value_mapping(spec)
    vm = {"META-INF/MANIFEST.MF": "Manifest-Version: 1.0\nBundle-Name: %s_VM\nBundle-SymbolicName: %s_VM; singleton:=true\nBundle-Version: 1.0.0\nSAP-BundleType: ValueMapping\nSAP-NodeType: IFLMAP\n" % (iid, iid),
          "metainfo.prop": "description=Value mappings for %s\n" % name, "src/main/resources/value_mapping.xml": vmx}
    sc = {"META-INF/MANIFEST.MF": "Manifest-Version: 1.0\nBundle-Name: AI_Common_Script\nBundle-SymbolicName: AI_Common_Script; singleton:=true\nBundle-Version: 1.0.0\nSAP-BundleType: ScriptCollection\nSAP-NodeType: IFLMAP\n",
          "metainfo.prop": "description=scripts\n", "script/Main.groovy": gm, "script/ErrorHandler.groovy": ge}
    doc = docs(spec, iid, name)
    rec = {"id": uuid.uuid4().hex[:10], "spec": spec, "iflow_id": iid, "package_id": pkg, "name": name, "lint": lint(spec, files, iflw),
           "preview": {iid + ".iflw": iflw, "Main.groovy": gm, "ErrorHandler.groovy": ge, "parameters.prop": files["src/main/resources/parameters.prop"], "value_mapping.xml": vmx, "README.md": doc},
           "iflow_zip": _zip(files), "vm_zip": _zip(vm), "script_zip": _zip(sc), "created": time.time()}
    rec["bundle"] = _zip({iid + ".zip": rec["iflow_zip"], iid + "_ValueMapping.zip": rec["vm_zip"], "AI_Common_Script.zip": rec["script_zip"], "README.md": doc})
    with _LOCK:
        _BUILDS[rec["id"]] = rec
        for k in list(_BUILDS)[:-30]:
            _BUILDS.pop(k, None)
    return rec


def get(bid):
    with _LOCK:
        return _BUILDS.get(bid)


def public(rec):
    s, r = SYSTEMS[rec["spec"]["sender"]], SYSTEMS[rec["spec"]["receiver"]]
    return {"id": rec["id"], "iflow_id": rec["iflow_id"], "package_id": rec["package_id"], "name": rec["name"], "lint": rec["lint"], "files": rec["preview"],
            "spec": {**{k: v for k, v in rec["spec"].items() if k != "prompt"}, "sender_label": s["label"], "receiver_label": r["label"]}}


def import_into(client, rec):
    """Create package and import script collection, value mapping and iFlow. Not deployed: credentials must exist first."""
    if not client.package_info(rec["package_id"]):
        client.create_package({"Id": rec["package_id"], "Name": rec["name"] + " (AI)", "ShortText": "AI generated by CPI Copilot", "Vendor": "CPI Copilot", "Version": "1.0.0"})
    client.import_artifact("script", "AI_Common_Script", "AI Common Script", rec["package_id"], rec["script_zip"])
    client.import_artifact("vm", rec["iflow_id"] + "_VM", rec["name"] + " Value Mapping", rec["package_id"], rec["vm_zip"])
    client.import_artifact("iflow", rec["iflow_id"], rec["name"], rec["package_id"], rec["iflow_zip"])
    return {"package": rec["package_id"], "artifacts": [rec["iflow_id"], rec["iflow_id"] + "_VM", "AI_Common_Script"]}
