"""Tool registry: one set of capabilities for the web UI, the chat copilot and any MCP client (SAP Joule Studio, Claude, custom agents)."""
import time, threading
import access, actions, approvals, audit, builder, config, insight, jobs, monitor, ops, policy
from agents import failure, notify
from actions import ActionError
from clients import client_for
from cpi_client import CPIError
from store import store

TOOLS = {}
CALLS = []
_L = threading.Lock()
_RATE = {}


def tool(name, desc, props=None, required=None, write=False, scope="Display"):
    def deco(fn):
        TOOLS[name] = {"name": name, "description": desc, "write": write, "scope": scope, "fn": fn,
                       "inputSchema": {"type": "object", "properties": props or {}, "required": required or []}}
        return fn
    return deco


def _t(user, name):
    return access.tenant_for(user, name)


def _rate(user, limit=120):
    now = time.time()
    with _L:
        h = [x for x in _RATE.get(user.name, []) if now - x < 60]
        if len(h) >= limit:
            return False
        h.append(now); _RATE[user.name] = h
    return True


def call(user, name, args=None, via="chat", trace=None):
    t0 = time.time()
    args = args or {}
    if name not in TOOLS:
        raise KeyError("Unknown tool " + name)
    spec = TOOLS[name]
    try:
        if not user.has(spec["scope"]):
            res, ok = {"error": "Not permitted: missing scope " + spec["scope"]}, False
        elif not _rate(user):
            res, ok = {"error": "Too many tool calls, slow down"}, False
        elif spec["write"] and config.READ_ONLY:
            res, ok = {"error": "The platform is in read-only mode (READ_ONLY=1). Changes are disabled."}, False
        else:
            res, ok = spec["fn"](user, **args), True
    except TypeError as e:
        res, ok = {"error": "Invalid arguments: " + str(e)[:160]}, False
    except ActionError as e:
        res, ok = {"error": e.msg}, False
    except CPIError as e:
        res, ok = {"error": str(e)}, False
    except Exception as e:
        res, ok = {"error": str(getattr(e, "detail", None) or e)[:300]}, False
    ms = int((time.time() - t0) * 1000)
    good = ok and not (isinstance(res, dict) and "error" in res)
    rec = {"ts": time.time(), "tool": name, "args": {k: (v if len(str(v)) < 80 else str(v)[:77] + "...") for k, v in args.items()}, "ok": good, "ms": ms, "via": via, "user": user.name, "write": spec["write"]}
    with _L:
        CALLS.append(rec); del CALLS[:-200]
    if trace is not None:
        trace.append({k: rec[k] for k in ("tool", "args", "ok", "ms", "write")})
    audit.record(user.name, "tool." + name, args.get("tenant") or args.get("target") or "-", "ALLOW" if good else "ERROR", via=via)
    return res


def recent_calls(user, n=50):
    with _L:
        return [c for c in CALLS if not user.sandbox or c["user"] == user.name][-n:]


def describe():
    return [{"name": t["name"], "description": t["description"], "write": t["write"], "scope": t["scope"], "inputSchema": t["inputSchema"]} for t in TOOLS.values()]


S = {"type": "string"}
B = {"type": "boolean"}
I = {"type": "integer"}


# ---------------- read tools ----------------
@tool("list_tenants", "List all connected SAP Integration Suite tenants with stage and connection source.")
def list_tenants(user):
    return {"tenants": [store.public(t) for t in access.visible(user).values()]}


@tool("get_tenant_overview", "Health, 24h message counts by status, runtime artifacts, certificates, queues and failure patterns of one tenant. Unreadable sections are reported, never shown as zero.", {"tenant": S}, ["tenant"])
def get_tenant_overview(user, tenant):
    t = _t(user, tenant)
    d = policy.decide(user, "monitor", t["stage"])
    if not d.allowed:
        return {"error": d.reason}
    o = monitor.overview(t, True)
    return {k: v for k, v in o.items() if k not in ("series", "failed_series")}


@tool("diagnose_tenant", "Probe every Integration Suite API the platform uses and report status, latency, granted scopes and the role that is missing when a call is refused.", {"tenant": S}, ["tenant"])
def diagnose_tenant(user, tenant):
    t = _t(user, tenant)
    return {"tenant": t["name"], "checks": client_for(t["name"]).diagnose()}


@tool("list_alerts", "Active alerts across all tenants: failure rate, certificate expiry, stopped artifacts, error queues, unreadable data, critical patterns.")
def list_alerts(user):
    al, _ = monitor.all_alerts(list(access.visible(user).values()))
    return {"alerts": al}


@tool("daily_briefing", "Management-style briefing of the landscape: headline, top issues, operations of the last 24 hours and pending approvals.")
def daily_briefing(user):
    return insight.briefing(user.name, list(access.visible(user).values()), jobs.list_jobs(user.name if user.sandbox else None, 100), approvals.pending_count(user))


@tool("list_packages", "List integration packages and their iFlows, value mappings and script collections in a tenant.", {"tenant": S}, ["tenant"])
def list_packages(user, tenant):
    c = client_for(_t(user, tenant)["name"])
    out = []
    for p in c.packages():
        a = c.package_artifacts(p["Id"])
        out.append({**p, "iflows": [x["Id"] for x in a["iflows"]], "valuemaps": [x["Id"] for x in a["valuemaps"]], "scripts": [x["Id"] for x in a["scripts"]]})
    return {"packages": out}


@tool("landscape_drift", "Compare package and artifact versions across all tenants. Shows what is out of sync or not yet promoted.")
def landscape_drift(user):
    return insight.landscape_drift(list(access.visible(user).values()))


@tool("explain_iflow", "Explain an iFlow in plain language and review it: steps, adapters, credentials, parameters, scripts and findings (missing exception handling, hard-coded addresses, payload logging, dangerous code).",
      {"tenant": S, "iflow": S}, ["tenant", "iflow"])
def explain_iflow(user, tenant, iflow):
    t = _t(user, tenant)
    c = client_for(t["name"])
    pid, a = ops.find_iflow(c, iflow)
    if not pid:
        return {"error": "iFlow '%s' not found.%s" % (iflow, (" Did you mean: " + ", ".join(a) + "?") if a else "")}
    r = insight.review_iflow(c.export("iflow", a["Id"]), a["Id"])
    r["package_id"] = pid
    r["tenant"] = t["name"]
    return r


@tool("analyze_failures", "Failed messages grouped by pattern with root cause, severity, business impact and recommended fix.", {"tenant": S, "top": I}, ["tenant"])
def analyze_failures(user, tenant, top=25):
    t = _t(user, tenant)
    d = policy.decide(user, "analyze", t["stage"])
    if not d.allowed:
        return {"error": d.reason}
    return failure.analyze(client_for(t["name"]), t["stage"], max(1, min(int(top), 100)))


@tool("search_messages", "Search message processing logs by iFlow, status, correlation id, application message id or message guid.",
      {"tenant": S, "iflow": S, "status": {"type": "string", "enum": ["COMPLETED", "FAILED", "RETRY", "ESCALATED", "PROCESSING", "ABANDONED"]}, "correlation_id": S, "application_message_id": S, "message_guid": S, "hours": I, "top": I}, ["tenant"])
def search_messages(user, tenant, iflow=None, status=None, correlation_id=None, application_message_id=None, message_guid=None, hours=24, top=50):
    t = _t(user, tenant)
    rows = client_for(t["name"]).search_messages(iflow, status, correlation_id, application_message_id, message_guid, int(hours or 24), int(top or 50))
    return {"tenant": t["name"], "count": len(rows), "messages": rows}


@tool("get_message_trace", "Full trace of one message: log, error text, custom headers and the step-by-step timeline.", {"tenant": S, "message_guid": S}, ["tenant", "message_guid"])
def get_message_trace(user, tenant, message_guid):
    t = _t(user, tenant)
    r = client_for(t["name"]).message_detail(message_guid)
    return r if r else {"error": "Message not found in this tenant"}


@tool("list_queues", "JMS queues of a tenant with message counts.", {"tenant": S}, ["tenant"])
def list_queues(user, tenant):
    return {"queues": client_for(_t(user, tenant)["name"]).queues()}


@tool("draft_incident_email", "Draft the incident notification for the most severe failure pattern of a tenant.", {"tenant": S}, ["tenant"])
def draft_incident_email(user, tenant):
    t = _t(user, tenant)
    pats = failure.analyze(client_for(t["name"]), t["stage"], 20)["patterns"]
    return notify.incident_email(pats[0], t["name"], t["stage"]) if pats else {"message": "No failures found"}


def build_report(user):
    rows = []
    for tn in access.visible(user).values():
        o = monitor.overview(tn)
        al = monitor.alerts_for(o)
        pats = o.get("patterns") or []
        rows.append({"tenant": tn["name"], "stage": tn["stage"], "connected": o.get("connected"), "messages_24h": o.get("messages_24h"), "failed_24h": o.get("failed_24h"),
                     "artifacts": len(o.get("artifacts") or []), "not_started": len([a for a in (o.get("artifacts") or []) if a["Status"] != "STARTED"]),
                     "critical": len([a for a in al if a["severity"] == "critical"]), "warnings": len([a for a in al if a["severity"] == "warning"]),
                     "top_issue": (pats[0]["iflow"] + ": " + pats[0]["subtype"]) if pats else "none", "health": o.get("health_label"),
                     "min_cert_days": min([c["days"] for c in o.get("certs") or []]) if o.get("certs") else None})
    jb = jobs.list_jobs(user.name if user.sandbox else None, 200)
    return {"generated": time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime()), "tenants": rows,
            "operations": {"total": len(jb), "success": len([j for j in jb if j["status"] == "success"]), "rolled_back": len([j for j in jb if j["status"] == "rolled_back"]), "failed": len([j for j in jb if j["status"] == "failed"])}}


@tool("executive_report", "Management summary across all tenants: health, failure rates, alerts, certificates, operations outcome.")
def executive_report(user):
    return build_report(user)


@tool("list_approvals", "Pending and decided approval requests. Approving is a human action in the web UI and is not available to agents.")
def list_approvals(user):
    return {"approvals": approvals.list_for(user)}


@tool("plan_move", "Dry run: analyze moving a package or specific iFlows between two tenants (dependencies, credentials, certificates, risk). Changes nothing.",
      {"source": S, "target": S, "package_id": S, "iflow_ids": {"type": "array", "items": S}}, ["source", "target", "package_id"], scope="Transport")
def plan_move(user, source, target, package_id, iflow_ids=None):
    s, t = _t(user, source), _t(user, target)
    if s["name"] == t["name"]:
        return {"error": "Source and target must differ"}
    reg = {v["stage"] for v in access.visible(user).values()}
    d = policy.decide(user, "move", t["stage"], s["stage"], requester=user.name, registered=reg)
    if not d.allowed:
        audit.record(user.name, "move.plan", t["name"], "DENY", reason=d.reason)
        return {"error": "Not permitted: " + d.reason}
    arts = [{"kind": "iflow", "id": i} for i in (iflow_ids or [])] or None
    p = ops.analyze_move(client_for(s["name"]), client_for(t["name"]), package_id, arts, True, t["stage"])
    return {"plan": p, "needs_approval": d.needs_approval}


@tool("get_job", "Status, steps and result of an operation started earlier.", {"job_id": S}, ["job_id"])
def get_job(user, job_id):
    j = jobs.get(job_id)
    if not j or (user.sandbox and j["user"] != user.name):
        return {"error": "Job not found"}
    return {k: j[k] for k in ("id", "title", "status", "steps", "result", "created", "finished")}


@tool("generate_iflow", "Generate an iFlow package (iFlow, Groovy scripts, value mapping, parameters, documentation) from a natural language requirement. Returns quality checks.",
      {"requirement": S}, ["requirement"], scope="Develop")
def generate_iflow(user, requirement):
    return builder.public(builder.build(str(requirement)[:1200]))


# ---------------- write tools ----------------
@tool("move_package", "Move a package (or selected iFlows) to another tenant: snapshot, import, deploy, verify, automatic rollback. confirm=true executes. UAT, PREPROD and PROD create an approval request that a different person must approve.",
      {"source": S, "target": S, "package_id": S, "iflow_ids": {"type": "array", "items": S}, "confirm": B, "deploy": B}, ["source", "target", "package_id"], write=True, scope="Transport")
def move_package(user, source, target, package_id, iflow_ids=None, confirm=False, deploy=True):
    if not confirm:
        return {"status": "NOT_CONFIRMED", "message": "Dry run only. Call again with confirm=true.", **plan_move(user, source, target, package_id, iflow_ids)}
    arts = [{"kind": "iflow", "id": i} for i in (iflow_ids or [])] or None
    r = actions.request(user, "move", {"source": source, "target": target, "package_id": package_id, "artifacts": arts, "deploy": deploy}, "mcp")
    if r["status"] == "STARTED":
        r["job_id"] = r.pop("job")
    return r


@tool("retry_queue_messages", "Retry (mode=retry) or move (mode=move with target_queue) failed JMS messages. confirm=true executes. PROD creates an approval request.",
      {"tenant": S, "queue": S, "mode": {"type": "string", "enum": ["retry", "move"]}, "target_queue": S, "message_ids": {"type": "array", "items": S}, "confirm": B}, ["tenant", "queue"], write=True, scope="Remediate")
def retry_queue_messages(user, tenant, queue, mode="retry", target_queue=None, message_ids=None, confirm=False):
    if not confirm:
        return {"status": "NOT_CONFIRMED", "message": "Call again with confirm=true"}
    r = actions.request(user, "retry", {"tenant": tenant, "queue": queue, "mode": mode, "target_queue": target_queue, "ids": message_ids or []}, "mcp")
    if r["status"] == "STARTED":
        r["job_id"] = r.pop("job")
    return r


@tool("import_generated_iflow", "Import a generated iFlow package into a DEV tenant (not deployed). confirm=true executes.", {"build_id": S, "tenant": S, "confirm": B}, ["build_id", "tenant"], write=True, scope="Develop")
def import_generated_iflow(user, build_id, tenant, confirm=False):
    t = _t(user, tenant)
    if t["stage"] != "DEV":
        return {"error": "Generated content may only be imported into a DEV tenant, then moved by transport"}
    rec = builder.get(build_id)
    if not rec:
        return {"error": "Unknown build id"}
    if not confirm:
        return {"status": "NOT_CONFIRMED", "message": "Call again with confirm=true"}
    audit.record(user.name, "builder.import", t["name"], "ALLOW", build=build_id)
    return {"status": "IMPORTED", **builder.import_into(client_for(t["name"]), rec)}


@tool("notify_incident", "Send the incident summary of a tenant to the configured notification webhook. confirm=true executes.", {"tenant": S, "confirm": B}, ["tenant"], write=True)
def notify_incident(user, tenant, confirm=False):
    mail = draft_incident_email(user, tenant)
    if "subject" not in mail:
        return {"message": "No failures found, nothing sent"}
    if not confirm:
        return {"status": "NOT_CONFIRMED", "preview": mail}
    if not config.NOTIFY_WEBHOOK_URL:
        return {"error": "No webhook configured. Set NOTIFY_WEBHOOK_URL (cf set-env cpi-copilot-api NOTIFY_WEBHOOK_URL <url>)."}
    import httpx
    try:
        httpx.post(config.NOTIFY_WEBHOOK_URL, json={"text": mail["subject"] + "\n\n" + mail["body"], "title": mail["subject"]}, timeout=15).raise_for_status()
    except Exception as e:
        return {"error": "Webhook call failed: " + type(e).__name__}
    audit.record(user.name, "notify.send", tenant, "ALLOW")
    return {"status": "SENT", "subject": mail["subject"]}
