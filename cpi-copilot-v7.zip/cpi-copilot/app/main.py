import json, os, time, uuid
from contextlib import asynccontextmanager
from fastapi import FastAPI, Depends, HTTPException, Request, Response
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
import audit, auth, config, monitor, orchestrator, tools
from api import router
from cpi_client import CPIError

HERE = os.path.dirname(os.path.abspath(__file__))
CSP = ("default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self' data:; connect-src 'self'; "
       "object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'")


@asynccontextmanager
async def lifespan(app):
    monitor.start_poller()
    audit.record("system", "app.start", config.VERSION, "ALLOW", profile=config.PROFILE)
    yield


app = FastAPI(title=config.PRODUCT, version=config.VERSION, lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)
app.include_router(router)
app.mount("/static", StaticFiles(directory=os.path.join(HERE, "static")), name="static")


@app.middleware("http")
async def guard(request: Request, call_next):
    rid = uuid.uuid4().hex[:12]
    limit = 262144 if request.url.path.startswith("/mcp") else 1048576
    cl = request.headers.get("content-length")
    if cl and cl.isdigit() and int(cl) > limit:
        return JSONResponse({"detail": "Request too large"}, status_code=413)
    try:
        r = await call_next(request)
    except Exception:
        audit.record("system", "unhandled.error", request.url.path, "ERROR", rid=rid)
        r = JSONResponse({"detail": "Internal error", "request_id": rid}, status_code=500)
    h = r.headers
    h["X-Content-Type-Options"] = "nosniff"
    h["X-Frame-Options"] = "DENY"
    h["Referrer-Policy"] = "no-referrer"
    h["Permissions-Policy"] = "camera=(), microphone=(self), geolocation=(), payment=(), usb=()"
    h["Cross-Origin-Opener-Policy"] = "same-origin"
    h["Cross-Origin-Resource-Policy"] = "same-origin"
    h["Content-Security-Policy"] = CSP
    h["X-Request-Id"] = rid
    if request.headers.get("x-forwarded-proto", "https") == "https":
        h["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    p = request.url.path
    if p == "/" or p.startswith("/static"):
        h["Cache-Control"] = "no-cache"
    elif p.startswith(("/api", "/chat", "/mcp")):
        h["Cache-Control"] = "no-store"
    nt = getattr(request.state, "new_token", None)
    if nt:
        h["X-Session-Token"] = nt
    return r


@app.get("/")
def home():
    return FileResponse(os.path.join(HERE, "static", "index.html"))


@app.get("/favicon.ico", include_in_schema=False)
def favicon():
    return Response(status_code=204)


@app.get("/health")
def health():
    return {"status": "UP", "version": config.VERSION}


@app.post("/mcp")
async def mcp(request: Request):
    """Model Context Protocol (JSON-RPC 2.0 over HTTP). Auth: Authorization: Bearer <access key or session token>."""
    try:
        user = auth.authenticate(request)
    except HTTPException as e:
        return JSONResponse({"jsonrpc": "2.0", "id": None, "error": {"code": -32001, "message": e.detail}}, status_code=e.status_code)
    try:
        msg = await request.json()
    except Exception:
        return JSONResponse({"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "Parse error"}}, status_code=400)

    def one(m):
        if not isinstance(m, dict):
            return {"jsonrpc": "2.0", "id": None, "error": {"code": -32600, "message": "Invalid request"}}
        mid, method, p = m.get("id"), m.get("method"), m.get("params") or {}
        if method and mid is None:
            return None
        if method == "initialize":
            return {"jsonrpc": "2.0", "id": mid, "result": {"protocolVersion": "2025-03-26", "capabilities": {"tools": {"listChanged": False}},
                    "serverInfo": {"name": "cpi-copilot", "version": config.VERSION, "author": config.AUTHOR},
                    "instructions": "SAP Integration Suite operations: monitor, diagnose, analyze failures, trace messages, explain iFlows, compare tenants, move packages, retry queue messages, generate iFlows. Write tools need confirm=true. UAT, PREPROD and PROD changes create an approval request that a human approves in the web UI."}}
        if method == "ping":
            return {"jsonrpc": "2.0", "id": mid, "result": {}}
        if method == "tools/list":
            return {"jsonrpc": "2.0", "id": mid, "result": {"tools": [{"name": t["name"], "description": t["description"] + (" (changes data)" if t["write"] else ""), "inputSchema": t["inputSchema"],
                    "annotations": {"readOnlyHint": not t["write"], "destructiveHint": bool(t["write"]), "openWorldHint": False}} for t in tools.TOOLS.values() if user.has(t["scope"])]}}
        if method == "tools/call":
            name = p.get("name")
            if name not in tools.TOOLS:
                return {"jsonrpc": "2.0", "id": mid, "error": {"code": -32602, "message": "Unknown tool " + str(name)}}
            args = p.get("arguments") or {}
            if not isinstance(args, dict):
                return {"jsonrpc": "2.0", "id": mid, "error": {"code": -32602, "message": "arguments must be an object"}}
            res = tools.call(user, name, args, "mcp")
            return {"jsonrpc": "2.0", "id": mid, "result": {"content": [{"type": "text", "text": json.dumps(res, default=str)[:60000]}], "isError": isinstance(res, dict) and "error" in res}}
        return {"jsonrpc": "2.0", "id": mid, "error": {"code": -32601, "message": "Method not found"}}

    if isinstance(msg, list):
        rs = [r for r in (one(m) for m in msg[:20]) if r]
        return JSONResponse(rs) if rs else Response(status_code=202)
    r = one(msg)
    return JSONResponse(r) if r else Response(status_code=202)


@app.get("/mcp")
def mcp_info():
    return {"name": "cpi-copilot", "protocol": "MCP over HTTP (JSON-RPC 2.0), POST to this URL", "auth": "Authorization: Bearer <access key>", "tools": len(tools.TOOLS), "author": config.AUTHOR}


class Ctx(BaseModel):
    view: str = Field("", max_length=30)
    tenant: str = Field("", max_length=60)


class ChatIn(BaseModel):
    message: str = Field(min_length=1, max_length=500)
    context: Ctx | None = None


@app.post("/chat")
def chat(body: ChatIn, user=Depends(auth.authenticate)):
    try:
        return orchestrator.handle(user, body.message, body.context.model_dump() if body.context else None)
    except HTTPException:
        raise
    except CPIError as e:
        return {"reply": "The tenant returned an error: " + str(e), "trace": [], "suggestions": ["Diagnose the connection"]}
    except Exception as e:
        audit.record(user.name, "chat.error", "-", "ERROR", error=type(e).__name__)
        return {"reply": "Something went wrong while handling that. Please rephrase or try again.", "trace": [], "suggestions": []}
