import hashlib, json, time, logging, threading
import security

log = logging.getLogger("audit")
logging.basicConfig(level=logging.INFO, format="%(message)s")
_lock = threading.Lock()
_prev = "GENESIS"
_events = []
_total = [0]


def record(user, action, target, decision, **detail):
    """Hash-chained audit event. Written to the app log as one JSON line (type=audit) for SIEM collection. Secrets are redacted."""
    global _prev
    with _lock:
        ev = {"ts": time.time(), "user": str(user)[:80], "action": str(action)[:80], "target": str(target)[:200],
              "decision": str(decision)[:30], "detail": security.redact(detail), "prev": _prev}
        ev["hash"] = hashlib.sha256(json.dumps(ev, sort_keys=True, default=str).encode()).hexdigest()
        _prev = ev["hash"]
        _events.append(ev); _total[0] += 1
        del _events[:-2000]
        log.info(json.dumps({"type": "audit", **ev}, default=str))
        return ev


def recent(n=100, user=None):
    with _lock:
        ev = [e for e in _events if user is None or e["user"] == user]
        return ev[-n:]


def verify():
    """Recompute the hash chain of the retained events. Returns (ok, checked, first_bad_index)."""
    with _lock:
        ev = list(_events)
    prev = None
    for i, e in enumerate(ev):
        body = {k: v for k, v in e.items() if k != "hash"}
        h = hashlib.sha256(json.dumps(body, sort_keys=True, default=str).encode()).hexdigest()
        if h != e["hash"] or (prev is not None and e["prev"] != prev):
            return False, len(ev), i
        prev = e["hash"]
    return True, len(ev), None


def head():
    with _lock:
        return {"events_total": _total[0], "retained": len(_events), "head_hash": _prev, "first_ts": _events[0]["ts"] if _events else None}


def export_jsonl():
    with _lock:
        return "\n".join(json.dumps(e, sort_keys=True, default=str) for e in _events) + "\n"
