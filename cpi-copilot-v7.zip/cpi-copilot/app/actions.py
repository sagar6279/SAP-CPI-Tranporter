"""Single path for every change, from the UI, chat or an MCP agent: read-only guard, policy, approval, then job."""
import time, threading
import access, approvals, audit, config, jobs, ops, policy
from auth import User

_RATE = {}
_RL = threading.Lock()


class ActionError(Exception):
    def __init__(self, status, msg):
        super().__init__(msg)
        self.status, self.msg = status, msg


def _throttle(user, limit=12):
    now = time.time()
    with _RL:
        h = [x for x in _RATE.get(user.name, []) if now - x < 60]
        if len(h) >= limit:
            raise ActionError(429, "Too many change requests, wait a minute")
        h.append(now); _RATE[user.name] = h


def _meta(s, t):
    return {"source": s["name"], "target": t["name"], "source_stage": s["stage"], "target_stage": t["stage"]}


def start_move(user, p, approver=None):
    what = "package " + p["package_id"] if not p.get("artifacts") else "iFlow " + ", ".join(a["id"] for a in p["artifacts"])
    s, t = access.tenant_for(user, p["source"]), access.tenant_for(user, p["target"])
    q = dict(p, approver=approver)
    return jobs.submit("move", "Move %s: %s to %s" % (what, p["source"], p["target"]), user, q, lambda ctx: ops.run_move(ctx, user, q), meta=_meta(s, t))


def start_retry(user, p, approver=None):
    t = access.tenant_for(user, p["tenant"])
    q = dict(p, approver=approver)
    title = "%s failed messages in %s / %s" % ("Retry" if p.get("mode", "retry") == "retry" else "Move", p["tenant"], p["queue"])
    return jobs.submit("retry", title, user, q, lambda ctx: ops.run_retry(ctx, user, q),
                       meta={"source": t["name"], "target": t["name"], "source_stage": t["stage"], "target_stage": t["stage"]})


def request(user, kind, params, via="ui"):
    if config.READ_ONLY:
        raise ActionError(403, "Read-only mode is active. Changes are disabled.")
    _throttle(user)
    if kind == "move":
        s, t = access.tenant_for(user, params["source"]), access.tenant_for(user, params["target"])
        if s["name"] == t["name"]:
            raise ActionError(400, "Source and target must differ")
        reg = {v["stage"] for v in access.visible(user).values()}
        d = policy.decide(user, "move", t["stage"], s["stage"], requester=user.name, registered=reg)
        if not d.allowed:
            audit.record(user.name, "move", t["name"], "DENY", reason=d.reason, via=via)
            raise ActionError(403, d.reason)
        p = dict(source=s["name"], target=t["name"], target_stage=t["stage"], package_id=params["package_id"], artifacts=params.get("artifacts") or None,
                 deploy=bool(params.get("deploy", True)), include_deps=bool(params.get("include_deps", True)),
                 simulate_failure=bool(params.get("simulate_failure")) and bool(t.get("demo")))
        if d.needs_approval:
            what = "iFlow " + ", ".join(a["id"] for a in p["artifacts"]) if p["artifacts"] else "package " + p["package_id"]
            rec = approvals.create("move", "Move %s: %s to %s" % (what, s["name"], t["name"]), p, user, t["stage"])
            return {"status": "PENDING_APPROVAL", "approval_id": rec["id"], "reason": "A second person with the Approve permission must approve changes to %s" % t["stage"]}
        audit.record(user.name, "move.start", t["name"], "ALLOW", via=via)
        return {"status": "STARTED", "job": start_move(user, p)["id"]}
    if kind == "retry":
        t = access.tenant_for(user, params["tenant"])
        d = policy.decide(user, "retry", t["stage"], requester=user.name)
        if not d.allowed:
            audit.record(user.name, "retry", t["name"], "DENY", reason=d.reason, via=via)
            raise ActionError(403, d.reason)
        mode = params.get("mode", "retry")
        if mode not in ("retry", "move"):
            raise ActionError(400, "mode must be retry or move")
        if mode == "move" and not params.get("target_queue"):
            raise ActionError(400, "target_queue is required to move messages")
        ids = [str(i)[:200] for i in (params.get("ids") or params.get("message_ids") or [])][:100]
        p = dict(tenant=t["name"], queue=str(params["queue"])[:200], mode=mode, target_queue=(str(params.get("target_queue"))[:200] if params.get("target_queue") else None), ids=ids)
        if d.needs_approval:
            rec = approvals.create("retry", "%s failed messages in %s / %s" % ("Retry" if mode == "retry" else "Move", t["name"], p["queue"]), p, user, t["stage"])
            return {"status": "PENDING_APPROVAL", "approval_id": rec["id"], "reason": "A second person must approve changes in %s" % t["stage"]}
        audit.record(user.name, "retry.start", t["name"], "ALLOW", via=via)
        return {"status": "STARTED", "job": start_retry(user, p)["id"]}
    raise ActionError(400, "Unknown kind")


def execute_approved(rec, approver_name):
    """Run an approved request as the original requester, with the approver recorded. Policy is evaluated again."""
    requester = User(rec["requester"], rec["requester_scopes"], sandbox=rec["sandbox"])
    p = rec["params"]
    if rec["kind"] == "move":
        s, t = access.tenant_for(requester, p["source"]), access.tenant_for(requester, p["target"])
        reg = {v["stage"] for v in access.visible(requester).values()}
        d = policy.decide(requester, "move", t["stage"], s["stage"], requester=requester.name, approver=approver_name, registered=reg)
        if not d.allowed:
            raise ActionError(403, d.reason)
        return start_move(requester, p, approver_name)
    if rec["kind"] == "retry":
        t = access.tenant_for(requester, p["tenant"])
        d = policy.decide(requester, "retry", t["stage"], requester=requester.name, approver=approver_name)
        if not d.allowed:
            raise ActionError(403, d.reason)
        return start_retry(requester, p, approver_name)
    raise ActionError(400, "Unknown kind")
