"""Authorization + governance: deterministic policy, no LLM involved."""
from dataclasses import dataclass

ENV_ORDER = ["DEV", "QA", "UAT", "PREPROD", "PROD"]
APPROVAL_STAGES = ("UAT", "PREPROD", "PROD")

def idx(stage):
    return ENV_ORDER.index(stage) if stage in ENV_ORDER else 0

@dataclass
class Decision:
    allowed: bool
    reason: str = ""
    needs_approval: bool = False

def _scope(action, target):
    if action in ("move", "transport"):
        return "TransportProd" if target == "PROD" else "Transport"
    return {"monitor": "Display", "analyze": "Display", "notify": "Display",
            "retry": "Remediate", "remediate": "Remediate", "generate": "Develop", "approve": "Approve",
            "tenant_admin": "Admin"}.get(action)

def decide(user, action, target=None, source=None, requester=None, approver=None, registered=None):
    need = _scope(action, target)
    if need is None:
        return Decision(False, "unknown action")
    if not user.has(need):
        return Decision(False, "missing scope " + need)
    if action in ("move", "transport") and source and target:
        si, ti = idx(source), idx(target)
        if ti < si:
            return Decision(False, "backward promotion is not allowed (" + source + " to " + target + ")")
        if ti - si > 1:
            skipped = ENV_ORDER[si + 1:ti]
            present = [s for s in skipped if registered is None or s in registered]
            if present:
                return Decision(False, "environment skipping is not allowed, pass through " + ", ".join(present) + " first")
    needs = False
    if action in ("move", "transport") and target in APPROVAL_STAGES:
        needs = True
    if action in ("retry", "remediate") and target == "PROD":
        needs = True
    if needs and approver and requester and approver.strip().lower() == requester.strip().lower():
        return Decision(False, "segregation of duties: requester cannot approve own change")
    return Decision(True, "approval required" if needs else "", needs_approval=needs)
