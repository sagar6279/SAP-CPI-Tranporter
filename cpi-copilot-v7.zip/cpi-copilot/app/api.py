import time
from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel, Field
import access, actions, approvals, audit, auth, builder, clients, config, demo_client, governance, insight, jobs, monitor, ops, policy, security, tools
from actions import ActionError
from agents import failure
from clients import client_for
from cpi_client import CPIError
from store import store, STAGES

router = APIRouter(prefix="/api")


def _wrap(fn):
    try:
        return fn()
    except CPIError as e:
        raise HTTPException(502, str(e))
    except ActionError as e:
        raise HTTPException(e.status, e.msg)
    except ValueError as e:
        raise HTTPException(400, str(e))
    except KeyError as e:
        raise HTTPException(404, str(e).strip("'\""))


def _need(user, scope):
    if not user.has(scope):
        audit.record(user.name, "api." + scope, "-", "DENY", reason="missing scope")
        raise HTTPException(403, "Missing permission: " + scope)


# ---------------- session ----------------
class LoginIn(BaseModel):
    key: str = Field(min_length=1, max_length=300)


@router.post("/login")
def login(b: LoginIn, request: Request):
    ip = auth.client_ip(request)
    security.check_lock(ip)
    ident = auth.match_key(b.key.strip())
    if not ident:
        security.record_fail(ip)
        audit.record("access-key", "login", "-", "DENY", reason="bad key", ip=ip)
        raise HTTPException(401, "Access key not accepted")
    security.clear_fail(ip)
    tok, exp = security.issue_session(ident["name"], ident["scopes"])
    audit.record(ident["name"], "login", "-", "ALLOW", ip=ip)
    return {"token": tok, "expires": exp, "user": ident["name"], "scopes": ident["scopes"]}


@router.post("/logout")
def logout(request: Request, user=Depends(auth.authenticate)):
    hdr = request.headers.get("authorization", "")
    if hdr.lower().startswith("bearer st."):
        security.revoke(hdr[7:].strip())
    audit.record(user.name, "logout", "-", "ALLOW")
    return {"ok": True}


@router.get("/me")
def me(user=Depends(auth.authenticate)):
    return {"user": user.name, "scopes": sorted(user.scopes), "sandbox": user.sandbox, "version": config.VERSION, "product": config.PRODUCT, "author": config.AUTHOR,
            "profile": config.PROFILE, "read_only": config.READ_ONLY, "ui_tenants": bool(config.ALLOW_UI_TENANTS and user.has("Admin") and not user.sandbox),
            "pending_approvals": approvals.pending_count(user), "session_minutes": config.SESSION_TTL_MIN}


@router.get("/about")
def about():
    return {"product": config.PRODUCT, "version": config.VERSION, "author": config.AUTHOR, "profile": config.PROFILE, "tools": len(tools.TOOLS), "sandbox": config.SANDBOX}


# ---------------- tenants ----------------
@router.get("/tenants")
def list_tenants(user=Depends(auth.authenticate)):
    vis = access.visible(user)
    return {"tenants": [store.public(t) for t in vis.values()], "stages": STAGES, "auto": [k for k, v in vis.items() if v.get("source") == "auto"]}


class TenantIn(BaseModel):
    name: str = Field(min_length=1, max_length=40)
    stage: str
    url: str = Field(max_length=300)
    tokenurl: str = Field(max_length=300)
    clientid: str = Field(max_length=300)
    clientsecret: str = Field(max_length=500)
    test: bool = True


@router.post("/tenants")
def add_tenant(b: TenantIn, user=Depends(auth.authenticate)):
    _need(user, "Admin")
    if user.sandbox:
        raise HTTPException(403, "Sandbox sessions cannot register real tenants. Sign in with an access key.")
    if not config.ALLOW_UI_TENANTS:
        raise HTTPException(403, "Adding tenants in the UI is disabled in this security profile. Bind a Process Integration Runtime instance instead.")
    if config.READ_ONLY:
        raise HTTPException(403, "Read-only mode is active.")
    try:
        security.validate_tenant_url(b.url, "Tenant URL")
        security.validate_tenant_url(b.tokenurl, "Token URL")
        name = store.add(b.name, b.stage.upper(), b.url, b.tokenurl, b.clientid, b.clientsecret, user.name)
    except ValueError as e:
        raise HTTPException(400, str(e))
    res = {"name": name, "saved": True}
    if b.test:
        try:
            res["test"] = client_for(name).ping()
        except Exception as e:
            store.remove(name); clients.forget(name)
            raise HTTPException(400, "Connection test failed, tenant not saved. " + str(e)[:200])
    audit.record(user.name, "tenant.add", name, "ALLOW", stage=b.stage)
    return res


@router.delete("/tenants/{name}")
def del_tenant(name: str, user=Depends(auth.authenticate)):
    _need(user, "Admin")
    t = access.tenant_for(user, name)
    if t["source"] != "ui":
        raise HTTPException(400, "Only tenants added in the UI can be removed here. Others are managed with cf.")
    store.remove(t["name"]); clients.forget(t["name"]); monitor.forget(t["name"])
    audit.record(user.name, "tenant.remove", name, "ALLOW")
    return {"removed": name}


class StageIn(BaseModel):
    stage: str


@router.post("/tenants/{name}/stage")
def set_stage(name: str, b: StageIn, user=Depends(auth.authenticate)):
    _need(user, "Admin")
    t = access.tenant_for(user, name)
    if t.get("demo"):
        raise HTTPException(400, "Demo tenants have a fixed stage")
    try:
        store.set_stage(t["name"], b.stage.upper())
    except ValueError as e:
        raise HTTPException(400, str(e))
    monitor.forget(t["name"])
    audit.record(user.name, "tenant.stage", name, "ALLOW", stage=b.stage)
    return {"name": name, "stage": b.stage.upper()}


@router.post("/tenants/{name}/test")
def test_tenant(name: str, user=Depends(auth.authenticate)):
    t = access.tenant_for(user, name)
    try:
        return {"ok": True, **client_for(t["name"]).ping()}
    except Exception as e:
        return {"ok": False, "error": str(e)[:300]}


@router.get("/tenants/{name}/diagnostics")
def diagnostics(name: str, user=Depends(auth.authenticate)):
    t = access.tenant_for(user, name)
    r = _wrap(lambda: client_for(t["name"]).diagnose())
    audit.record(user.name, "tenant.diagnose", name, "ALLOW")
    return {"tenant": t["name"], "stage": t["stage"], "checks": r}


@router.post("/demo/load")
def demo_load(user=Depends(auth.authenticate)):
    store.set_demo(demo_client.build_demo(), user.name); monitor.clear()
    audit.record(user.name, "demo.load", "-", "ALLOW")
    return {"loaded": True}


@router.post("/demo/clear")
def demo_clear(user=Depends(auth.authenticate)):
    store.clear_demo(user.name); monitor.clear()
    return {"cleared": True}


# ---------------- monitoring ----------------
@router.get("/overview/{name}")
def overview(name: str, refresh: int = 0, user=Depends(auth.authenticate)):
    t = access.tenant_for(user, name)
    d = policy.decide(user, "monitor", t["stage"])
    if not d.allowed:
        raise HTTPException(403, d.reason)
    return monitor.overview(t, bool(refresh))


@router.get("/alerts")
def alerts(user=Depends(auth.authenticate)):
    return {"alerts": monitor.all_alerts(list(access.visible(user).values()))[0]}


@router.get("/alerts/history")
def alert_history(user=Depends(auth.authenticate)):
    return {"events": monitor.history(set(access.visible(user)), 80)}


@router.get("/briefing")
def briefing(user=Depends(auth.authenticate)):
    return tools.call(user, "daily_briefing", {}, "ui")


@router.get("/drift")
def drift(user=Depends(auth.authenticate)):
    return _wrap(lambda: insight.landscape_drift(list(access.visible(user).values())))


# ---------------- tenant content ----------------
@router.get("/tenants/{name}/packages")
def packages(name: str, user=Depends(auth.authenticate)):
    t = access.tenant_for(user, name)
    def go():
        c = client_for(t["name"])
        res = []
        for p in c.packages():
            a = c.package_artifacts(p["Id"])
            res.append({**p, "counts": {"iflows": len(a["iflows"]), "valuemaps": len(a["valuemaps"]), "scripts": len(a["scripts"])}, "artifacts": a})
        return {"packages": res}
    return _wrap(go)


@router.get("/tenants/{name}/failed")
def failed(name: str, top: int = 40, user=Depends(auth.authenticate)):
    t = access.tenant_for(user, name)
    d = policy.decide(user, "analyze", t["stage"])
    if not d.allowed:
        raise HTTPException(403, d.reason)
    return _wrap(lambda: failure.analyze(client_for(t["name"]), t["stage"], max(1, min(top, 100))))


@router.get("/tenants/{name}/messages")
def messages(name: str, iflow: str = "", status: str = "", correlation_id: str = "", app_msg_id: str = "", guid: str = "", hours: int = 24, top: int = 50, user=Depends(auth.authenticate)):
    t = access.tenant_for(user, name)
    rows = _wrap(lambda: client_for(t["name"]).search_messages(iflow or None, status or None, correlation_id or None, app_msg_id or None, guid or None, max(1, min(hours, 720)), max(1, min(top, 200))))
    return {"messages": rows}


@router.get("/tenants/{name}/messages/{guid}")
def message_trace(name: str, guid: str, user=Depends(auth.authenticate)):
    t = access.tenant_for(user, name)
    r = _wrap(lambda: client_for(t["name"]).message_detail(guid))
    if not r:
        raise HTTPException(404, "Message not found")
    return r


@router.get("/tenants/{name}/queues")
def queues(name: str, user=Depends(auth.authenticate)):
    t = access.tenant_for(user, name)
    return _wrap(lambda: {"queues": client_for(t["name"]).queues()})


@router.get("/tenants/{name}/queues/{q}")
def queue_messages(name: str, q: str, user=Depends(auth.authenticate)):
    t = access.tenant_for(user, name)
    return _wrap(lambda: {"messages": client_for(t["name"]).queue_messages(q, 200)})


class ExplainIn(BaseModel):
    tenant: str
    iflow: str = Field(max_length=200)


@router.post("/iflow/explain")
def explain(b: ExplainIn, user=Depends(auth.authenticate)):
    r = tools.call(user, "explain_iflow", {"tenant": b.tenant, "iflow": b.iflow}, "ui")
    if "error" in r:
        raise HTTPException(400, r["error"])
    return r


# ---------------- changes ----------------
class MoveIn(BaseModel):
    source: str
    target: str
    package_id: str = Field(max_length=200)
    artifacts: list[dict] | None = None
    deploy: bool = True
    include_deps: bool = True
    simulate_failure: bool = False


@router.post("/plan")
def plan(b: MoveIn, user=Depends(auth.authenticate)):
    _need(user, "Transport")
    r = tools.call(user, "plan_move", {"source": b.source, "target": b.target, "package_id": b.package_id, "iflow_ids": [a["id"] for a in (b.artifacts or []) if a.get("id")]}, "ui")
    if "error" in r:
        raise HTTPException(403 if "Not permitted" in r["error"] else 400, r["error"])
    s, t = store.get(b.source), store.get(b.target)
    return {"plan": r["plan"], "needs_approval": r["needs_approval"], "source_stage": s["stage"], "target_stage": t["stage"]}


class JobIn(BaseModel):
    kind: str
    params: dict


@router.post("/jobs")
def create_job(b: JobIn, user=Depends(auth.authenticate)):
    need = {"move": "Transport", "retry": "Remediate"}.get(b.kind)
    if not need:
        raise HTTPException(400, "Unknown job kind")
    _need(user, need)
    try:
        return actions.request(user, b.kind, b.params, "ui")
    except ActionError as e:
        raise HTTPException(e.status, e.msg)
    except KeyError as e:
        raise HTTPException(400, "Missing parameter " + str(e))


@router.get("/jobs")
def list_jobs(user=Depends(auth.authenticate)):
    return {"jobs": jobs.list_jobs(user.name if user.sandbox else None)}


@router.get("/jobs/{jid}")
def get_job(jid: str, user=Depends(auth.authenticate)):
    j = jobs.get(jid)
    if not j or (user.sandbox and j["user"] != user.name):
        raise HTTPException(404, "Job not found")
    return j


# ---------------- approvals ----------------
@router.get("/approvals")
def list_approvals(user=Depends(auth.authenticate)):
    return {"approvals": approvals.list_for(user), "can_approve": bool(user.sandbox or user.has("Approve"))}


class DecisionIn(BaseModel):
    approve: bool
    reason: str = Field("", max_length=300)


@router.post("/approvals/{aid}/decision")
def decide(aid: str, b: DecisionIn, user=Depends(auth.authenticate)):
    if config.READ_ONLY:
        raise HTTPException(403, "Read-only mode is active.")
    try:
        rec = approvals.decide(aid, user, b.approve, b.reason)
    except ValueError as e:
        raise HTTPException(403 if ("Segregation" in str(e) or "permission" in str(e)) else 400, str(e))
    if rec["status"] == "APPROVED":
        try:
            rec["job"] = actions.execute_approved(rec, rec["decided_by"])["id"]
        except ActionError as e:
            rec["status"] = "FAILED"; rec["reason"] = e.msg
            audit.record(rec["decided_by"], "approval.execute", aid, "ERROR", reason=e.msg)
            raise HTTPException(e.status, e.msg)
        except Exception as e:
            rec["status"] = "FAILED"
            raise HTTPException(400, str(getattr(e, "detail", e))[:200])
    return approvals.public(rec)


# ---------------- builder ----------------
class BuildIn(BaseModel):
    requirement: str = Field(max_length=1200)
    sender: str | None = None
    receiver: str | None = None
    auth: str | None = None
    convert: str | None = None


@router.get("/builder/templates")
def b_templates(user=Depends(auth.authenticate)):
    return {"templates": builder.TEMPLATES, "systems": {k: v["label"] for k, v in builder.SYSTEMS.items()}}


@router.post("/builder/generate")
def b_generate(b: BuildIn, user=Depends(auth.authenticate)):
    _need(user, "Develop")
    if len(b.requirement.strip()) < 10:
        raise HTTPException(400, "Describe the integration in a sentence")
    ov = {k: v for k, v in {"sender": b.sender, "receiver": b.receiver, "auth": b.auth, "convert": b.convert}.items() if v and v != "auto"}
    rec = builder.build(b.requirement, ov)
    audit.record(user.name, "builder.generate", rec["iflow_id"], "ALLOW")
    return builder.public(rec)


@router.get("/builder/{bid}/download")
def b_download(bid: str, user=Depends(auth.authenticate)):
    rec = builder.get(bid)
    if not rec:
        raise HTTPException(404, "Build not found")
    return Response(rec["bundle"], media_type="application/zip", headers={"Content-Disposition": 'attachment; filename="%s.zip"' % rec["iflow_id"]})


class ImportIn(BaseModel):
    tenant: str


@router.post("/builder/{bid}/import")
def b_import(bid: str, b: ImportIn, user=Depends(auth.authenticate)):
    r = tools.call(user, "import_generated_iflow", {"build_id": bid, "tenant": b.tenant, "confirm": True}, "ui")
    if "error" in r:
        raise HTTPException(400, r["error"])
    return r


# ---------------- agent ----------------
@router.get("/agent/tools")
def agent_tools(user=Depends(auth.authenticate)):
    return {"tools": tools.describe(), "calls": tools.recent_calls(user)}


class ToolIn(BaseModel):
    name: str
    args: dict = {}


@router.post("/agent/call")
def agent_call(b: ToolIn, user=Depends(auth.authenticate)):
    if b.name not in tools.TOOLS:
        raise HTTPException(404, "Unknown tool")
    return tools.call(user, b.name, b.args, "ui")


class FeedbackIn(BaseModel):
    rating: str = Field(pattern="^(up|down)$")
    note: str = Field("", max_length=200)


@router.post("/feedback")
def feedback(b: FeedbackIn, user=Depends(auth.authenticate)):
    audit.record(user.name, "chat.feedback", "-", b.rating.upper(), note=b.note)
    return {"ok": True}


# ---------------- governance ----------------
@router.get("/audit")
def get_audit(user=Depends(auth.authenticate)):
    return {"events": audit.recent(150, user.name if user.sandbox else None), "head": audit.head()}


@router.get("/audit/export")
def audit_export(user=Depends(auth.authenticate)):
    _need(user, "Admin")
    if user.sandbox:
        raise HTTPException(403, "Not available in sandbox sessions")
    audit.record(user.name, "audit.export", "-", "ALLOW")
    return Response(audit.export_jsonl(), media_type="application/x-ndjson", headers={"Content-Disposition": 'attachment; filename="audit-%d.jsonl"' % int(time.time())})


@router.get("/audit/verify")
def audit_verify(user=Depends(auth.authenticate)):
    ok, n, bad = audit.verify()
    return {"intact": ok, "checked": n, "broken_at": bad, **audit.head()}


@router.get("/governance")
def governance_status(user=Depends(auth.authenticate)):
    return {"version": config.VERSION, **governance.controls()}


@router.get("/evidence.html")
def evidence(user=Depends(auth.authenticate)):
    audit.record(user.name, "evidence.view", "-", "ALLOW")
    return Response(governance.evidence_html(user.name), media_type="text/html")


@router.get("/sbom")
def sbom(user=Depends(auth.authenticate)):
    return governance.sbom()


@router.get("/report")
def report(user=Depends(auth.authenticate)):
    return tools.build_report(user)


@router.get("/report.html")
def report_html(user=Depends(auth.authenticate)):
    from html import escape
    r = tools.build_report(user)
    f = lambda v: "n/a" if v is None else v
    rows = "".join("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s / %s</td><td>%s</td></tr>" % (
        escape(x["tenant"]), x["stage"], escape(str(f(x["health"]))), f(x["messages_24h"]), f(x["failed_24h"]), x["artifacts"], x["not_started"], x["critical"], x["warnings"], escape(x["top_issue"])) for x in r["tenants"])
    o = r["operations"]
    html = """<!doctype html><meta charset="utf-8"><title>Integration operations report</title><style>body{font-family:Segoe UI,Arial;margin:36px;color:#161b2e}h1{margin:0}table{border-collapse:collapse;width:100%%;margin-top:18px}th,td{border:1px solid #d5d9e6;padding:8px 10px;text-align:left;font-size:13px}th{background:#f1f3fa}.k{display:inline-block;margin:14px 18px 0 0;padding:12px 18px;border-radius:12px;background:#f1f3fa}.k b{font-size:24px;display:block}</style>
<h1>Integration operations report</h1><div>%s</div><div class="k"><b>%d</b>tenants</div><div class="k"><b>%d</b>operations</div><div class="k"><b>%d</b>succeeded</div><div class="k"><b>%d</b>rolled back</div><div class="k"><b>%d</b>failed</div>
<table><tr><th>Tenant</th><th>Stage</th><th>Health</th><th>Messages 24h</th><th>Failed 24h</th><th>Artifacts</th><th>Not started</th><th>Critical / warnings</th><th>Top issue</th></tr>%s</table>
<p style="color:#5b6585;font-size:12px">n/a means the tenant did not allow reading that value. Generated by %s %s, designed and developed by %s. Print to save as PDF.</p>""" % (
        r["generated"], len(r["tenants"]), o["total"], o["success"], o["rolled_back"], o["failed"], rows, config.PRODUCT, config.VERSION, config.AUTHOR)
    return Response(html, media_type="text/html")
