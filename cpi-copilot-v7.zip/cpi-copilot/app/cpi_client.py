"""SAP Integration Suite (Cloud Integration) OData V2 client.
Accuracy rules: never turn an error into zero, page through large result sets, convert /Date()/ values, quote OData literals safely."""
import base64, json, re, time, threading
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import quote
import httpx

KIND_SET = {"iflow": "IntegrationDesigntimeArtifacts", "vm": "ValueMappingDesigntimeArtifacts", "script": "ScriptCollectionDesigntimeArtifacts"}
KIND_DEPLOY = {"iflow": "DeployIntegrationFlow", "vm": "DeployValueMapping", "script": "DeployScriptCollection"}
STATUSES = ["COMPLETED", "FAILED", "RETRY", "ESCALATED", "PROCESSING", "ABANDONED"]

ROLE_BY_PATH = [
    ("/MessageProcessingLogs", "MonitoringDataRead"), ("/IntegrationRuntimeArtifacts", "MonitoringDataRead"),
    ("/MessagingQueues", "DataStoresAndQueuesRead"), ("/RetryMessagingMessages", "QueuesRetry (verify role template name in Role Templates)"),
    ("/MoveMessagingMessages", "QueuesRetry (verify role template name in Role Templates)"),
    ("/IntegrationPackages", "WorkspacePackagesEdit"), ("/Deploy", "WorkspaceArtifactsDeploy"),
    ("/IntegrationDesigntimeArtifacts", "WorkspacePackagesEdit"), ("/ValueMappingDesigntimeArtifacts", "WorkspacePackagesEdit"),
    ("/ScriptCollectionDesigntimeArtifacts", "WorkspacePackagesEdit"),
]


class CPIError(Exception):
    def __init__(self, status, message, hint="", role=""):
        super().__init__(message)
        self.status, self.message, self.hint, self.role = status, message, hint, role

    def __str__(self):
        s = (("HTTP %s: " % self.status) if self.status else "") + self.message
        if self.hint:
            s += " - " + self.hint
        if self.role and self.status in (401, 403):
            s += " (role: %s)" % self.role
        return s


def _hint(status):
    return {401: "Check client id, secret and token URL", 403: "The service instance lacks a role for this API",
            404: "Resource not found on this tenant", 429: "Rate limited by the tenant"}.get(status, "")


def odata_ms(v):
    if v is None or v == "":
        return None
    if isinstance(v, (int, float)):
        return int(v)
    m = re.search(r"/Date\((-?\d+)", str(v))
    if m:
        return int(m.group(1))
    try:
        from datetime import datetime, timezone
        d = datetime.fromisoformat(str(v).replace("Z", "+00:00"))
        if d.tzinfo is None:
            d = d.replace(tzinfo=timezone.utc)
        return int(d.timestamp() * 1000)
    except Exception:
        return None


def iso_ms(ms):
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(ms / 1000)) if ms is not None else None


def _since(hours):
    return time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(time.time() - hours * 3600))


_SAFE = re.compile(r"^[A-Za-z0-9_.:\-/ @]{1,200}$")

def lit(v):
    s = str(v)
    if not _SAFE.match(s):
        raise CPIError(400, "Search value contains unsupported characters")
    return s.replace("'", "''")

def qp(v):
    return quote(str(v).replace("'", "''"), safe="")

def _first(d, *keys, default=None):
    for k in keys:
        if k in d and d[k] is not None:
            return d[k]
    return default


class CPIClient:
    demo = False

    def __init__(self, t):
        self.t = t
        self.name = t["name"]
        base = re.sub(r"/api/v1$", "", t["url"].rstrip("/"))
        self.base = base + "/api/v1"
        self._http = httpx.Client(timeout=httpx.Timeout(60.0, connect=15.0), follow_redirects=False)
        self._tok, self._exp, self._csrf = None, 0, None
        self._lock = threading.Lock()

    # ---------------- transport ----------------
    def _token(self, force=False):
        with self._lock:
            if self._tok and not force and self._exp > time.time() + 60:
                return self._tok
            try:
                r = self._http.post(self.t["tokenurl"], data={"grant_type": "client_credentials"}, auth=(self.t["clientid"], self.t["clientsecret"]))
            except httpx.HTTPError as e:
                raise CPIError(0, "Cannot reach the token endpoint (%s)" % type(e).__name__, "Check token URL and network")
            if r.status_code >= 400:
                raise CPIError(r.status_code, "Token request failed", _hint(401))
            j = r.json()
            self._tok, self._exp = j["access_token"], time.time() + int(j.get("expires_in", 600))
            return self._tok

    def _fetch_csrf(self):
        r = self._http.get(self.base + "/", headers={"Authorization": "Bearer " + self._token(), "X-CSRF-Token": "Fetch"})
        self._csrf = r.headers.get("x-csrf-token")
        return self._csrf

    @staticmethod
    def _qs(params):
        """Encode the query ourselves: spaces as %20 (never '+'), OData system options keep their literal $ prefix."""
        if not params:
            return ""
        return "?" + "&".join("%s=%s" % (quote(str(k), safe="$"), quote(str(v), safe="'(),:/")) for k, v in params.items())

    @staticmethod
    def _role(path):
        for pre, role in ROLE_BY_PATH:
            if path.startswith(pre):
                return role
        return ""

    def req(self, method, path, params=None, json=None, accept="application/json", headers=None, tries=3):
        last = None
        for attempt in range(tries):
            h = {"Authorization": "Bearer " + self._token(), "Accept": accept}
            if method != "GET":
                h["X-CSRF-Token"] = self._csrf or self._fetch_csrf() or ""
            if headers:
                h.update(headers)
            try:
                r = self._http.request(method, self.base + path + self._qs(params), json=json, headers=h)
            except httpx.HTTPError as e:
                last = CPIError(0, "Network error (%s)" % type(e).__name__, "Tenant unreachable")
                time.sleep(1.5 * (attempt + 1)); continue
            if r.status_code == 401 and attempt < tries - 1:
                self._token(force=True); continue
            if r.status_code == 403 and method != "GET" and "required" in (r.headers.get("x-csrf-token", "") or "").lower() and attempt < tries - 1:
                self._fetch_csrf(); continue
            if r.status_code in (429, 502, 503, 504) and attempt < tries - 1:
                time.sleep(2 ** attempt); continue
            if r.status_code >= 400:
                msg = r.text[:300].replace("\n", " ")
                try:
                    j = r.json()
                    msg = (j.get("error", {}).get("message", {}).get("value")) or j.get("message") or msg
                except Exception:
                    msg = re.sub(r"<[^>]+>", " ", msg).strip()[:200]
                raise CPIError(r.status_code, msg, _hint(r.status_code), self._role(path))
            return r
        raise last or CPIError(0, "request failed")

    @staticmethod
    def _res(r):
        j = r.json()
        d = j.get("d", j)
        if isinstance(d, dict):
            return d.get("results", d.get("value", d))
        return d

    def _all(self, path, params=None, page=500, cap=5000):
        """Page through a collection. Returns (rows, capped). Falls back to one plain call if the entity rejects $top/$skip."""
        out, skip = [], 0
        while len(out) < cap:
            q = dict(params or {}); q["$top"] = page; q["$skip"] = skip; q["$format"] = "json"
            try:
                res = self._res(self.req("GET", path, params=q))
            except CPIError as e:
                if skip == 0 and e.status == 400:
                    q = dict(params or {}); q["$format"] = "json"
                    res = self._res(self.req("GET", path, params=q))
                    return (res if isinstance(res, list) else []), False
                raise
            if not isinstance(res, list):
                break
            out += res
            if len(res) < page:
                return out, False
            skip += page
        return out[:cap], True

    def _count(self, flt):
        r = self.req("GET", "/MessageProcessingLogs/$count", params={"$filter": flt}, accept="text/plain")
        t = r.text.strip()
        if not re.fullmatch(r"\d+", t):
            raise CPIError(502, "Unexpected count response")
        return int(t)

    def ping(self):
        t0 = time.time()
        self.req("GET", "/IntegrationPackages", params={"$top": 1, "$format": "json"})
        return {"ok": True, "latency_ms": int((time.time() - t0) * 1000)}

    # ---------------- design time ----------------
    def packages(self):
        rows, _ = self._all("/IntegrationPackages")
        return [{"Id": p.get("Id"), "Name": p.get("Name"), "Version": p.get("Version"), "ShortText": p.get("ShortText"), "Vendor": p.get("Vendor"), "Mode": p.get("Mode"),
                 "Modified": iso_ms(odata_ms(p.get("ModifiedDate")))} for p in rows]

    def package_artifacts(self, pid):
        out = {}
        for key, nav in (("iflows", "IntegrationDesigntimeArtifacts"), ("valuemaps", "ValueMappingDesigntimeArtifacts"), ("scripts", "ScriptCollectionDesigntimeArtifacts")):
            try:
                rows, _ = self._all("/IntegrationPackages('%s')/%s" % (qp(pid), nav), page=200)
                out[key] = [{"Id": a.get("Id"), "Name": a.get("Name"), "Version": a.get("Version")} for a in rows]
            except CPIError as e:
                out[key] = []
                out.setdefault("errors", {})[key] = str(e)
        return out

    def export(self, kind, aid, version="active"):
        return self.req("GET", "/%s(Id='%s',Version='%s')/$value" % (KIND_SET[kind], qp(aid), qp(version)), accept="application/octet-stream").content

    def artifact_info(self, kind, aid, version="active"):
        try:
            return self._res(self.req("GET", "/%s(Id='%s',Version='%s')" % (KIND_SET[kind], qp(aid), qp(version)), params={"$format": "json"}))
        except CPIError as e:
            if e.status == 404:
                return None
            raise

    def package_info(self, pid):
        try:
            return self._res(self.req("GET", "/IntegrationPackages('%s')" % qp(pid), params={"$format": "json"}))
        except CPIError as e:
            if e.status == 404:
                return None
            raise

    def create_package(self, meta):
        body = {"Id": meta["Id"], "Name": meta.get("Name") or meta["Id"], "ShortText": meta.get("ShortText") or meta.get("Name") or meta["Id"], "Description": meta.get("ShortText") or "",
                "Version": meta.get("Version") or "1.0.0", "Vendor": meta.get("Vendor") or "", "SupportedPlatform": "SAP Cloud Integration", "Mode": "EDIT_ALLOWED"}
        self.req("POST", "/IntegrationPackages", json=body, headers={"Content-Type": "application/json"})

    def import_artifact(self, kind, aid, name, pid, content):
        body = {"Name": name, "Id": aid, "PackageId": pid, "ArtifactContent": base64.b64encode(content).decode()}
        hdr = {"Content-Type": "application/json"}
        if self.artifact_info(kind, aid):
            self.req("PUT", "/%s(Id='%s',Version='active')" % (KIND_SET[kind], qp(aid)), json=body, headers=hdr)
        else:
            self.req("POST", "/" + KIND_SET[kind], json=body, headers=hdr)

    def deploy(self, kind, aid):
        self.req("POST", "/%s?Id='%s'&Version='active'" % (KIND_DEPLOY[kind], qp(aid)))

    def undeploy(self, aid):
        self.req("DELETE", "/IntegrationRuntimeArtifacts('%s')" % qp(aid))

    # ---------------- runtime ----------------
    def runtime_artifacts(self):
        rows, _ = self._all("/IntegrationRuntimeArtifacts")
        return [{"Id": a.get("Id"), "Name": a.get("Name"), "Version": a.get("Version"), "Type": a.get("Type"), "Status": a.get("Status"),
                 "DeployedBy": a.get("DeployedBy"), "DeployedOn": iso_ms(odata_ms(a.get("DeployedOn")))} for a in rows]

    def runtime_status(self, aid):
        try:
            d = self._res(self.req("GET", "/IntegrationRuntimeArtifacts('%s')" % qp(aid), params={"$format": "json"}))
            return {"Status": d.get("Status"), "Error": self._err(aid, d)}
        except CPIError as e:
            if e.status == 404:
                return {"Status": "NOT_DEPLOYED", "Error": None}
            raise

    def _err(self, aid, d):
        if d.get("Status") not in ("ERROR", "STOPPED"):
            return None
        try:
            return self.req("GET", "/IntegrationRuntimeArtifacts('%s')/ErrorInformation/$value" % qp(aid), accept="text/plain").text[:400]
        except Exception:
            return "see runtime error information"

    # ---------------- monitoring ----------------
    def message_stats(self, hours=24):
        """Exact counts from the tenant ($count per status). Raises when the total cannot be read."""
        base = "LogStart gt datetime'%s'" % _since(hours)
        total = self._count(base)
        by, errs = {}, {}
        def one(st):
            try:
                return st, self._count(base + " and Status eq '%s'" % st), None
            except CPIError as e:
                return st, None, str(e)
        with ThreadPoolExecutor(max_workers=3) as ex:
            for st, n, e in ex.map(one, STATUSES):
                by[st] = n
                if e:
                    errs[st] = e
        return {"hours": hours, "total": total, "by_status": by, "errors": errs}

    def message_sample(self, hours=24, cap=3000):
        """Hourly buckets and per-iFlow totals from up to `cap` log entries. Flags when the sample is capped."""
        flt = "LogStart gt datetime'%s'" % _since(hours)
        rows, capped = self._all("/MessageProcessingLogs", {"$filter": flt, "$select": "MessageGuid,LogStart,Status,IntegrationFlowName", "$orderby": "LogStart desc"}, page=1000, cap=cap)
        now = time.time() * 1000
        total, failed = [0] * hours, [0] * hours
        flows = {}
        for m in rows:
            ms = odata_ms(m.get("LogStart"))
            if ms is None:
                continue
            idx = int((now - ms) // 3600000)
            if 0 <= idx < hours:
                total[hours - 1 - idx] += 1
                if m.get("Status") == "FAILED":
                    failed[hours - 1 - idx] += 1
            f = flows.setdefault(m.get("IntegrationFlowName") or "?", {"total": 0, "failed": 0})
            f["total"] += 1
            if m.get("Status") == "FAILED":
                f["failed"] += 1
        return {"series": total, "failed_series": failed, "by_flow": flows, "sampled": len(rows), "capped": capped}

    @staticmethod
    def _mpl(m):
        s, e = odata_ms(m.get("LogStart")), odata_ms(m.get("LogEnd"))
        return {"MessageGuid": m.get("MessageGuid"), "IntegrationFlowName": m.get("IntegrationFlowName"), "Status": m.get("Status"),
                "LogStart": iso_ms(s), "LogEnd": iso_ms(e), "ProcessingMs": (e - s) if (s is not None and e is not None) else None,
                "CorrelationId": m.get("CorrelationId"), "ApplicationMessageId": m.get("ApplicationMessageId"), "Sender": m.get("Sender"), "Receiver": m.get("Receiver")}

    def failed_messages(self, top=50, hours=None, iflow=None):
        return self.search_messages(iflow=iflow, status="FAILED", hours=hours, top=top)

    def search_messages(self, iflow=None, status=None, correlation_id=None, app_msg_id=None, guid=None, hours=24, top=50):
        parts = []
        if hours:
            parts.append("LogStart gt datetime'%s'" % _since(int(hours)))
        if status:
            if status.upper() not in STATUSES:
                raise CPIError(400, "Status must be one of " + ", ".join(STATUSES))
            parts.append("Status eq '%s'" % status.upper())
        if iflow:
            parts.append("IntegrationFlowName eq '%s'" % lit(iflow))
        if correlation_id:
            parts.append("CorrelationId eq '%s'" % lit(correlation_id))
        if app_msg_id:
            parts.append("ApplicationMessageId eq '%s'" % lit(app_msg_id))
        if guid:
            parts.append("MessageGuid eq '%s'" % lit(guid))
        q = {"$top": max(1, min(int(top), 200)), "$orderby": "LogEnd desc", "$format": "json"}
        if parts:
            q["$filter"] = " and ".join(parts)
        return [self._mpl(m) for m in self._res(self.req("GET", "/MessageProcessingLogs", params=q))]

    def error_text(self, guid):
        return self.req("GET", "/MessageProcessingLogs('%s')/ErrorInformation/$value" % qp(guid), accept="text/plain").text

    def message_detail(self, guid):
        """Processing log, error text, custom headers and step timeline of one message. Missing parts are reported, not hidden."""
        g = lit(guid)
        out = {"guid": g, "partial": {}}
        try:
            m = self._res(self.req("GET", "/MessageProcessingLogs('%s')" % qp(g), params={"$format": "json"}))
        except CPIError as e:
            if e.status == 404:
                return None
            raise
        out["log"] = self._mpl(m)
        out["log"]["LogLevel"] = m.get("LogLevel")
        try:
            out["error"] = self.error_text(g)[:4000] if m.get("Status") in ("FAILED", "RETRY", "ESCALATED") else None
        except CPIError as e:
            out["error"] = None; out["partial"]["error"] = str(e)
        try:
            rows = self._res(self.req("GET", "/MessageProcessingLogs('%s')/CustomHeaderProperties" % qp(g), params={"$format": "json"}))
            out["headers"] = [{"name": r.get("Name"), "value": str(r.get("Value"))[:200]} for r in (rows if isinstance(rows, list) else [])]
        except CPIError as e:
            out["headers"] = []; out["partial"]["headers"] = str(e)
        steps = []
        try:
            runs = self._res(self.req("GET", "/MessageProcessingLogs('%s')/Runs" % qp(g), params={"$format": "json", "$top": 5}))
            for run in (runs if isinstance(runs, list) else [])[:2]:
                rid = run.get("Id")
                rs = self._res(self.req("GET", "/MessageProcessingLogRuns('%s')/RunSteps" % qp(rid), params={"$format": "json", "$top": 300}))
                for s in (rs if isinstance(rs, list) else []):
                    a, b = odata_ms(s.get("StepStart")), odata_ms(s.get("StepStop"))
                    steps.append({"step": s.get("StepId") or s.get("ModelStepId"), "status": s.get("Status"), "ms": (b - a) if (a is not None and b is not None) else None})
        except CPIError as e:
            out["partial"]["steps"] = str(e)
        out["steps"] = steps
        return out

    def cert_expiry(self):
        out, now = [], time.time() * 1000
        rows, _ = self._all("/KeystoreEntries", page=500)
        for k in rows:
            ms = odata_ms(k.get("ValidNotAfter"))
            if ms is not None:
                out.append({"alias": k.get("Alias"), "type": k.get("Type"), "days": int((ms - now) // 86400000), "expires": iso_ms(ms)})
        return sorted(out, key=lambda x: x["days"])

    def credential_aliases(self):
        names, ok = set(), 0
        for path in ("/UserCredentials", "/OAuth2ClientCredentials"):
            try:
                rows, _ = self._all(path, page=500)
                names |= {r.get("Name") for r in rows if r.get("Name")}
                ok += 1
            except CPIError:
                pass
        return names if ok else None

    # ---------------- JMS queues ----------------
    def queues(self):
        rows, _ = self._all("/MessagingQueues", cap=2000)
        out = []
        for q in rows:
            act = _first(q, "active", "Active")
            state = _first(q, "state", "State", default=("Started" if act else "Stopped") if act is not None else "Unknown")
            out.append({"Name": _first(q, "name", "Name"), "State": state, "NumberOfMessages": int(_first(q, "numberOfMessages", "NumberOfMessages", "messages", "Messages", default=0) or 0),
                        "SizeInBytes": int(_first(q, "sizeInBytes", "SizeInBytes", default=0) or 0), "Exclusive": _first(q, "exclusive", "Exclusive")})
        return out

    def queue_messages(self, queue, top=100):
        rows, _ = self._all("/MessagingQueues('%s')/MessagingMessages" % qp(queue), page=100, cap=max(1, min(int(top), 1000)))
        out = []
        for m in rows:
            c = _first(m, "createdAt", "CreatedAt", "created", "storedAt", "creationTime")
            ms = odata_ms(c)
            out.append({"JmsMessageId": _first(m, "jmsMessageId", "JmsMessageId"), "Status": _first(m, "status", "Status", default=""), "RetryCount": _first(m, "retryCount", "RetryCount", default=0),
                        "Created": iso_ms(ms) if ms is not None else (str(c) if c else None), "Sender": _first(m, "sender", "Sender"), "CorrelationId": _first(m, "correlationId", "CorrelationId"),
                        "MessageId": _first(m, "messageId", "MessageId"), "Error": _first(m, "lastError", "LastError", "errorInformation")})
        return out

    def _post_json(self, path, body):
        r = self.req("POST", path, json=body, headers={"Content-Type": "application/json"})
        try:
            j = r.json()
            return int(j.get("processedCount")) if isinstance(j, dict) and j.get("processedCount") is not None else None
        except Exception:
            return None

    def retry_messages(self, queue, ids):
        """Returns the number of messages SAP reports as processed (processedCount), falling back to the number requested."""
        ids = list(ids)
        try:
            n = self._post_json("/RetryMessagingMessages", {"queueName": queue, "jmsMessageIds": ids})
            return n if n is not None else len(ids)
        except CPIError as e:
            if e.status != 400:
                raise
        done = 0
        for i in ids:
            n = self._post_json("/RetryMessagingMessages", {"queueName": queue, "jmsMessageId": i})
            done += n if n is not None else 1
        return done

    def move_messages(self, source, target, ids):
        ids = list(ids)
        try:
            n = self._post_json("/MoveMessagingMessages", {"sourceQueue": source, "targetQueue": target, "jmsMessageIds": ids})
        except CPIError as e:
            if e.status != 400:
                raise
            n = self._post_json("/MoveMessagingMessages", {"queueName": source, "targetQueueName": target, "jmsMessageIds": ids})
        return n if n is not None else len(ids)

    # ---------------- diagnostics ----------------
    def diagnose(self):
        """Probe every API the platform uses. Shows exactly which role is missing instead of showing empty data."""
        res = []
        t0 = time.time()
        try:
            tok = self._token(force=True)
            scopes, exp = [], None
            try:
                pl = json.loads(base64.urlsafe_b64decode(tok.split(".")[1] + "==="))
                sc = pl.get("scope") or []
                scopes = [s.split(".")[-1] if "." in s else s for s in sc] if isinstance(sc, list) else str(sc).split()
                exp = pl.get("exp")
            except Exception:
                pass
            res.append({"name": "OAuth token", "path": "token endpoint", "ok": True, "status": 200, "ms": int((time.time() - t0) * 1000), "rows": None, "role": "", "message": "Token issued", "scopes": sorted(set(scopes)), "exp": exp})
        except CPIError as e:
            res.append({"name": "OAuth token", "path": "token endpoint", "ok": False, "status": e.status, "ms": int((time.time() - t0) * 1000), "rows": None, "role": "", "message": str(e)})
            return res
        probes = [("Design time: packages", "/IntegrationPackages", {"$top": 5}), ("Runtime: deployed artifacts", "/IntegrationRuntimeArtifacts", {"$top": 5}),
                  ("Monitoring: message logs", "/MessageProcessingLogs", {"$top": 5, "$orderby": "LogStart desc"}), ("Monitoring: message count", "/MessageProcessingLogs/$count", None),
                  ("Security: keystore", "/KeystoreEntries", {"$top": 5}), ("Security: user credentials", "/UserCredentials", {"$top": 5}),
                  ("JMS: message queues", "/MessagingQueues", {"$top": 5})]
        def run(p):
            name, path, params = p
            t = time.time()
            try:
                if path.endswith("$count"):
                    r = self.req("GET", path, params={"$filter": "LogStart gt datetime'%s'" % _since(24)}, accept="text/plain", tries=2)
                    rows = int(r.text.strip()) if r.text.strip().isdigit() else None
                else:
                    q = dict(params or {}); q["$format"] = "json"
                    r = self.req("GET", path, params=q, tries=2)
                    j = self._res(r); rows = len(j) if isinstance(j, list) else None
                return {"name": name, "path": path, "ok": True, "status": r.status_code, "ms": int((time.time() - t) * 1000), "rows": rows, "role": self._role(path), "message": "OK"}
            except CPIError as e:
                return {"name": name, "path": path, "ok": False, "status": e.status, "ms": int((time.time() - t) * 1000), "rows": None, "role": self._role(path), "message": e.message[:160] or _hint(e.status)}
        with ThreadPoolExecutor(max_workers=4) as ex:
            res += list(ex.map(run, probes))
        return res
