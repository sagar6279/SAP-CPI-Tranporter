import threading
import cpi_client, demo_client
from store import store

_cache = {}
_lock = threading.Lock()

def client_for(name):
    t = store.get(name)
    if not t:
        raise KeyError("Tenant '%s' is not registered" % name)
    if t.get("demo"):
        return demo_client.get(t["name"])
    key = (t["name"], t["url"], t["clientid"])
    with _lock:
        c = _cache.get(key)
        if not c:
            c = cpi_client.CPIClient(t)
            _cache[key] = c
        return c

def forget(name):
    with _lock:
        for k in [k for k in _cache if k[0] == name]:
            del _cache[k]
