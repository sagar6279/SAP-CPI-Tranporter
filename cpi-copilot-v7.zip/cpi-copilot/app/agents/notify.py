def incident_email(f, tenant, stage):
    subj = "[%s][%s] Critical CPI Failure Detected - %s - %s" % (f["severity"], stage, f["iflow"], f["domain"])
    body = """Environment: %s
Subaccount / Tenant: %s
iFlow: %s
Failure Category: %s / %s
Occurrences: %s
Root Cause (confidence %d%%): %s
Recommended Resolution: %s
Business Impact: %s
Runbook: %s

AI Action Plan:
 1) Validate the evidence in the message processing log (message %s)
 2) Apply the recommended fix (approval required in PROD)
 3) Retry affected messages if the receiver is idempotent
 4) Confirm the error rate returns to baseline
""" % (stage, tenant, f["iflow"], f["domain"], f["subtype"], f.get("count"), int(f["confidence"] * 100), f["root_cause"],
       f["recommended_fix"], f.get("business_impact"), f.get("remediation_id") or "none", f.get("sample_message_guid"))
    return {"subject": subj, "body": body}
# Sending: connect Microsoft Graph (Outlook/Teams) and the ServiceNow Table API through the Destination service.
