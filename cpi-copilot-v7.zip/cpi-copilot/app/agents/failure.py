"""Failure analysis: deterministic signatures first; LLM only for unknown patterns (hook point)."""
import re

SIGNATURES = [
    (r"PKIX path building failed|unable to find valid certification path", "Security", "Untrusted/expired certificate", "P2",
     "Import the missing root/intermediate certificate into the keystore and redeploy", "RB-CERT-01"),
    (r"SSLHandshakeException|handshake_failure", "Connectivity", "SSL handshake", "P2", "Verify TLS version, cipher and the server certificate chain", "RB-SSL-01"),
    (r"UnknownHostException|Name or service not known", "Connectivity", "DNS", "P2", "Check receiver host name or Cloud Connector virtual host", None),
    (r"SocketTimeoutException|Read timed out|connect timed out", "Connectivity", "Timeout", "P3", "Check receiver availability, raise the timeout, retry if the receiver is idempotent", "RB-RETRY-01"),
    (r"\b401\b|Unauthorized|invalid_client|invalid_token", "Security", "OAuth/Authentication failure", "P2", "Verify the credential alias and OAuth client, rotate the secret if expired", "RB-OAUTH-01"),
    (r"\b403\b|Forbidden", "Security", "Authorization failure", "P3", "Check roles and scopes on the receiver side", None),
    (r"\b429\b|rate limit|Too Many Requests", "External", "Rate limit", "P3", "Throttle the sender and retry with exponential backoff", "RB-RETRY-01"),
    (r"SAXParseException|not well-formed|Unexpected character|JsonParseException|MismatchedInput", "Data", "XML/JSON parse error", "P3", "Inspect the source payload and validate it against the schema", None),
    (r"schema validation|cvc-|XSD", "Data", "Schema validation", "P3", "Compare the payload with the XSD and contact the sender owner", None),
    (r"IDoc.*(status 51|error)|IDOC_ADAPTER", "SAP Backend", "IDoc failure", "P2", "Check WE02/BD87 in the backend and reprocess", None),
    (r"OData.*(error|400|500)|/sap/opu/odata", "SAP Backend", "OData failure", "P3", "Check /IWFND/ERROR_LOG in the backend", None),
    (r"JMS.*(full|quota)|Queue.*(full|capacity)", "Platform", "JMS queue full", "P2", "Check the consumer, redrive or clear the dead-letter queue after backup", "RB-JMS-01"),
]
EXTERNAL = {"salesforce": "Salesforce", "successfactors": "SuccessFactors", "servicenow": "ServiceNow", "azure": "Azure"}
SHIFT = {"PROD": 0, "PREPROD": 1, "UAT": 2, "QA": 3, "DEV": 3}
IMPACT = [("invoice", "Order-to-cash: invoices not posted"), ("order", "Order-to-cash: sales orders delayed or rejected"),
          ("employee", "HR master data not synchronised"), ("payroll", "Payroll data not delivered"),
          ("vendor", "Procure-to-pay: vendor data out of sync"), ("gl_", "Finance: postings missing"), ("payment", "Finance: payment notifications delayed"),
          ("notify", "Notifications delayed")]


def impact(iflow):
    n = (iflow or "").lower()
    for k, v in IMPACT:
        if k in n:
            return v
    return "Business process depends on this interface"


def classify(text, stage, iflow):
    t = text or ""
    for pat, domain, sub, sev, fix, rb in SIGNATURES:
        if re.search(pat, t, re.I):
            ext = next((v for k, v in EXTERNAL.items() if k in t.lower()), None)
            n = min(int(sev[1]) + SHIFT.get(stage, 3), 4)
            return {"iflow": iflow, "stage": stage, "domain": domain, "subtype": sub, "external_system": ext, "severity": "P%d" % n,
                    "root_cause": sub + " (matched known error signature)", "recommended_fix": fix, "remediation_id": rb,
                    "confidence": 0.82, "method": "rule", "business_impact": impact(iflow)}
    return {"iflow": iflow, "stage": stage, "domain": "Unknown", "subtype": "Unclassified", "severity": "P3", "root_cause": "Unknown, needs AI or human analysis",
            "recommended_fix": "Escalate with the evidence package", "remediation_id": None, "confidence": 0.2, "method": "needs_llm", "business_impact": impact(iflow)}


def analyze(client, stage, top=25):
    from concurrent.futures import ThreadPoolExecutor
    raw = client.failed_messages(top)
    def txt(m):
        try:
            return client.error_text(m["MessageGuid"]), True
        except Exception as e:
            return "(error text unavailable: %s)" % type(e).__name__, False
    with ThreadPoolExecutor(max_workers=5) as ex:
        texts = list(ex.map(txt, raw))
    pats, msgs = {}, []
    for m, (t, ok) in zip(raw, texts):
        c = classify(t if ok else "", stage, m.get("IntegrationFlowName") or "?")
        msgs.append({**m, "domain": c["domain"], "subtype": c["subtype"], "severity": c["severity"], "error": (t or "")[:240]})
        k = (c["iflow"], c["subtype"])
        if k in pats:
            pats[k]["count"] += 1
        else:
            pats[k] = {**c, "count": 1, "sample_message_guid": m["MessageGuid"], "correlation_id": m.get("CorrelationId"), "evidence": (t or "")[:300]}
    return {"patterns": sorted(pats.values(), key=lambda x: (x["severity"], -x["count"])), "messages": msgs, "sampled": len(raw)}
