"""Real four-eyes approval: a different authenticated person with the Approve scope decides, parameters are hash-locked."""
import hashlib, json, threading, time, uuid
import audit, config

_AP = {}
_L = threading.RLock()


def _h(params):
    return hashlib.sha256(json.dumps(params, sort_keys=True, default=str).encode()).hexdigest()


def create(kind, title, params, requester, stage):
    now = time.time()
    rec = {"id": uuid.uuid4().hex[:10], "kind": kind, "title": title, "params": params, "params_hash": _h(params), "stage": stage,
           "requester": requester.name, "requester_scopes": sorted(requester.scopes), "sandbox": bool(requester.sandbox),
           "status": "PENDING", "created": now, "expires": now + config.APPROVAL_TTL_HOURS * 3600, "decided_by": None, "decided_at": None, "reason": "", "job": None}
    with _L:
        _AP[rec["id"]] = rec
        for k in list(_AP)[:-300]:
            _AP.pop(k, None)
    audit.record(requester.name, "approval.request", rec["id"], "PENDING", kind=kind, stage=stage, hash=rec["params_hash"][:12])
    return rec


def _fresh(rec):
    if rec["status"] == "PENDING" and rec["expires"] < time.time():
        rec["status"] = "EXPIRED"
    return rec


def public(rec):
    r = {k: v for k, v in rec.items() if k not in ("params", "requester_scopes")}
    p = rec["params"]
    r["summary"] = {k: p.get(k) for k in ("source", "target", "package_id", "tenant", "queue", "mode", "target_queue") if p.get(k)}
    return r


def list_for(user, status=None):
    with _L:
        out = []
        for rec in reversed(list(_AP.values())):
            _fresh(rec)
            if user.sandbox and rec["requester"] != user.name:
                continue
            if not user.sandbox and rec["sandbox"]:
                continue
            if status and rec["status"] != status:
                continue
            out.append(public(rec))
        return out


def get(aid):
    with _L:
        rec = _AP.get(aid)
        return _fresh(rec) if rec else None


def decide(aid, user, approve, reason=""):
    """Returns the record. Raises ValueError with a user-facing message when the decision is not allowed."""
    with _L:
        rec = get(aid)
        if not rec:
            raise ValueError("Approval request not found")
        if rec["sandbox"] != bool(user.sandbox):
            raise ValueError("Approval request not found")
        if rec["status"] != "PENDING":
            raise ValueError("Request is already %s" % rec["status"].lower())
        decider = "sandbox-approver" if user.sandbox else user.name
        if not user.sandbox and not user.has("Approve"):
            raise ValueError("You need the Approve permission")
        if decider == rec["requester"]:
            audit.record(user.name, "approval.decide", aid, "DENY", reason="requester cannot approve own change")
            raise ValueError("Segregation of duties: the requester cannot approve their own change")
        if _h(rec["params"]) != rec["params_hash"]:
            rec["status"] = "INVALID"
            audit.record(user.name, "approval.decide", aid, "DENY", reason="parameters changed after request")
            raise ValueError("Request was modified after it was submitted")
        rec["status"] = "APPROVED" if approve else "REJECTED"
        rec["decided_by"], rec["decided_at"], rec["reason"] = decider, time.time(), (reason or "")[:300]
        audit.record(decider, "approval.decide", aid, rec["status"], requester=rec["requester"], kind=rec["kind"])
        return rec


def pending_count(user):
    return len(list_for(user, "PENDING"))
