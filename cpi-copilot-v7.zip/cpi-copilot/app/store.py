"""Tenant registry: auto-discovered (service bindings) + permanent (cf service) + UI-added + per-user demo."""
import threading, re
import config

STAGES = ["DEV", "QA", "UAT", "PREPROD", "PROD"]

def guess_stage(name, tags=()):
    u = re.sub(r"[^A-Z0-9]", "", (name + "".join(tags or [])).upper())
    for s in ("PREPROD", "PRELIVE", "PROD", "UAT", "QA", "TEST", "DEV"):
        if s in u:
            return {"PRELIVE": "PREPROD", "TEST": "QA"}.get(s, s)
    return "DEV"

class Store:
    def __init__(self):
        self._lock = threading.Lock()
        self._ui, self._demo, self._stage, self._demo_users = {}, {}, {}, set()

    def _base(self):
        out = {}
        for name, c in config.discover().items():
            out[name] = {**c, "name": name, "stage": self._stage.get(name) or guess_stage(name, c.get("tags")), "source": "auto"}
        for name, c in config.tenants().items():
            out[name] = {**c, "name": name, "stage": self._stage.get(name) or c.get("stage") or guess_stage(name), "source": "service"}
        return out

    def all(self):
        with self._lock:
            d = self._base()
            for k, v in self._ui.items():
                d[k] = {**v, "stage": self._stage.get(k) or v["stage"]}
            d.update(self._demo)
            return d

    def get(self, name):
        a = self.all()
        if name in a:
            return a[name]
        for k, v in a.items():
            if k.lower() == (name or "").lower():
                return v
        return None

    def set_stage(self, name, stage):
        if stage not in STAGES:
            raise ValueError("invalid stage")
        with self._lock:
            self._stage[name] = stage

    def add(self, name, stage, url, tokenurl, clientid, clientsecret, user):
        name = re.sub(r"[^A-Za-z0-9_.-]", "_", name.strip())[:40]
        if not name:
            raise ValueError("name required")
        if stage not in STAGES:
            raise ValueError("invalid stage")
        for f, v in (("url", url), ("tokenurl", tokenurl), ("clientid", clientid), ("clientsecret", clientsecret)):
            if not v or not str(v).strip():
                raise ValueError(f + " is required")
        if not url.startswith("https://") or not tokenurl.startswith("https://"):
            raise ValueError("url and tokenurl must start with https://")
        with self._lock:
            if name in self._base():
                raise ValueError("name is used by an automatically connected tenant")
            self._ui[name] = {"name": name, "stage": stage, "url": url.strip(), "tokenurl": tokenurl.strip(), "clientid": clientid.strip(),
                              "clientsecret": clientsecret.strip(), "source": "ui", "added_by": user}
        return name

    def remove(self, name):
        with self._lock:
            if name in self._ui:
                del self._ui[name]; return True
        return False

    def set_demo(self, d, user):
        with self._lock:
            self._demo = d; self._demo_users.add(user)

    def clear_demo(self, user):
        with self._lock:
            self._demo_users.discard(user)

    def demo_on(self, user):
        return user in self._demo_users

    @staticmethod
    def public(t):
        host = t.get("url", "").replace("https://", "").split("/")[0]
        return {"name": t["name"], "stage": t["stage"], "source": t["source"], "host": host, "demo": bool(t.get("demo"))}

store = Store()
