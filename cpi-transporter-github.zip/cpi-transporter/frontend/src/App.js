import React, { useState, useEffect, useRef } from "react";

const API = "https://cpi-transporter.cfapps.ap21.hana.ondemand.com/api";
const WS  = "wss://cpi-transporter.cfapps.ap21.hana.ondemand.com/ws/jobs";
const cls = (...a) => a.filter(Boolean).join(" ");
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

const COLORS = {
  CAI04:      { from:"#6366f1", to:"#8b5cf6" },
  BVD_NonProd:{ from:"#f59e0b", to:"#ef4444" },
  ABBCPI:     { from:"#FF000F", to:"#ff6b35"  },
  default:    { from:"#64748b", to:"#475569"  },
};
const gc = (k) => COLORS[k] || COLORS.default;

const BG_MAIN = "#0f172a";
const BG_CARD = "#1e293b";
const BG_INPUT = "#334155";
const TEXT_MAIN = "#f1f5f9";
const TEXT_MUTE = "#94a3b8";
const BORDER = "#334155";
const ACCENT = "#FF000F";
const ACCENT2 = "#ff6b35";

const Spinner = () => (
  <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin"/>
);

const Badge = ({ status }) => {
  const map = {
    connected:["#22c55e","CONNECTED"],failed:["#ef4444","FAILED"],
    loading:  ["#f59e0b","TESTING"], complete:["#22c55e","COMPLETE"],
    running:  ["#3b82f6","RUNNING"], error:   ["#ef4444","ERROR"],
    queued:   ["#8b5cf6","QUEUED"],  passed:  ["#22c55e","PASSED"],
    scanning: ["#06b6d4","SCANNING"],pending: ["#f59e0b","PENDING"],
    approved: ["#22c55e","APPROVED"],rejected:["#ef4444","REJECTED"],
  }[status];
  if (!map) return null;
  const [bg, label] = map;
  const pulse = ["loading","running","scanning","pending"].includes(status);
  return (
    <span style={{background:bg}} className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold text-white shrink-0">
      <span className={cls("w-1.5 h-1.5 rounded-full bg-white/80", pulse&&"animate-pulse")}/>
      {label}
    </span>
  );
};

const Avatar = ({ letter, k, size="w-12 h-12 text-xl" }) => {
  const c = gc(k);
  return (
    <div className={cls(size,"rounded-2xl flex items-center justify-center text-white font-black shadow-lg")}
      style={{background:`linear-gradient(135deg,${c.from},${c.to})`}}>
      {letter}
    </div>
  );
};

const Bar = ({ pct, h=6 }) => (
  <div style={{height:h}} className="w-full bg-slate-700 rounded-full overflow-hidden">
    <div style={{
      width:`${pct}%`,height:h,
      background:pct===100?"linear-gradient(90deg,#22c55e,#16a34a)":"linear-gradient(90deg,#FF000F,#ff6b35)",
      transition:"width .5s ease",
    }} className="rounded-full"/>
  </div>
);

const Ring = ({ pct, size=52, stroke=5 }) => {
  const r=(size-stroke)/2, circ=2*Math.PI*r;
  return (
    <svg width={size} height={size} className="-rotate-90">
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="#334155" strokeWidth={stroke}/>
      <circle cx={size/2} cy={size/2} r={r} fill="none"
        stroke={pct===100?"#22c55e":"#FF000F"} strokeWidth={stroke}
        strokeDasharray={circ} strokeDashoffset={circ*(1-pct/100)}
        strokeLinecap="round" style={{transition:"stroke-dashoffset .5s ease"}}/>
    </svg>
  );
};

const LogLine = ({ log }) => {
  const cfg={
    success:{icon:"✔",cls:"text-emerald-400"},error:{icon:"✘",cls:"text-red-400"},
    warning:{icon:"⚠",cls:"text-amber-300"},complete:{icon:"★",cls:"text-violet-400"},
    info:{icon:"║",cls:"text-blue-400"},
  }[log.status]||{icon:"·",cls:"text-gray-500"};
  return (
    <div className={cls("flex gap-2.5 items-start py-[2px] font-mono text-[11px] leading-relaxed",cfg.cls)}>
      <span className="shrink-0 w-3">{cfg.icon}</span>
      <span className="text-slate-500 shrink-0 text-[10px]">{log.timestamp?new Date(log.timestamp).toLocaleTimeString():""}</span>
      <span className="bg-slate-900 text-slate-500 px-1 rounded shrink-0 text-[10px]">{String(log.progress||0).padStart(3,"0")}%</span>
      <span className="break-all">{log.message}</span>
    </div>
  );
};

const ScanRow = ({ label, status, detail }) => (
  <div className={cls("flex items-center gap-3 px-4 py-3 rounded-xl border transition-all",
    status==="pass"?"bg-emerald-900/30 border-emerald-700":
    status==="fail"?"bg-red-900/30 border-red-700":
    status==="scanning"?"bg-blue-900/30 border-blue-700":"bg-slate-800 border-slate-600"
  )}>
    <div className={cls("w-7 h-7 rounded-lg flex items-center justify-center text-white text-xs font-bold shrink-0",
      status==="pass"?"bg-emerald-500":status==="fail"?"bg-red-500":
      status==="scanning"?"bg-blue-500":"bg-slate-600"
    )}>
      {status==="pass"?"✔":status==="fail"?"✘":status==="scanning"?<Spinner/>:"○"}
    </div>
    <div className="flex-1 min-w-0">
      <div className="text-sm font-semibold text-slate-200">{label}</div>
      {detail&&<div className={cls("text-xs mt-0.5 truncate",
        status==="pass"?"text-emerald-400":status==="fail"?"text-red-400":"text-slate-500"
      )}>{detail}</div>}
    </div>
    {status==="scanning"&&<div className="w-16 h-1.5 bg-slate-600 rounded-full overflow-hidden shrink-0"><div className="h-full bg-blue-400 w-2/3 animate-pulse rounded-full"/></div>}
  </div>
);

const StepNav = ({ step }) => {
  const steps=[{n:1,label:"Tenants",icon:"01"},{n:2,label:"Objects",icon:"02"},{n:3,label:"Security",icon:"03"},{n:4,label:"Approve",icon:"04"},{n:5,label:"Deploy",icon:"05"}];
  return (
    <div className="flex items-center justify-center py-4 bg-slate-900/90 backdrop-blur border-b border-slate-700 gap-0">
      {steps.map((s,i)=>(
        <React.Fragment key={s.n}>
          <div className="flex flex-col items-center gap-1">
            <div className={cls("w-9 h-9 rounded-xl flex items-center justify-center text-sm font-bold border-2 transition-all duration-300",
              step>s.n?"bg-emerald-500 border-emerald-500 text-white shadow-lg":
              step===s.n?"bg-red-600 border-red-600 text-white shadow-xl scale-110":
              "bg-slate-800 border-slate-600 text-slate-500"
            )}>{step>s.n?"✔":s.icon}</div>
            <span className={cls("text-[11px] font-semibold hidden sm:block mt-1",
              step===s.n?"text-red-400":step>s.n?"text-emerald-400":"text-slate-500"
            )}>{s.label}</span>
          </div>
          {i<steps.length-1&&<div className={cls("w-12 sm:w-14 h-0.5 mb-5 mx-1 transition-all duration-500",step>s.n?"bg-emerald-500":"bg-slate-600")}/>}
        </React.Fragment>
      ))}
    </div>
  );
};

const DropZone = ({ label, side, tenant, tenantData, tStatus, onDrop, onClear }) => {
  const [over,setOver]=useState(false);
  const c=gc(tenant);
  return (
    <div
      onDragOver={e=>{e.preventDefault();setOver(true);}}
      onDragLeave={()=>setOver(false)}
      onDrop={e=>{e.preventDefault();setOver(false);onDrop(side,e.dataTransfer.getData("tenantKey"));}}
      className={cls("relative min-h-[170px] rounded-2xl border-2 border-dashed flex flex-col items-center justify-center transition-all duration-200",
        over?"border-red-500 bg-red-900/20 scale-[1.02] shadow-lg":
        tenant?(tStatus[tenant]==="connected"?"border-emerald-500 bg-emerald-900/20":"border-orange-500 bg-orange-900/20"):
        "border-slate-600 bg-slate-800/50 hover:border-slate-500"
      )}>
      <div className={cls("absolute -top-3 left-5 px-3 py-1 rounded-full text-[11px] font-bold text-white",
        side==="src"?"bg-gradient-to-r from-blue-600 to-indigo-600":"bg-gradient-to-r from-orange-600 to-red-600"
      )}>{label}</div>
      {tenant&&tenantData?(
        <div className="w-full p-5 text-center space-y-2">
          <Avatar letter={tenantData.name?.charAt(0)} k={tenant} size="w-14 h-14 text-2xl mx-auto"/>
          <div className="font-bold text-slate-100">{tenantData.name}</div>
          <div className="text-xs text-slate-400">{tenantData.env} · {tenantData.region}</div>
          <div className="flex justify-center">{tStatus[tenant]?<Badge status={tStatus[tenant]}/>:<span className="text-xs text-slate-500">Not tested</span>}</div>
          <button onClick={onClear} className="text-xs text-slate-500 hover:text-red-400 transition-colors">✕ Remove</button>
        </div>
      ):(
        <div className="text-center p-6 space-y-2">
          <div className="text-4xl">{side==="src"?"📤":"📥"}</div>
          <div className="text-sm font-semibold text-slate-400">Drop tenant here</div>
          <div className="text-xs text-slate-500">or click a card below</div>
        </div>
      )}
    </div>
  );
};

const TenantCard = ({ tenant, tStatus, onValidate, onClick, onDelete }) => {
  const st=tStatus[tenant.key];
  return (
    <div draggable onDragStart={e=>e.dataTransfer.setData("tenantKey",tenant.key)}
      onClick={()=>onClick(tenant.key)}
      className="group flex items-center gap-3 p-3.5 bg-slate-800/80 rounded-2xl border border-slate-700 cursor-grab active:cursor-grabbing hover:shadow-lg hover:border-slate-600 transition-all duration-200 select-none backdrop-blur">
      <div className="text-slate-500 group-hover:text-slate-400 transition-colors shrink-0">
        <svg viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4">
          <circle cx="7" cy="4" r="1.5"/><circle cx="13" cy="4" r="1.5"/>
          <circle cx="7" cy="10" r="1.5"/><circle cx="13" cy="10" r="1.5"/>
          <circle cx="7" cy="16" r="1.5"/><circle cx="13" cy="16" r="1.5"/>
        </svg>
      </div>
      <Avatar letter={((tenant.label||tenant.name)||'?').charAt(0)} k={tenant.key} size="w-10 h-10 text-base"/>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-bold text-sm text-slate-100">{tenant.label||tenant.name}</span>
          {st&&<Badge status={st}/>}
        </div>
        <div className="text-xs text-slate-400 truncate">{tenant.env} · {tenant.region}</div>
      </div>
      <button onClick={e=>{e.stopPropagation();onValidate(tenant.key);}}
        className={cls("shrink-0 px-3 py-1.5 rounded-xl text-xs font-semibold border-2 transition-all",
          st==="connected"?"bg-emerald-900/50 border-emerald-600 text-emerald-300":
          st==="loading"?"bg-amber-900/50 border-amber-600 text-amber-300 cursor-wait":
          "bg-slate-700 border-slate-600 text-slate-400 hover:border-slate-500 hover:bg-slate-600"
        )}>
        {st==="loading"?<Spinner/>:st==="connected"?"✔ OK":"Test"}
      </button>
      <button onClick={e=>{e.stopPropagation();onDelete&&onDelete(tenant.key);}}
        className="shrink-0 w-7 h-7 rounded-lg flex items-center justify-center text-slate-500 hover:text-red-400 hover:bg-red-900/30 border border-transparent hover:border-red-800 transition-all">
        <svg viewBox="0 0 20 20" fill="currentColor" className="w-3.5 h-3.5"><path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd"/></svg>
      </button>
    </div>
  );
};

const AddTenantModal = ({ onClose, onAdded, adminToken }) => {
  const [form, setForm] = useState({
    name:"", env:"Non-Production", clientid:"", clientsecret:"",
    url:"", tokenurl:"", region:""
  });
  const [testing,  setTesting]  = useState(false);
  const [testRes,  setTestRes]  = useState(null);
  const [saving,   setSaving]   = useState(false);
  const [jsonPaste,setJsonPaste]= useState("");

  const set = (k,v) => { setForm(f=>({...f,[k]:v})); setTestRes(null); };

  // Smart JSON paste — works from the paste box or Ctrl+V anywhere in modal
  const applyJson = (raw) => {
    try {
      const j = JSON.parse(raw.trim());
      const o = j.oauth || j;
      setForm(f=>({
        ...f,
        clientid:    o.clientid    || o.client_id    || f.clientid,
        clientsecret:o.clientsecret|| o.client_secret|| f.clientsecret,
        tokenurl:    o.tokenurl    || o.token_url    || o.url_service_instance || f.tokenurl,
        url:         o.url         || o.serviceurl   || o.baseurl  || f.url,
        name:        o.name        || f.name,
      }));
      setTestRes(null);
      setJsonPaste("✅ Auto-filled from JSON!");
      setTimeout(()=>setJsonPaste(""),2500);
    } catch(e) {
      setJsonPaste("❌ Invalid JSON — check format");
      setTimeout(()=>setJsonPaste(""),3000);
    }
  };

  const handlePasteBox = (e) => {
    const raw = e.target.value;
    if(raw.trim().startsWith("{")) applyJson(raw);
    else setJsonPaste(raw);
  };

  const testConn = async () => {
    setTesting(true); setTestRes(null);
    try {
      const key = form.name.replace(/ /g,"_").toUpperCase() || "TEST_"+Date.now();
      await fetch(`${API}/tenants`,{method:"POST",
        headers:{"Content-Type":"application/json"},body:JSON.stringify(form)});
      const r = await fetch(`${API}/tenants/${key}/validate`).then(r=>r.json());
      setTestRes(r);
      await fetch(`${API}/tenants/${key}`,{method:"DELETE"});
    } catch(e){ setTestRes({status:"failed",error:e.message}); }
    setTesting(false);
  };

  const save = async () => {
    if(!form.name) return alert("Display Name is required");
    if(!form.url)  return alert("CPI Host URL is required");
    if(!form.clientid) return alert("Client ID is required");
    setSaving(true);
    try {
      // Map frontend field names → backend TenantIn model field names
      const key = (form.name||"").replace(/[^a-zA-Z0-9]/g,"_").toUpperCase()||"T_"+Date.now();
      const payload = {
        key:           key,
        label:         form.name        || "",
        host:          (form.url||"").replace(/^https?:\/\//,""),
        token_url:     form.tokenurl    || "",
        client_id:     form.clientid    || "",
        client_secret: form.clientsecret|| "",
        environment:   form.env         || "Non-Production",
        region:        form.region      || ""
      };
      const r = await fetch(`${API}/tenants`,{
        method:"POST",
        headers:{"Content-Type":"application/json","Authorization":`Bearer ${adminToken}`},
        body:JSON.stringify(payload)
      });
      if(!r.ok){ const e=await r.json().catch(()=>({})); throw new Error(e.detail||r.status); }
      onAdded(); onClose();
    } catch(e){ alert("Save failed: "+e.message); }
    setSaving(false);
  };

  const envColors = {
    "Production":    {bg:"#FF000F",ring:"#FF000F"},
    "Non-Production":{bg:"#3b82f6",ring:"#3b82f6"},
    "Development":   {bg:"#22c55e",ring:"#22c55e"},
    "Sandbox":       {bg:"#f59e0b",ring:"#f59e0b"},
  };

  const Field = ({label, fkey, placeholder, type="text", required=false}) => {
    const filled = !!form[fkey];
    return (
      <div>
        <label style={{display:"block",fontSize:10,fontWeight:700,
                       color: filled?"#94a3b8":"#64748b",
                       marginBottom:5,textTransform:"uppercase",letterSpacing:1}}>
          {label}{required&&<span style={{color:"#FF000F",marginLeft:3}}>*</span>}
        </label>
        <input
          value={form[fkey]}
          onChange={e=>set(fkey,e.target.value)}
          placeholder={placeholder}
          type={type}
          style={{
            width:"100%", boxSizing:"border-box",
            padding:"10px 14px",
            background: filled?"#1e3a5f":"#0f172a",
            border: `1.5px solid ${filled?"#3b82f6":"#334155"}`,
            borderRadius:10, color:"#e2e8f0", fontSize:13,
            outline:"none", transition:"all .15s",
            fontFamily: fkey==="clientsecret"?"monospace":"inherit",
          }}
          onFocus={e=>{e.target.style.borderColor="#FF000F"; e.target.style.background="#1e293b";}}
          onBlur={e=>{e.target.style.borderColor=filled?"#3b82f6":"#334155"; e.target.style.background=filled?"#1e3a5f":"#0f172a";}}
        />
      </div>
    );
  };

  return (
    <div style={{position:"fixed",inset:0,zIndex:50,display:"flex",alignItems:"center",
                 justifyContent:"center",padding:16,background:"rgba(0,0,0,0.75)",
                 backdropFilter:"blur(8px)"}}>
      <div style={{background:"#0f172a",borderRadius:20,boxShadow:"0 24px 80px rgba(0,0,0,0.6)",
                   width:"100%",maxWidth:540,maxHeight:"92vh",overflowY:"auto",
                   border:"1px solid #1e293b"}}>

        {/* ── Header ── */}
        <div style={{padding:"18px 22px",borderBottom:"1px solid #1e293b",
                     display:"flex",alignItems:"center",justifyContent:"space-between",
                     position:"sticky",top:0,background:"#0f172a",zIndex:10,borderRadius:"20px 20px 0 0"}}>
          <div style={{display:"flex",alignItems:"center",gap:12}}>
            <div style={{width:38,height:38,borderRadius:12,background:"linear-gradient(135deg,#FF000F,#cc0000)",
                         display:"flex",alignItems:"center",justifyContent:"center",
                         boxShadow:"0 4px 14px rgba(255,0,15,0.35)"}}>
              <span style={{color:"white",fontWeight:900,fontSize:18}}>+</span>
            </div>
            <div>
              <div style={{fontWeight:800,color:"white",fontSize:16}}>Add SAP CPI Tenant</div>
              <div style={{fontSize:11,color:"#475569"}}>Connect a CPI environment</div>
            </div>
          </div>
          <button onClick={onClose}
            style={{width:32,height:32,borderRadius:10,background:"#1e293b",border:"1px solid #334155",
                    color:"#94a3b8",cursor:"pointer",fontSize:16,display:"flex",
                    alignItems:"center",justifyContent:"center"}}>✕</button>
        </div>

        <div style={{padding:"20px 22px",display:"flex",flexDirection:"column",gap:16}}>

          {/* ── JSON Paste Box ── */}
          <div style={{background:"#1e293b",border:"1px dashed #334155",borderRadius:12,padding:14}}>
            <div style={{fontSize:11,fontWeight:700,color:"#f59e0b",marginBottom:8,
                         display:"flex",alignItems:"center",gap:6}}>
              <span>💡</span>
              <span>Paste BTP Service Key JSON — all fields auto-fill instantly</span>
            </div>
            <textarea
              rows={3}
              value={typeof jsonPaste==="string"&&jsonPaste.startsWith("✅")||jsonPaste.startsWith("❌")?jsonPaste:""}
              placeholder={'Paste JSON here... {"oauth":{"clientid":"sb-...","clientsecret":"...","tokenurl":"https://...","url":"https://..."}}'}
              onChange={handlePasteBox}
              onPaste={e=>{setTimeout(()=>{const v=e.target.value;if(v.includes("{"))applyJson(v);},50);}}
              style={{width:"100%",boxSizing:"border-box",background:"#0f172a",
                      border:"1px solid #334155",borderRadius:8,color:"#7dd3fc",
                      padding:"8px 12px",fontSize:11,fontFamily:"monospace",
                      resize:"none",outline:"none",lineHeight:1.5}}
            />
            {typeof jsonPaste==="string"&&(jsonPaste.startsWith("✅")||jsonPaste.startsWith("❌"))&&(
              <div style={{marginTop:6,fontSize:12,fontWeight:700,
                           color:jsonPaste.startsWith("✅")?"#22c55e":"#ef4444"}}>
                {jsonPaste}
              </div>
            )}
          </div>

          {/* ── Environment Pills ── */}
          <div>
            <div style={{fontSize:10,fontWeight:700,color:"#64748b",marginBottom:8,
                         textTransform:"uppercase",letterSpacing:1}}>Environment</div>
            <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
              {["Production","Non-Production","Development","Sandbox"].map(e=>{
                const sel = form.env===e;
                const ec = envColors[e]||{bg:"#475569"};
                return(
                  <button key={e} onClick={()=>set("env",e)}
                    style={{padding:"6px 16px",borderRadius:20,border:`2px solid ${sel?ec.bg:"#334155"}`,
                             background:sel?ec.bg+"22":"transparent",
                             color:sel?ec.bg:"#64748b",fontWeight:700,fontSize:12,cursor:"pointer",
                             transition:"all .15s"}}>
                    {e==="Production"?"🔴":e==="Non-Production"?"🔵":e==="Development"?"🟢":"🟡"} {e}
                  </button>
                );
              })}
            </div>
          </div>

          {/* ── Fields ── */}
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
            <div style={{gridColumn:"1"}}>
              <Field label="Display Name" fkey="name" placeholder="e.g. CAI04_PROD" required/>
            </div>
            <div style={{gridColumn:"2"}}>
              <Field label="Region" fkey="region" placeholder="e.g. eu10"/>
            </div>
            <div style={{gridColumn:"1 / span 2"}}>
              <Field label="CPI Host URL" fkey="url"
                placeholder="https://xxx.it-cpiXXX.cfapps.eu10.hana.ondemand.com" required/>
            </div>
            <div style={{gridColumn:"1 / span 2"}}>
              <Field label="Token URL (auto-detected if blank)" fkey="tokenurl"
                placeholder="https://xxx.authentication.eu10.hana.ondemand.com/oauth/token"/>
            </div>
            <div style={{gridColumn:"1 / span 2"}}>
              <Field label="OAuth Client ID" fkey="clientid"
                placeholder="sb-xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx!bXXXXXX" required/>
            </div>
            <div style={{gridColumn:"1 / span 2"}}>
              <Field label="OAuth Client Secret" fkey="clientsecret"
                placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx$xxxx" type="password" required/>
            </div>
          </div>

          {/* ── Test Result ── */}
          {testRes&&(
            <div style={{padding:"12px 16px",borderRadius:12,display:"flex",alignItems:"center",gap:12,
                         background:testRes.status==="connected"?"rgba(34,197,94,0.1)":"rgba(239,68,68,0.1)",
                         border:`1px solid ${testRes.status==="connected"?"#22c55e55":"#ef444455"}`}}>
              <div style={{width:36,height:36,borderRadius:10,flexShrink:0,
                            background:testRes.status==="connected"?"#22c55e":"#ef4444",
                            display:"flex",alignItems:"center",justifyContent:"center",
                            color:"white",fontWeight:900,fontSize:16}}>
                {testRes.status==="connected"?"✔":"✘"}
              </div>
              <div>
                <div style={{fontWeight:700,fontSize:13,
                             color:testRes.status==="connected"?"#22c55e":"#ef4444"}}>
                  {testRes.status==="connected"
                    ?"✅ Connected successfully!"
                    :"❌ Failed — check credentials"}
                </div>
                {testRes.error&&(
                  <div style={{fontSize:11,color:"#94a3b8",marginTop:3,fontFamily:"monospace"}}>
                    {testRes.error}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ── Action Buttons ── */}
          <div style={{display:"flex",gap:10}}>
            <button onClick={testConn}
              disabled={testing||!form.url||!form.clientid||!form.clientsecret||!form.name}
              style={{flex:1,padding:"12px",background:"transparent",
                      border:"2px solid #334155",borderRadius:12,color:"#94a3b8",
                      fontWeight:700,fontSize:13,cursor:"pointer",
                      opacity:testing||!form.url||!form.clientid||!form.clientsecret||!form.name?0.4:1,
                      display:"flex",alignItems:"center",justifyContent:"center",gap:8}}>
              {testing
                ?<><span style={{animation:"spin 1s linear infinite",display:"inline-block"}}>⏳</span> Testing…</>
                :"🔌 Test Connection"}
            </button>
            <button onClick={save}
              disabled={saving||!form.name||!form.url||!form.clientid||!form.clientsecret}
              style={{flex:1,padding:"12px",
                      background:saving||!form.name||!form.url||!form.clientid||!form.clientsecret
                        ?"#334155":"linear-gradient(135deg,#FF000F,#cc0000)",
                      border:"none",borderRadius:12,color:"white",fontWeight:800,
                      fontSize:13,cursor:"pointer",
                      opacity:saving||!form.name||!form.url||!form.clientid||!form.clientsecret?0.5:1,
                      display:"flex",alignItems:"center",justifyContent:"center",gap:8,
                      boxShadow:"0 4px 14px rgba(255,0,15,0.3)"}}>
              {saving
                ?<><span style={{animation:"spin 1s linear infinite",display:"inline-block"}}>⏳</span> Saving…</>
                :"💾 Save Tenant"}
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};



// ══════════════════════════════════════════════════════════════
// APPROVAL PORTAL PAGE  — Standalone page (hash-routed)
// URL: https://frontend/#/approval-portal
// PIN auth: APPROVAL_PORTAL_PIN env var (default: cpi1234)
// ══════════════════════════════════════════════════════════════
const PinHintBadge = () => {
  const [hint, setHint] = React.useState(null);
  React.useEffect(()=>{
    fetch(`${API}/admin/credentials-hint`).then(r=>r.json()).then(d=>setHint(d)).catch(()=>{});
  },[]);
  if(!hint) return null;
  return(
    <div style={{background:"rgba(255,0,15,0.06)",border:"1px solid rgba(255,0,15,0.2)",
      borderRadius:10,padding:"10px 14px",marginBottom:16,textAlign:"left"}}>
      <div style={{fontSize:10,fontWeight:700,color:"#FF000F",textTransform:"uppercase",
        letterSpacing:1,marginBottom:6}}>🔑 PIN Hint</div>
      <div style={{display:"flex",justifyContent:"space-between",fontSize:12,color:"#94a3b8"}}>
        <span>Approval PIN</span>
        <span style={{fontFamily:"monospace",color:"#94a3b8"}}>{hint.approval_pin_hint} ({hint.pin_len} chars)</span>
      </div>
    </div>
  );
};

const ApprovalPortalPage = () => {
  const [pending,    setPending]    = useState([]);
  const [history,    setHistory]    = useState([]);
  const [allJobs,    setAllJobs]    = useState([]);
  const [pin,        setPin]        = useState('');
  const [pinOk,      setPinOk]      = useState(false);
  const [pinErr,     setPinErr]     = useState('');
  const [busy,       setBusy]       = useState(false);
  const [section,    setSection]    = useState('pending'); // pending|history|logs
  const [expanded,   setExpanded]   = useState({});
  const [rejectModal,setRejectModal]= useState(null);
  const [rejectReason,setRejectReason]=useState('');
  const [successMap, setSuccessMap] = useState({});
  const [viewJob,    setViewJob]    = useState(null); // full job detail modal
  const [jobLogs,    setJobLogs]    = useState(null);
  const [logsLoading,setLogsLoading]= useState(false);
  const [lastRefresh,setLastRefresh]= useState(null);

  const loadAll = async () => {
    const [p, a, j] = await Promise.all([
      fetch(`${API}/portal/pending`).then(r=>r.json()).catch(()=>[]),
      fetch(`${API}/portal/all`).then(r=>r.json()).catch(()=>[]),
      fetch(`${API}/jobs`).then(r=>r.json()).then(d=>Array.isArray(d)?d:(d.jobs||[])).catch(()=>[]),
    ]);
    setPending(Array.isArray(p)?p:[]);
    setHistory(Array.isArray(a)?a.filter(n=>n.status!=='PENDING'):[]);
    setAllJobs(Array.isArray(j)?j:[]);
    setLastRefresh(new Date().toLocaleTimeString());
  };

  useEffect(()=>{ loadAll(); const iv=setInterval(loadAll,20000); return()=>clearInterval(iv); },[]);

  const tryPin = async () => {
    if(!pin){setPinErr('Enter PIN');return;}
    const r = await fetch(`${API}/portal/verify-pin`,{
      method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({pin})
    }).then(r=>r.json()).catch(()=>({detail:'Connection error'}));
    if(r.ok){setPinOk(true);setPinErr('');}
    else setPinErr(r.detail||'Wrong PIN');
  };

  const doApprove = async (nid) => {
    setBusy(true);
    const r = await fetch(`${API}/portal/approve/${nid}`,{
      method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({pin})
    }).then(r=>r.json()).catch(e=>({error:e.message}));
    if(r.detail==='Invalid PIN'){setPinOk(false);setPinErr('PIN expired. Re-enter.');}
    else if(r.success){setSuccessMap(m=>({...m,[nid]:r.job_id||'approved'}));await loadAll();}
    else alert('Error: '+(r.detail||r.error||JSON.stringify(r)));
    setBusy(false);
  };

  const doReject = async (nid) => {
    setBusy(true);
    const r = await fetch(`${API}/portal/reject/${nid}`,{
      method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({pin,reason:rejectReason})
    }).then(r=>r.json()).catch(e=>({error:e.message}));
    if(r.detail==='Invalid PIN'){setPinOk(false);setPinErr('PIN expired. Re-enter.');}
    else if(r.success){setRejectModal(null);setRejectReason('');await loadAll();}
    else alert('Error: '+(r.detail||r.error||JSON.stringify(r)));
    setBusy(false);
  };

  const openJobLogs = async (jobId) => {
    setLogsLoading(true); setViewJob(jobId);
    const j = await fetch(`${API}/jobs/${jobId}`).then(r=>r.json()).catch(()=>null);
    setJobLogs(j); setLogsLoading(false);
  };

  const downloadLog = (jobId) => {
    window.open(`${API}/jobs/${jobId}/logs/download`,'_blank');
  };

  const countdown = (expiresAt) => {
    const ms = new Date(expiresAt) - new Date();
    if(ms<=0) return {label:'Expired',color:'#ef4444',urgent:true};
    const d=Math.floor(ms/86400000), h=Math.floor((ms%86400000)/3600000), m=Math.floor((ms%3600000)/60000);
    const urgent = d < 1;
    return {label:`${d}d ${h}h ${m}m`,color:urgent?'#f59e0b':'#22c55e',urgent};
  };

  const statusBadge = (s) => {
    const map={PENDING:{c:'#f59e0b',bg:'rgba(245,158,11,0.12)',icon:'⏳'},
               APPROVED:{c:'#22c55e',bg:'rgba(34,197,94,0.12)',icon:'✅'},
               REJECTED:{c:'#ef4444',bg:'rgba(239,68,68,0.12)',icon:'❌'},
               ARCHIVED:{c:'#64748b',bg:'rgba(100,116,139,0.12)',icon:'🗄'}};
    const v=map[s]||map.ARCHIVED;
    return <span style={{background:v.bg,border:`1px solid ${v.c}44`,borderRadius:20,
                          padding:'2px 10px',color:v.c,fontSize:11,fontWeight:700}}>{v.icon} {s}</span>;
  };

  return (
    <div style={{minHeight:'100vh',background:'#0f172a',color:'#e2e8f0',fontFamily:'system-ui,sans-serif'}}>
      {/* ── HEADER ── */}
      <header style={{background:'linear-gradient(135deg,#1a1a2e,#16213e)',borderBottom:'1px solid #334155',
                      padding:'0 28px',height:58,display:'flex',alignItems:'center',justifyContent:'space-between',
                      position:'sticky',top:0,zIndex:100}}>
        <div style={{display:'flex',alignItems:'center',gap:14}}>
          <div style={{width:38,height:38,background:'linear-gradient(145deg,#FF000F,#7f0000)',
                       borderRadius:10,display:'flex',alignItems:'center',justifyContent:'center',
                       boxShadow:'0 0 0 1px rgba(255,0,15,0.4),0 4px 16px rgba(255,0,15,0.3)'}}>
            <span style={{color:'white',fontWeight:900,fontSize:14}}>SR</span>
          </div>
          <div>
            <div style={{fontWeight:900,fontSize:16,letterSpacing:1,color:'white'}}>
              SAP CPI — APPROVAL PORTAL
            </div>
            <div style={{fontSize:10,color:'#475569',display:'flex',alignItems:'center',gap:6}}>
              <span style={{background:'rgba(255,0,15,0.15)',border:'1px solid rgba(255,0,15,0.3)',
                             borderRadius:4,padding:'1px 5px',color:'#ff6b6b',fontWeight:700,fontSize:9}}>
                ● LIVE
              </span>
              Production Transport Approval System · {lastRefresh&&`Last updated: ${lastRefresh}`}
            </div>
          </div>
        </div>
        <div style={{display:'flex',alignItems:'center',gap:10}}>
          <div style={{background:'rgba(255,0,15,0.1)',border:'1px solid rgba(255,0,15,0.25)',
                       borderRadius:8,padding:'4px 12px',color:'#ff9999',fontSize:12,fontWeight:700}}>
            🔴 {pending.length} Pending
          </div>
          <button onClick={()=>window.location.hash=''}
            style={{background:'#1e293b',border:'1px solid #334155',borderRadius:8,
                    color:'#94a3b8',padding:'6px 14px',cursor:'pointer',fontSize:12}}>
            ← Back to App
          </button>
        </div>
      </header>

      {/* ── PIN LOCK ── */}
      {!pinOk&&(
        <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.85)',display:'flex',
                     alignItems:'center',justifyContent:'center',zIndex:200}}>
          <div style={{background:'#1e293b',border:'1px solid #334155',borderRadius:20,
                       padding:'40px 44px',width:360,maxWidth:'92%',textAlign:'center'}}>
            <div style={{fontSize:52,marginBottom:12}}>🔐</div>
            <div style={{fontWeight:900,fontSize:22,color:'white',marginBottom:4}}>Enter Approval PIN</div>
            <div style={{fontSize:12,color:'#475569',marginBottom:24}}>
              Required to approve or reject transports<br/>
              <span style={{color:'#334155',fontSize:11}}>Default PIN: cpi1234 (change via APPROVAL_PORTAL_PIN env var)</span>
            </div>
            {pinErr&&<div style={{background:'rgba(239,68,68,0.1)',border:'1px solid #ef444455',
                                   borderRadius:8,padding:'8px 14px',color:'#f87171',
                                   fontSize:12,marginBottom:14}}>{pinErr}</div>}
            <input type="password" value={pin}
              onChange={e=>setPin(e.target.value)}
              onKeyDown={e=>e.key==='Enter'&&tryPin()}
              placeholder="Enter PIN…"
              autoFocus
              style={{width:'100%',background:'#0f172a',border:'1px solid #334155',borderRadius:10,
                      padding:'12px 16px',color:'white',fontSize:18,textAlign:'center',
                      letterSpacing:4,marginBottom:16,boxSizing:'border-box'}}/>
            <button onClick={tryPin}
              style={{width:'100%',padding:'13px',background:'linear-gradient(135deg,#FF000F,#cc0000)',
                      border:'none',borderRadius:10,color:'white',fontWeight:900,fontSize:15,cursor:'pointer'}}>
              Unlock Portal →
            </button>
            <button onClick={loadAll} style={{marginTop:12,background:'transparent',border:'none',
                                              color:'#334155',fontSize:12,cursor:'pointer'}}>
              View only (no PIN needed)
            </button>
          </div>
        </div>
      )}

      
{/* ══════════════════════════════════════════════════════
    CHANGE PASSWORD MODAL
══════════════════════════════════════════════════════ */}
{showChangePw&&(
<div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.75)',display:'flex',
  alignItems:'center',justifyContent:'center',zIndex:500}}>
  <div style={{background:'#1e293b',border:'1px solid #334155',borderRadius:20,
    padding:32,width:400,maxWidth:'94%'}}>
    <div style={{fontWeight:900,fontSize:18,color:'white',marginBottom:4}}>🔑 Change Password</div>
    <div style={{color:'#64748b',fontSize:12,marginBottom:20}}>Update your admin portal password</div>
    {pwMsg.text&&<div style={{padding:'8px 12px',borderRadius:8,marginBottom:14,fontSize:12,
      background:pwMsg.type==='error'?'rgba(239,68,68,0.12)':pwMsg.type==='success'?'rgba(34,197,94,0.12)':'rgba(96,165,250,0.12)',
      border:`1px solid ${pwMsg.type==='error'?'#ef4444':pwMsg.type==='success'?'#22c55e':'#60a5fa'}`,
      color:pwMsg.type==='error'?'#f87171':pwMsg.type==='success'?'#4ade80':'#93c5fd'}}>{pwMsg.text}</div>}
    {[{ph:'Current Password',key:'current'},{ph:'New Password',key:'new_'},{ph:'Confirm New Password',key:'confirm'}].map(f=>(
      <input key={f.key} type="password" placeholder={f.ph} value={pwForm[f.key]}
        onChange={e=>setPwForm(p=>({...p,[f.key]:e.target.value}))}
        style={{width:'100%',background:'#0f172a',border:'1px solid #334155',borderRadius:10,
          padding:'11px 14px',color:'white',fontSize:13,marginBottom:10,boxSizing:'border-box'}}/>
    ))}
    <div style={{display:'flex',gap:10,marginTop:6}}>
      <button onClick={()=>setShowChangePw(false)}
        style={{flex:1,padding:'10px',background:'transparent',border:'1px solid #334155',
          borderRadius:10,color:'#64748b',cursor:'pointer',fontWeight:600}}>Cancel</button>
      <button onClick={doChangePw}
        style={{flex:1,padding:'10px',background:'linear-gradient(135deg,#FF000F,#cc0000)',
          border:'none',borderRadius:10,color:'white',cursor:'pointer',fontWeight:700}}>
        Update Password
      </button>
    </div>
  </div>
</div>
)}

{/* ══════════════════════════════════════════════════════
    FORGOT PASSWORD MODAL
══════════════════════════════════════════════════════ */}
{showForgotPw&&(
<div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.75)',display:'flex',
  alignItems:'center',justifyContent:'center',zIndex:500}}>
  <div style={{background:'#1e293b',border:'1px solid #334155',borderRadius:20,
    padding:32,width:400,maxWidth:'94%'}}>
    <div style={{fontWeight:900,fontSize:18,color:'white',marginBottom:4}}>🔑 Forgot Password</div>
    <div style={{color:'#64748b',fontSize:12,marginBottom:20}}>
      {resetStep===1?'Step 1 of 2 — Enter your username to get a reset token':'Step 2 of 2 — Enter reset token and new password'}
    </div>
    {pwMsg.text&&<div style={{padding:'8px 12px',borderRadius:8,marginBottom:14,fontSize:12,
      background:pwMsg.type==='error'?'rgba(239,68,68,0.12)':pwMsg.type==='success'?'rgba(34,197,94,0.12)':'rgba(96,165,250,0.12)',
      border:`1px solid ${pwMsg.type==='error'?'#ef4444':pwMsg.type==='success'?'#22c55e':'#60a5fa'}`,
      color:pwMsg.type==='error'?'#f87171':pwMsg.type==='success'?'#4ade80':'#93c5fd'}}>{pwMsg.text}</div>}
    {resetStep===1?(
      <input placeholder="Username" value={forgotUser} onChange={e=>setForgotUser(e.target.value)}
        onKeyDown={e=>e.key==='Enter'&&doForgotStep1()}
        style={{width:'100%',background:'#0f172a',border:'1px solid #334155',borderRadius:10,
          padding:'11px 14px',color:'white',fontSize:13,marginBottom:14,boxSizing:'border-box'}}/>
    ):(
      <>
        <div style={{background:'rgba(96,165,250,0.08)',border:'1px solid rgba(96,165,250,0.2)',
          borderRadius:8,padding:'8px 12px',marginBottom:10,fontSize:12}}>
          <div style={{color:'#64748b',marginBottom:3}}>Your Reset Token:</div>
          <div style={{color:'#60a5fa',fontFamily:'monospace',fontWeight:700,wordBreak:'break-all'}}>{forgotToken}</div>
        </div>
        <input placeholder="Reset Token (auto-filled above)" value={forgotToken}
          onChange={e=>setForgotToken(e.target.value)}
          style={{width:'100%',background:'#0f172a',border:'1px solid #334155',borderRadius:10,
            padding:'11px 14px',color:'white',fontSize:13,marginBottom:8,boxSizing:'border-box'}}/>
        <input type="password" placeholder="New Password" value={forgotNewPw}
          onChange={e=>setForgotNewPw(e.target.value)}
          style={{width:'100%',background:'#0f172a',border:'1px solid #334155',borderRadius:10,
            padding:'11px 14px',color:'white',fontSize:13,marginBottom:8,boxSizing:'border-box'}}/>
        <input type="password" placeholder="Confirm New Password" value={forgotConfirm}
          onChange={e=>setForgotConfirm(e.target.value)}
          onKeyDown={e=>e.key==='Enter'&&doForgotStep2()}
          style={{width:'100%',background:'#0f172a',border:'1px solid #334155',borderRadius:10,
            padding:'11px 14px',color:'white',fontSize:13,marginBottom:8,boxSizing:'border-box'}}/>
      </>
    )}
    <div style={{display:'flex',gap:10,marginTop:6}}>
      <button onClick={()=>{setShowForgotPw(false);setResetStep(1);setPwMsg({text:"",type:""}); }}
        style={{flex:1,padding:'10px',background:'transparent',border:'1px solid #334155',
          borderRadius:10,color:'#64748b',cursor:'pointer',fontWeight:600}}>Cancel</button>
      <button onClick={resetStep===1?doForgotStep1:doForgotStep2}
        style={{flex:1,padding:'10px',background:'linear-gradient(135deg,#3b82f6,#1d4ed8)',
          border:'none',borderRadius:10,color:'white',cursor:'pointer',fontWeight:700}}>
        {resetStep===1?'Get Reset Token →':'Reset Password →'}
      </button>
    </div>
  </div>
</div>
)}

{/* ══════════════════════════════════════════════════════
    CHANGE PIN MODAL
══════════════════════════════════════════════════════ */}
{(showChangePin||showForgotPin)&&(
<div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.75)',display:'flex',
  alignItems:'center',justifyContent:'center',zIndex:500}}>
  <div style={{background:'#1e293b',border:'1px solid #334155',borderRadius:20,
    padding:32,width:400,maxWidth:'94%'}}>
    <div style={{fontWeight:900,fontSize:18,color:'white',marginBottom:4}}>
      🔒 {showForgotPin?'Reset Approval PIN':'Change Approval PIN'}
    </div>
    <div style={{color:'#64748b',fontSize:12,marginBottom:20}}>
      {showForgotPin
        ?'Admin only — override the Approval Portal PIN'
        :'Update the PIN used to unlock the Approval Portal'}
    </div>
    {pinMsg.text&&<div style={{padding:'8px 12px',borderRadius:8,marginBottom:14,fontSize:12,
      background:pinMsg.type==='error'?'rgba(239,68,68,0.12)':pinMsg.type==='success'?'rgba(34,197,94,0.12)':'rgba(96,165,250,0.12)',
      border:`1px solid ${pinMsg.type==='error'?'#ef4444':pinMsg.type==='success'?'#22c55e':'#60a5fa'}`,
      color:pinMsg.type==='error'?'#f87171':pinMsg.type==='success'?'#4ade80':'#93c5fd'}}>{pinMsg.text}</div>}
    {[
      {ph:'Current PIN',key:'current'},
      {ph:'New PIN (min 4 chars)',key:'new_'},
      {ph:'Confirm New PIN',key:'confirm'}
    ].map(f=>(
      <input key={f.key} type="password" placeholder={f.ph} value={pinForm[f.key]}
        onChange={e=>setPinForm(p=>({...p,[f.key]:e.target.value}))}
        style={{width:'100%',background:'#0f172a',border:'1px solid #334155',borderRadius:10,
          padding:'11px 14px',color:'white',fontSize:13,marginBottom:10,
          textAlign:'center',letterSpacing:3,boxSizing:'border-box'}}/>
    ))}
    <div style={{color:'#475569',fontSize:11,marginBottom:12,textAlign:'center'}}>
      ⚠ Admin token required — must be logged into Admin Portal to change PIN
    </div>
    <div style={{display:'flex',gap:10}}>
      <button onClick={()=>{setShowChangePin(false);setShowForgotPin(false);setPinMsg({text:"",type:""}); }}
        style={{flex:1,padding:'10px',background:'transparent',border:'1px solid #334155',
          borderRadius:10,color:'#64748b',cursor:'pointer',fontWeight:600}}>Cancel</button>
      <button onClick={doChangePin}
        style={{flex:1,padding:'10px',background:'linear-gradient(135deg,#7c3aed,#5b21b6)',
          border:'none',borderRadius:10,color:'white',cursor:'pointer',fontWeight:700}}>
        Update PIN
      </button>
    </div>
  </div>
</div>
)}

{/* ── REJECT MODAL ── */}
      {rejectModal&&(
        <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.7)',display:'flex',
                     alignItems:'center',justifyContent:'center',zIndex:300}}>
          <div style={{background:'#1e293b',border:'1px solid #ef4444',borderRadius:14,
                       padding:28,width:400,maxWidth:'92%'}}>
            <div style={{fontWeight:900,color:'#ef4444',marginBottom:8,fontSize:16}}>❌ Reject Transport</div>
            <div style={{color:'#94a3b8',fontSize:13,marginBottom:12}}>
              <b style={{color:'#e2e8f0'}}>{rejectModal.transport_id}</b> — {rejectModal.package_name}
            </div>
            <textarea value={rejectReason} onChange={e=>setRejectReason(e.target.value)}
              placeholder="Reason for rejection (optional)…"
              style={{width:'100%',background:'#0f172a',border:'1px solid #475569',borderRadius:8,
                      color:'#e2e8f0',padding:10,fontSize:13,resize:'vertical',
                      minHeight:90,boxSizing:'border-box'}}/>
            <div style={{display:'flex',gap:8,marginTop:12}}>
              <button onClick={()=>{setRejectModal(null);setRejectReason('');}}
                style={{flex:1,padding:'9px',background:'transparent',border:'1px solid #475569',
                        color:'#94a3b8',borderRadius:8,cursor:'pointer',fontWeight:600}}>Cancel</button>
              <button onClick={()=>doReject(rejectModal.id)} disabled={busy}
                style={{flex:1,padding:'9px',background:'#ef4444',border:'none',
                        color:'white',borderRadius:8,cursor:'pointer',fontWeight:700}}>Confirm Reject</button>
            </div>
          </div>
        </div>
      )}

      {/* ── JOB LOG MODAL ── */}
      {viewJob&&(
        <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.85)',display:'flex',
                     alignItems:'center',justifyContent:'center',zIndex:300,padding:20}}>
          <div style={{background:'#1e293b',border:'1px solid #334155',borderRadius:16,
                       width:'100%',maxWidth:820,maxHeight:'85vh',display:'flex',flexDirection:'column'}}>
            {/* Modal header */}
            <div style={{padding:'16px 22px',borderBottom:'1px solid #334155',
                         display:'flex',alignItems:'center',justifyContent:'space-between',flexShrink:0}}>
              <div>
                <div style={{fontWeight:900,color:'white',fontSize:16}}>
                  📋 Transport Log — {jobLogs?.transport_id||viewJob.slice(0,8)+'…'}
                </div>
                {jobLogs&&(
                  <div style={{fontSize:12,color:'#64748b',marginTop:2}}>
                    {jobLogs.source} → {jobLogs.target} ·
                    {' '}{(jobLogs.artifact_details||[]).length} artifacts ·
                    {' '}<span style={{color:jobLogs.status==='complete'?'#22c55e':'#ef4444',fontWeight:700}}>
                      {jobLogs.status?.toUpperCase()}
                    </span>
                    {jobLogs.days_until_expiry!=null&&(
                      <span style={{color:'#f59e0b',marginLeft:8}}>
                        ⏱ Expires in {jobLogs.days_until_expiry}d
                      </span>
                    )}
                  </div>
                )}
              </div>
              <div style={{display:'flex',gap:8}}>
                <button onClick={()=>downloadLog(viewJob)}
                  style={{padding:'7px 16px',background:'linear-gradient(135deg,#FF000F,#cc0000)',
                          border:'none',borderRadius:8,color:'white',fontWeight:700,
                          fontSize:13,cursor:'pointer'}}>
                  ⬇ Download Log
                </button>
                <button onClick={()=>{setViewJob(null);setJobLogs(null);}}
                  style={{padding:'7px 14px',background:'#334155',border:'none',
                          borderRadius:8,color:'#94a3b8',cursor:'pointer',fontSize:13}}>✕</button>
              </div>
            </div>
            {/* Transport details */}
            {jobLogs&&!logsLoading&&(
              <div style={{padding:'12px 22px',borderBottom:'1px solid #1e293b',
                           display:'flex',gap:20,flexWrap:'wrap',flexShrink:0,
                           background:'rgba(0,0,0,0.2)'}}>
                <div style={{fontSize:12}}>
                  <span style={{color:'#475569'}}>TR ID: </span>
                  <span style={{color:'#FF000F',fontWeight:700,fontFamily:'monospace'}}>{jobLogs.transport_id}</span>
                </div>
                <div style={{fontSize:12}}>
                  <span style={{color:'#475569'}}>Package: </span>
                  <span style={{color:'#e2e8f0',fontWeight:600}}>{(jobLogs.package_ids||[]).join(', ')}</span>
                </div>
                <div style={{fontSize:12}}>
                  <span style={{color:'#475569'}}>Artifacts: </span>
                  <span style={{color:'#7dd3fc',fontWeight:600}}>{(jobLogs.artifact_details||[]).map(a=>a.name).join(', ')||'(scanning…)'}</span>
                </div>
                <div style={{fontSize:12}}>
                  <span style={{color:'#475569'}}>Started: </span>
                  <span style={{color:'#94a3b8'}}>{jobLogs.created_at&&new Date(jobLogs.created_at).toLocaleString()}</span>
                </div>
                {jobLogs.completed_at&&<div style={{fontSize:12}}>
                  <span style={{color:'#475569'}}>Completed: </span>
                  <span style={{color:'#22c55e'}}>{new Date(jobLogs.completed_at).toLocaleString()}</span>
                </div>}
                {jobLogs.approved_by&&<div style={{fontSize:12}}>
                  <span style={{color:'#475569'}}>Approved by: </span>
                  <span style={{color:'#a78bfa',fontWeight:700}}>{jobLogs.approved_by}</span>
                </div>}
              </div>
            )}
            {/* Log lines */}
            <div style={{flex:1,overflow:'auto',padding:'14px 22px',
                         fontFamily:'monospace',fontSize:12,background:'#0f172a'}}>
              {logsLoading?(
                <div style={{color:'#475569',textAlign:'center',padding:40}}>Loading logs…</div>
              ):jobLogs?.logs?.length===0?(
                <div style={{color:'#475569',textAlign:'center',padding:40}}>No log entries yet</div>
              ):(jobLogs?.logs||[]).map((entry,i)=>{
                const clr={success:'#22c55e',error:'#ef4444',warning:'#f59e0b',
                           complete:'#a78bfa',info:'#64748b'}[entry.status]||'#64748b';
                const ts=(entry.timestamp||'').slice(11,19);
                const pct=entry.progress!=null?` [${String(entry.progress).padStart(3)}%]`:'';
                return(
                  <div key={i} style={{color:clr,marginBottom:2,lineHeight:1.5}}>
                    <span style={{color:'#1e293b',fontSize:10}}>[{ts}]</span>
                    <span style={{color:'#334155'}}>{pct}</span>
                    {' '}{entry.message}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ── MAIN CONTENT ── */}
      <div style={{maxWidth:1100,margin:'0 auto',padding:'28px 20px'}}>

        {/* Section tabs */}
        <div style={{display:'flex',gap:4,marginBottom:24,background:'#1e293b',
                     borderRadius:14,padding:4,border:'1px solid #334155',width:'fit-content'}}>
          {[
            {id:'pending', icon:'🔔', label:`Pending (${pending.length})`},
            {id:'history', icon:'📜', label:'Approval History'},
            {id:'logs',    icon:'📋', label:`Transport Logs (${allJobs.length})`},
          ].map(t=>(
            <button key={t.id} onClick={()=>setSection(t.id)}
              style={{padding:'9px 20px',borderRadius:10,border:'none',cursor:'pointer',
                      fontWeight:700,fontSize:13,transition:'all .15s',
                      background:section===t.id?'#334155':'transparent',
                      color:section===t.id?'#e2e8f0':'#475569'}}>
              {t.icon} {t.label}
            </button>
          ))}
          <button onClick={loadAll}
            style={{padding:'9px 14px',borderRadius:10,border:'none',cursor:'pointer',
                    background:'transparent',color:'#334155',fontSize:13}}>
            ↻
          </button>
        </div>

        {/* ── PENDING APPROVALS ── */}
        {section==='pending'&&(
          <div>
            {pending.length===0?(
              <div style={{textAlign:'center',padding:'80px 20px',color:'#334155'}}>
                <div style={{fontSize:56,marginBottom:12}}>✅</div>
                <div style={{fontSize:20,fontWeight:700,color:'#475569'}}>No pending approvals</div>
                <div style={{fontSize:14,marginTop:8,color:'#334155'}}>All production transports are approved or archived</div>
              </div>
            ):(
              <div style={{display:'flex',flexDirection:'column',gap:16}}>
                {pending.map(n=>{
                  const cd=countdown(n.expires_at);
                  const isSucc=successMap[n.id];
                  if(isSucc) return(
                    <div key={n.id} style={{background:'rgba(34,197,94,0.1)',border:'2px solid #22c55e',
                                             borderRadius:16,padding:'20px 24px',
                                             display:'flex',alignItems:'center',gap:12}}>
                      <div style={{fontSize:32}}>✅</div>
                      <div>
                        <div style={{color:'#22c55e',fontWeight:900,fontSize:16}}>Transport Approved & Started!</div>
                        <div style={{color:'#64748b',fontSize:13}}>Job ID: {isSucc.slice(0,8)}… | {n.transport_id}</div>
                      </div>
                    </div>
                  );
                  const isExp=!expanded[n.id];
                  return(
                    <div key={n.id} style={{background:'#1e293b',border:`2px solid ${cd.urgent?'#f59e0b':'#334155'}`,
                                             borderRadius:16,overflow:'hidden',
                                             transition:'border-color .3s'}}>
                      {/* Card header */}
                      <div style={{padding:'16px 22px',background:cd.urgent?'rgba(245,158,11,0.06)':'rgba(255,0,15,0.04)',
                                   borderBottom:'1px solid #334155',cursor:'pointer'}}
                           onClick={()=>setExpanded(e=>({...e,[n.id]:!e[n.id]}))}>
                        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',flexWrap:'wrap',gap:8}}>
                          <div style={{display:'flex',alignItems:'center',gap:12}}>
                            <div style={{background:'rgba(255,0,15,0.12)',border:'1px solid rgba(255,0,15,0.3)',
                                         borderRadius:8,padding:'6px 14px'}}>
                              <div style={{color:'#FF000F',fontFamily:'monospace',fontWeight:900,fontSize:14}}>
                                {n.transport_id}
                              </div>
                            </div>
                            <div>
                              <div style={{color:'white',fontWeight:700,fontSize:16}}>{n.package_name}</div>
                              <div style={{color:'#64748b',fontSize:12,marginTop:2}}>
                                Requested by <b style={{color:'#94a3b8'}}>{n.requested_by||'user'}</b> ·{' '}
                                {new Date(n.created_at).toLocaleString()}
                              </div>
                            </div>
                          </div>
                          <div style={{display:'flex',alignItems:'center',gap:10,flexShrink:0}}>
                            <div style={{background:`${cd.color}18`,border:`1px solid ${cd.color}44`,
                                         borderRadius:8,padding:'5px 12px',
                                         color:cd.color,fontWeight:700,fontSize:12}}>
                              ⏱ {cd.label}
                            </div>
                            {statusBadge('PENDING')}
                            <span style={{color:'#475569',fontSize:16}}>{isExp?'▼':'▲'}</span>
                          </div>
                        </div>
                      </div>

                      {/* Expanded details */}
                      {expanded[n.id]&&(
                        <div style={{padding:'18px 22px'}}>
                          {/* Source → Target */}
                          <div style={{display:'flex',alignItems:'center',gap:16,marginBottom:16,
                                       padding:'12px 18px',background:'rgba(0,0,0,0.2)',borderRadius:10}}>
                            <div style={{textAlign:'center'}}>
                              <div style={{fontSize:10,color:'#475569',fontWeight:700,textTransform:'uppercase',letterSpacing:1,marginBottom:4}}>Source</div>
                              <div style={{color:'#3b82f6',fontWeight:900,fontSize:16}}>{n.source}</div>
                            </div>
                            <div style={{flex:1,height:2,background:'linear-gradient(90deg,#3b82f6,#FF000F)',borderRadius:2}}/>
                            <div style={{fontSize:24}}>🎯</div>
                            <div style={{flex:1,height:2,background:'linear-gradient(90deg,#FF000F,#FF000F)',borderRadius:2}}/>
                            <div style={{textAlign:'center'}}>
                              <div style={{fontSize:10,color:'#475569',fontWeight:700,textTransform:'uppercase',letterSpacing:1,marginBottom:4}}>Target (PROD)</div>
                              <div style={{color:'#FF000F',fontWeight:900,fontSize:16}}>{n.target}</div>
                            </div>
                          </div>

                          {/* Artifacts list */}
                          <div style={{marginBottom:16}}>
                            <div style={{fontSize:11,color:'#475569',fontWeight:700,textTransform:'uppercase',
                                         letterSpacing:1,marginBottom:8}}>
                              iFlows / Artifacts ({(n.iflows||[]).length})
                            </div>
                            <div style={{display:'flex',flexWrap:'wrap',gap:6}}>
                              {(n.iflows||[]).map((f,i)=>(
                                <span key={i} style={{background:'rgba(99,102,241,0.1)',
                                                       border:'1px solid rgba(99,102,241,0.3)',
                                                       borderRadius:6,padding:'4px 10px',
                                                       color:'#a5b4fc',fontSize:12}}>{f}</span>
                              ))}
                            </div>
                          </div>

                          {/* Artifact details if available */}
                          {(n.artifact_details||[]).length>0&&(
                            <div style={{marginBottom:16}}>
                              <div style={{fontSize:11,color:'#475569',fontWeight:700,textTransform:'uppercase',letterSpacing:1,marginBottom:8}}>
                                Artifact Details
                              </div>
                              <table style={{width:'100%',borderCollapse:'collapse',fontSize:12}}>
                                <thead>
                                  <tr style={{background:'#0f172a'}}>
                                    {['Artifact ID','Artifact Name','Package'].map(h=>(
                                      <th key={h} style={{padding:'7px 12px',textAlign:'left',color:'#475569',fontWeight:700,borderBottom:'1px solid #334155'}}>{h}</th>
                                    ))}
                                  </tr>
                                </thead>
                                <tbody>
                                  {(n.artifact_details||[]).map((a,i)=>(
                                    <tr key={i} style={{background:i%2===0?'rgba(0,0,0,0.2)':'transparent'}}>
                                      <td style={{padding:'7px 12px',color:'#7dd3fc',fontFamily:'monospace',fontSize:11}}>{a.id}</td>
                                      <td style={{padding:'7px 12px',color:'#e2e8f0',fontWeight:600}}>{a.name}</td>
                                      <td style={{padding:'7px 12px',color:'#94a3b8'}}>{a.package_id}</td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div>
                          )}

                          {/* Action buttons */}
                          <div style={{display:'flex',gap:12,alignItems:'center',
                                       paddingTop:14,borderTop:'1px solid #334155'}}>
                            <button onClick={()=>pinOk?doApprove(n.id):alert('Unlock portal first')}
                              disabled={busy||!pinOk}
                              style={{padding:'12px 28px',background:'linear-gradient(135deg,#16a34a,#15803d)',
                                      border:'none',borderRadius:10,color:'white',fontWeight:900,
                                      fontSize:15,cursor:busy||!pinOk?'not-allowed':'pointer',
                                      opacity:busy||!pinOk?0.5:1,boxShadow:'0 4px 14px rgba(22,163,74,0.3)'}}>
                              ✅ Approve & Start Transport
                            </button>
                            <button onClick={()=>pinOk?setRejectModal(n):alert('Unlock portal first')}
                              disabled={busy||!pinOk}
                              style={{padding:'12px 24px',background:'rgba(239,68,68,0.1)',
                                      border:'2px solid #ef4444',borderRadius:10,color:'#f87171',
                                      fontWeight:700,fontSize:15,cursor:busy||!pinOk?'not-allowed':'pointer',
                                      opacity:busy||!pinOk?0.5:1}}>
                              ❌ Reject
                            </button>
                            {!pinOk&&(
                              <span style={{fontSize:12,color:'#f59e0b'}}>🔐 Unlock portal to take action</span>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ── APPROVAL HISTORY ── */}
        {section==='history'&&(
          <div>
            <div style={{fontSize:13,color:'#475569',marginBottom:16}}>
              All approval decisions · notifications visible for 3 days
            </div>
            {history.length===0?(
              <div style={{textAlign:'center',padding:'60px',color:'#334155'}}>
                <div style={{fontSize:40,marginBottom:10}}>📜</div>
                <div style={{color:'#475569',fontWeight:700}}>No history yet</div>
              </div>
            ):(
              <div style={{display:'flex',flexDirection:'column',gap:8}}>
                {history.map((n,i)=>{
                  const sColor={APPROVED:'#22c55e',REJECTED:'#ef4444',ARCHIVED:'#64748b'}[n.status]||'#64748b';
                  return(
                    <div key={n.id} style={{background:'#1e293b',border:'1px solid #334155',
                                             borderRadius:12,padding:'14px 20px',
                                             display:'flex',alignItems:'center',gap:14,flexWrap:'wrap'}}>
                      <div style={{flexShrink:0}}>
                        <div style={{fontFamily:'monospace',color:'#FF000F',fontWeight:700,fontSize:12}}>{n.transport_id}</div>
                        <div style={{color:'#e2e8f0',fontWeight:600,fontSize:14,marginTop:2}}>{n.package_name}</div>
                        <div style={{color:'#475569',fontSize:11,marginTop:2}}>{n.source} → {n.target}</div>
                      </div>
                      <div style={{flex:1,minWidth:180}}>
                        <div style={{color:'#64748b',fontSize:12}}>{(n.iflows||[]).length} iFlows</div>
                        <div style={{color:'#475569',fontSize:11}}>by {n.requested_by||'user'} · {new Date(n.created_at).toLocaleString()}</div>
                      </div>
                      <div style={{display:'flex',flexDirection:'column',gap:4,flexShrink:0}}>
                        {statusBadge(n.status)}
                        {n.approved_by&&<span style={{fontSize:11,color:'#22c55e'}}>by {n.approved_by} · {new Date(n.approved_at).toLocaleString()}</span>}
                        {n.rejected_by&&<span style={{fontSize:11,color:'#ef4444'}}>by {n.rejected_by}{n.reject_reason&&` · "${n.reject_reason}"`}</span>}
                      </div>
                      {n.job_id&&(
                        <button onClick={()=>openJobLogs(n.job_id)}
                          style={{padding:'6px 14px',background:'rgba(99,102,241,0.1)',
                                  border:'1px solid rgba(99,102,241,0.3)',borderRadius:8,
                                  color:'#a5b4fc',cursor:'pointer',fontSize:12,fontWeight:600,flexShrink:0}}>
                          📋 View Logs
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ── TRANSPORT LOGS ── */}
        {section==='logs'&&(
          <div>
            <div style={{fontSize:13,color:'#475569',marginBottom:16}}>
              All transport job logs · auto-expire after 60 days
            </div>
            {allJobs.length===0?(
              <div style={{textAlign:'center',padding:'60px',color:'#334155'}}>
                <div style={{fontSize:40,marginBottom:10}}>📋</div>
                <div style={{color:'#475569',fontWeight:700}}>No transport jobs yet</div>
              </div>
            ):(
              <div style={{display:'flex',flexDirection:'column',gap:8}}>
                {allJobs.map(j=>{
                  const sColor={complete:'#22c55e',error:'#ef4444',running:'#3b82f6',queued:'#8b5cf6'}[j.status]||'#64748b';
                  const expDays=j.days_until_expiry;
                  return(
                    <div key={j.id||j.job_id} style={{background:'#1e293b',border:'1px solid #334155',
                                                       borderRadius:12,padding:'14px 20px',
                                                       display:'flex',alignItems:'center',
                                                       gap:14,flexWrap:'wrap'}}>
                      <div style={{flexShrink:0,minWidth:160}}>
                        <div style={{fontFamily:'monospace',color:'#FF000F',fontWeight:700,fontSize:13}}>{j.transport_id||j.id?.slice(0,8)}</div>
                        <div style={{color:'#94a3b8',fontSize:12,marginTop:2}}>{j.source} → <b style={{color:'#FF000F'}}>{j.target}</b></div>
                        <div style={{color:'#475569',fontSize:11,marginTop:1}}>{(j.package_ids||[]).join(', ')}</div>
                      </div>
                      <div style={{flex:1}}>
                        <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:4}}>
                          <span style={{background:`${sColor}22`,border:`1px solid ${sColor}55`,
                                         borderRadius:20,padding:'2px 10px',color:sColor,
                                         fontSize:11,fontWeight:700}}>{j.status?.toUpperCase()}</span>
                          <span style={{fontSize:11,color:'#475569'}}>{j.created_at&&new Date(j.created_at).toLocaleString()}</span>
                        </div>
                        <div style={{height:6,background:'#334155',borderRadius:3,overflow:'hidden',maxWidth:200}}>
                          <div style={{height:6,width:`${j.progress||0}%`,
                                       background:j.progress===100?'#22c55e':'#FF000F',borderRadius:3}}/>
                        </div>
                      </div>
                      <div style={{display:'flex',flexDirection:'column',gap:6,flexShrink:0,alignItems:'flex-end'}}>
                        <div style={{fontSize:11,color:expDays<7?'#f59e0b':'#475569'}}>
                          {j.archived?'📦 Archived':`⏱ Expires in ${expDays}d`}
                        </div>
                        <div style={{display:'flex',gap:6}}>
                          <button onClick={()=>openJobLogs(j.id||j.job_id)}
                            style={{padding:'5px 12px',background:'rgba(99,102,241,0.1)',
                                    border:'1px solid rgba(99,102,241,0.3)',borderRadius:8,
                                    color:'#a5b4fc',cursor:'pointer',fontSize:12,fontWeight:600}}>
                            👁 View
                          </button>
                          <button onClick={()=>downloadLog(j.id||j.job_id)}
                            style={{padding:'5px 12px',background:'rgba(255,0,15,0.1)',
                                    border:'1px solid rgba(255,0,15,0.3)',borderRadius:8,
                                    color:'#ff9999',cursor:'pointer',fontSize:12,fontWeight:600}}>
                            ⬇ Download
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
};

// ── APPROVAL WAITING MODAL — Admin Portal Version ──────────────────────────
const ApprovalWaitModal = ({ token, onCancel, pendingInfo }) => {
  const [elapsed, setElapsed] = React.useState(0);
  React.useEffect(() => {
    const t = setInterval(() => setElapsed(e => e + 5), 5000);
    return () => clearInterval(t);
  }, []);
  return (
    <div style={{position:"fixed",top:0,left:0,right:0,bottom:0,background:"rgba(0,0,0,0.85)",
                 display:"flex",alignItems:"center",justifyContent:"center",zIndex:9999}}>
      <div style={{background:"#1a1a2e",border:"1px solid #FF000F",borderRadius:16,padding:40,
                   textAlign:"center",maxWidth:460,width:"90%"}}>
        <div style={{fontSize:52,marginBottom:12}}>🔐</div>
        <h2 style={{color:"white",marginBottom:6,fontSize:20}}>Awaiting Admin Approval</h2>
        <p style={{color:"#aab4be",marginBottom:16,fontSize:13,lineHeight:1.6}}>
          Your PRODUCTION transport request has been sent to the<br/>
          <strong style={{color:"#FF000F"}}>Admin Portal</strong>. An admin must approve it to continue.
        </p>
        <div style={{background:"rgba(255,193,7,0.08)",border:"1px solid rgba(255,193,7,0.4)",
                     borderRadius:10,padding:"10px 16px",marginBottom:16}}>
          <p style={{color:"#ffc107",margin:0,fontSize:12,display:"flex",alignItems:"center",
                     justifyContent:"center",gap:6}}>
            <span className="animate-pulse">⏳</span>
            Checking every 5 seconds… ({Math.floor(elapsed/60)}m {elapsed%60}s elapsed)
          </p>
        </div>
        {pendingInfo&&(
          <div style={{background:"rgba(255,255,255,0.04)",borderRadius:8,padding:"10px 14px",
                       marginBottom:16,textAlign:"left",fontSize:12}}>
            <div style={{color:"#64748b",marginBottom:4,fontSize:11,fontWeight:700,textTransform:"uppercase",letterSpacing:1}}>Request Details</div>
            <div style={{color:"#94a3b8"}}><b style={{color:"#e2e8f0"}}>ID:</b> {pendingInfo.transport_id}</div>
            <div style={{color:"#94a3b8"}}><b style={{color:"#e2e8f0"}}>Package:</b> {pendingInfo.package_name}</div>
            <div style={{color:"#94a3b8"}}><b style={{color:"#e2e8f0"}}>Target:</b> <span style={{color:"#FF000F",fontWeight:700}}>{pendingInfo.target} 🎯</span></div>
            <div style={{color:"#94a3b8"}}><b style={{color:"#e2e8f0"}}>iFlows:</b> {(pendingInfo.iflows||[]).length} selected</div>
            <div style={{color:"#f59e0b",marginTop:6,fontSize:11}}>
              ⚠ Expires in 3 days if not approved
            </div>
          </div>
        )}
        <div style={{display:"flex",gap:8,justifyContent:"center",flexWrap:"wrap",marginBottom:16}}>
          <div style={{background:"rgba(255,0,15,0.1)",border:"1px solid rgba(255,0,15,0.3)",
                       borderRadius:8,padding:"6px 14px",color:"#ff9999",fontSize:11}}>
            🔐 Admin Portal → Pending Approvals
          </div>
        </div>
        <button onClick={onCancel}
          style={{background:"transparent",border:"1px solid #475569",color:"#94a3b8",
                  padding:"8px 24px",borderRadius:8,cursor:"pointer",fontSize:13}}>
          Cancel Request
        </button>
      </div>
    </div>
  );
};

// ── SecurityPanel Component ──────────────────────────────────────
function SecurityPanel({ adminToken, setAdminToken }) {
  const [newPw,      setNewPw]      = useState("");
  const [newPin,     setNewPin]     = useState("");
  const [showPw,     setShowPw]     = useState(false);
  const [showPin,    setShowPin]    = useState(false);
  const [showCurPin, setShowCurPin] = useState(false);
  const [pwMsg,      setPwMsg]      = useState("");
  const [pinMsg,     setPinMsg]     = useState("");
  const [creds,      setCreds]      = useState(null);

  useEffect(()=>{
    if(!adminToken) return;
    fetch(`${API}/admin/credentials`,{headers:{"Authorization":`Bearer ${adminToken}`}})
      .then(r=>r.json()).then(setCreds).catch(()=>{});
  },[adminToken]);

  const changePassword = async()=>{
    if(!newPw||newPw.length<4){setPwMsg("❌ Min 4 characters");return;}
    const r = await fetch(`${API}/admin/change-password`,{
      method:"POST",
      headers:{"Content-Type":"application/json","Authorization":`Bearer ${adminToken}`},
      body:JSON.stringify({new_password:newPw})
    }).then(r=>r.json()).catch(e=>({error:e.message}));
    if(r.message){
      setPwMsg("✅ "+r.message);
      const lr = await fetch(`${API}/admin/login`,{
        method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({username:"admin",password:newPw})
      }).then(r=>r.json()).catch(()=>({}));
      if(lr.token){sessionStorage.setItem("cpi_admin_token",lr.token);setAdminToken(lr.token);}
      setNewPw("");
    } else { setPwMsg("❌ "+(r.detail||r.error||"Failed")); }
  };

  const changePin = async()=>{
    if(!newPin||newPin.length<4){setPinMsg("❌ Min 4 chars");return;}
    const r = await fetch(`${API}/admin/change-pin`,{
      method:"POST",
      headers:{"Content-Type":"application/json","Authorization":`Bearer ${adminToken}`},
      body:JSON.stringify({new_pin:newPin})
    }).then(r=>r.json()).catch(e=>({error:e.message}));
    if(r.message){setPinMsg("✅ "+r.message);setCreds(c=>c?{...c,approval_pin:newPin}:c);setNewPin("");}
    else{setPinMsg("❌ "+(r.detail||r.error||"Failed"));}
  };

  const IS={width:"100%",padding:"10px 14px",background:"#0f172a",border:"1px solid #334155",
    borderRadius:10,color:"white",fontSize:13,outline:"none",boxSizing:"border-box"};
  const BS=(col)=>({padding:"10px 20px",background:`${col}22`,border:`1px solid ${col}55`,
    borderRadius:10,color:col,cursor:"pointer",fontWeight:700,fontSize:13,whiteSpace:"nowrap"});

  return (
    <div>
      <h3 style={{color:"white",fontWeight:900,fontSize:18,marginBottom:20}}>🔐 Security Settings</h3>

      {/* Current Credentials */}
      <div style={{background:"#1e293b",border:"1px solid #334155",borderRadius:14,padding:20,marginBottom:20}}>
        <div style={{color:"#94a3b8",fontWeight:700,fontSize:12,marginBottom:14,textTransform:"uppercase",letterSpacing:1}}>🔑 Current Credentials</div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
          <div style={{background:"#0f172a",borderRadius:10,padding:14}}>
            <div style={{color:"#475569",fontSize:11,marginBottom:4}}>ADMIN USERNAME</div>
            <div style={{color:"white",fontWeight:700,fontFamily:"monospace"}}>admin</div>
          </div>
          <div style={{background:"#0f172a",borderRadius:10,padding:14}}>
            <div style={{color:"#475569",fontSize:11,marginBottom:4}}>DEFAULT PASSWORD</div>
            <div style={{color:"#7dd3fc",fontWeight:700,fontFamily:"monospace"}}>ABB@2026</div>
          </div>
          <div style={{background:"#0f172a",borderRadius:10,padding:14,gridColumn:"1/-1"}}>
            <div style={{color:"#475569",fontSize:11,marginBottom:4}}>APPROVAL PORTAL PIN</div>
            <div style={{display:"flex",alignItems:"center",gap:8}}>
              <span style={{color:"#FF000F",fontWeight:900,fontSize:18,fontFamily:"monospace",letterSpacing:4}}>
                {showCurPin?(creds?.approval_pin||"cpi1234"):"● ● ● ● ● ●"}
              </span>
              <button onClick={()=>setShowCurPin(!showCurPin)}
                style={{background:"none",border:"none",color:"#64748b",cursor:"pointer",fontSize:14}}>
                {showCurPin?"🙈 Hide":"👁 Show"}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Change Password */}
      <div style={{background:"#1e293b",border:"1px solid #334155",borderRadius:14,padding:20,marginBottom:16}}>
        <div style={{color:"#94a3b8",fontWeight:700,fontSize:12,marginBottom:14,textTransform:"uppercase",letterSpacing:1}}>🔒 Change Admin Password</div>
        <div style={{display:"flex",gap:10,alignItems:"center"}}>
          <div style={{position:"relative",flex:1}}>
            <input type={showPw?"text":"password"} value={newPw} onChange={e=>setNewPw(e.target.value)}
              placeholder="New password (min 4 chars)" style={IS}/>
            <button onClick={()=>setShowPw(!showPw)} style={{position:"absolute",right:10,top:"50%",
              transform:"translateY(-50%)",background:"none",border:"none",color:"#64748b",cursor:"pointer"}}>
              {showPw?"🙈":"👁"}
            </button>
          </div>
          <button onClick={changePassword} style={BS("#22c55e")}>✔ Update</button>
        </div>
        {pwMsg&&<div style={{marginTop:8,fontSize:12,color:pwMsg.startsWith("✅")?"#22c55e":"#ef4444"}}>{pwMsg}</div>}
      </div>

      {/* Change Approval PIN */}
      <div style={{background:"#1e293b",border:"1px solid #334155",borderRadius:14,padding:20}}>
        <div style={{color:"#94a3b8",fontWeight:700,fontSize:12,marginBottom:14,textTransform:"uppercase",letterSpacing:1}}>🔔 Change Approval Portal PIN</div>
        <div style={{display:"flex",gap:10,alignItems:"center"}}>
          <div style={{position:"relative",flex:1}}>
            <input type={showPin?"text":"password"} value={newPin} onChange={e=>setNewPin(e.target.value)}
              placeholder="New PIN (min 4 chars)" style={IS}/>
            <button onClick={()=>setShowPin(!showPin)} style={{position:"absolute",right:10,top:"50%",
              transform:"translateY(-50%)",background:"none",border:"none",color:"#64748b",cursor:"pointer"}}>
              {showPin?"🙈":"👁"}
            </button>
          </div>
          <button onClick={changePin} style={BS("#FF000F")}>✔ Update</button>
        </div>
        {pinMsg&&<div style={{marginTop:8,fontSize:12,color:pinMsg.startsWith("✅")?"#22c55e":"#ef4444"}}>{pinMsg}</div>}
      </div>
    </div>
  );
}


export default function App() {
  const [tenants,setTenants]=useState([]);
  const [src,setSrc]=useState(null);
  const [tgt,setTgt]=useState(null);
  const [tStatus,setTStatus]=useState({});
  const [packages,setPackages]=useState([]);
  const [loadingPkgs,setLoadingPkgs]=useState(false);
  const [artifacts,setArtifacts]=useState({});
  const [selPkgs,setSelPkgs]=useState([]);
  const [selArts,setSelArts]=useState({});
  const [step,setStep]=useState(1);
  const [scans,setScans]=useState([]);
  const [scanDone,setScanDone]=useState(false);
  const [approved,setApproved]=useState(false);
  const [opts,setOpts]=useState({conflict_resolution:"overwrite",deploy_after:false,dry_run:false,validate_checksum:true,auto_rollback:true});
  const [jobId,setJobId]=useState(null);
  const [transportId,setTransportId]=useState(null);
  const [logs,setLogs]=useState([]);
  const [prog,setProg]=useState(0);
  const [jStatus,setJStatus]=useState("idle");
  const [jobs,setJobs]=useState([]);
  const [tab,setTab]=useState("transport");
  const [showAdd,setShowAdd]=useState(false);
  const [deleteKey,setDeleteKey]=useState(null);

  // ── Approval States ──────────────────────────────────────────
  const [approvalToken,setApprovalToken]=useState(null);
  const [approvalStatus,setApprovalStatus]=useState(null);
  const [showApprovalWait,setShowApprovalWait]=useState(false);


  // ── Admin Portal State ────────────────────────────────────────
  const [adminToken, setAdminToken]             = useState(() => sessionStorage.getItem('cpi_admin_token'));
  const [adminInfo,  setAdminInfo]              = useState(null);
  const [adminSection, setAdminSection]         = useState('pending');
  const [allNotifs,  setAllNotifs]              = useState([]);
  const [adminUsers, setAdminUsers]             = useState([]);
  const [adminStats, setAdminStats]             = useState({pending:0,approved:0,rejected:0,archived:0,total_jobs:0});
  const [pendingCount, setPendingCount]         = useState(0);
  const [adminLoginCreds, setAdminLoginCreds]   = useState({username:'',password:''});
  const [adminLoginErr,   setAdminLoginErr]     = useState('');
  const [adminBusy,       setAdminBusy]         = useState(false);
  const [newUser,         setNewUser]           = useState({username:'',password:'',role:'viewer',email:''});
  // ── Forgot / Change Password (Admin) ──
  const [showAdminForgot, setShowAdminForgot]   = useState(false);
  const [showAdminChPw,   setShowAdminChPw]     = useState(false);
  const [adminForgotUser, setAdminForgotUser]   = useState('');
  const [adminForgotTok,  setAdminForgotTok]    = useState('');
  const [adminNewPw,      setAdminNewPw]        = useState('');
  const [adminConfPw,     setAdminConfPw]       = useState('');
  const [adminPwStep,     setAdminPwStep]       = useState(1);
  const [adminPwMsg,      setAdminPwMsg]        = useState({text:'',type:''});
  const [credHint,        setCredHint]          = useState(null);
  // ── Change Password (logged-in) ──
  const [adminCurPw,      setAdminCurPw]        = useState('');
  const [rejectReason,    setRejectReason]      = useState('');
  const [rejectTarget,    setRejectTarget]      = useState(null);
  const [pendingInfo,     setPendingInfo]       = useState(null); // for ApprovalWaitModal
  const [notifJobId,      setNotifJobId]        = useState(null);

  const wsRef=useRef(null);
  const logRef=useRef(null);

  const authH=(tok)=>tok?{"Authorization":`Bearer ${tok}`}:{};
  const refreshTenants=()=>fetch(`${API}/tenants`,{headers:authH(adminToken)}).then(r=>r.json()).then(d=>setTenants(Array.isArray(d)?d:(d.tenants||[]))).catch(()=>{});
  // Fetch masked credential hint for login screen
  useEffect(()=>{
    fetch(`${API}/admin/credentials-hint`).then(r=>r.json()).then(d=>setCredHint(d)).catch(()=>{});
  },[]);

  // ── Auto-login on startup to get admin token for tenant management ──
  useEffect(()=>{
    const autoLogin = async () => {
      if(adminToken) { refreshTenants(); return; }
      try {
        const r = await fetch(`${API}/admin/login`,{
          method:'POST',
          headers:{'Content-Type':'application/json'},
          body:JSON.stringify({username:'admin',password:'ABB@2026'})
        }).then(r=>r.json());
        if(r.token){
          sessionStorage.setItem('cpi_admin_token', r.token);
          setAdminToken(r.token);
        }
      } catch(e){}
    };
    autoLogin();
  },[]);

  useEffect(()=>{
    if(adminToken !== null) {
      refreshTenants();
      fetch(`${API}/jobs`,{headers:authH(adminToken)}).then(r=>r.json()).then(d=>setJobs(Array.isArray(d)?d:(d.jobs||[]))).catch(()=>{});
    }
  },[adminToken]);

  // ── Real-time job polling every 3s ──────────────────────────
  useEffect(()=>{
    const poll = setInterval(()=>{
      if(!adminToken) return;
      fetch(`${API}/jobs`,{headers:authH(adminToken)}).then(r=>r.json())
        .then(d=>setJobs(Array.isArray(d)?d:(d.jobs||[]))).catch(()=>{});
    }, 3000);
    return ()=>clearInterval(poll);
  },[adminToken]);
  useEffect(()=>{if(logRef.current)logRef.current.scrollTop=logRef.current.scrollHeight;},[logs]);

  // ── Poll Approval Status Every 5s ────────────────────────────
  useEffect(()=>{
    if(!approvalToken) return;
    const interval=setInterval(async()=>{
      try{
        const res=await fetch(`${API}/approval-status/${approvalToken}`);
        const data=await res.json();
        setApprovalStatus(data.status);
        if(data.status==="APPROVED"){
          clearInterval(interval);
          setShowApprovalWait(false);
          if(data.job_id){
            // Admin already started the transport job — connect to it
            setJobId(data.job_id); setLogs([]); setProg(0); setJStatus("running"); setStep(5);
            connectWS(data.job_id);
          } else {
            // Start transport from frontend
            startTransport();
          }
        }
        if(data.status==="REJECTED"){
          clearInterval(interval);
          setShowApprovalWait(false);
          alert(`❌ Transport REJECTED by admin.${data.reject_reason?'\nReason: '+data.reject_reason:''}`);
        }
        if(data.status==="ARCHIVED"){
          clearInterval(interval);
          setShowApprovalWait(false);
          alert("⏰ Approval request expired (3-day limit). Please submit again.");
        }
      }catch(e){ console.error("Polling error:",e); }
    },5000);
    return()=>clearInterval(interval);
  },[approvalToken]);

  const validate=async(key)=>{
    setTStatus(s=>({...s,[key]:"loading"}));
    try{const r=await fetch(`${API}/tenants/${key}/validate`).then(r=>r.json());setTStatus(s=>({...s,[key]:r.status}));}
    catch{setTStatus(s=>({...s,[key]:"failed"}));}
  };

  const handleDrop=async(side,key)=>{
    if(side==="src"){setSrc(key);fetchPkgs(key);}else{setTgt(key);}
    if(!tStatus[key])validate(key);
  };
  const handleClick=(key)=>{
    if(!src){setSrc(key);fetchPkgs(key);validate(key);}
    else if(!tgt){setTgt(key);validate(key);}
  };

  const fetchPkgs=async(key)=>{
    if(!key) return;
    setLoadingPkgs(true);
    setPackages([]);
    try{
      const p=await fetch(`${API}/tenants/${key}/packages`).then(r=>r.json());
      const list=Array.isArray(p)?p:(p.packages||p.results||[]);
      setPackages(list);
    }catch(e){ console.error("fetchPkgs error:",e); setPackages([]); }
    setLoadingPkgs(false);
  };

  const fetchArts=async(key,pkgId,force=false)=>{
    if(artifacts[pkgId]!==undefined&&!force)return;
    setArtifacts(x=>({...x,[pkgId]:null}));
    try{
      const a=await fetch(`${API}/tenants/${key}/packages/${pkgId}/artifacts`).then(r=>r.json());
      const list=Array.isArray(a)?a:(a.artifacts||a.results||[]);
      setArtifacts(x=>({...x,[pkgId]:list}));
      if(list.length>0) setSelArts(s=>({...s,[pkgId]:list.map(art=>art.Id||art.id)}));
    }catch(e){ setArtifacts(x=>({...x,[pkgId]:[]})); }
  };
  const togPkg=(id)=>{
    const willSel=!selPkgs.includes(id);
    setSelPkgs(s=>willSel?[...s,id]:s.filter(x=>x!==id));
    if(willSel&&src) fetchArts(src,id,true);
    else if(!willSel){ setSelArts(s=>{const n={...s};delete n[id];return n;}); }
  };
  const togArt=(pkgId,artId)=>{setSelArts(s=>{const c=s[pkgId]||[];return{...s,[pkgId]:c.includes(artId)?c.filter(x=>x!==artId):[...c,artId]};});};
  const togAllArts=(pkgId)=>{const all=(artifacts[pkgId]||[]).map(a=>a.Id||a.id);setSelArts(s=>({...s,[pkgId]:(s[pkgId]||[]).length===all.length?[]:all}));};
  const selectAllPkgs=()=>{const ids=packages.map(p=>p.Id||p.id);setSelPkgs(ids);ids.forEach(id=>{if(src)fetchArts(src,id,true);});};
  const clearAll=()=>{setSelPkgs([]);setSelArts({});};
  const artTypeIcon=(type)=>{const t=(type||"").toLowerCase();if(t.includes("iflow")||t.includes("integration"))return"⚡";if(t.includes("value")||t.includes("mapping"))return"🗂";if(t.includes("script"))return"📜";if(t.includes("function"))return"🔧";if(t.includes("api"))return"🔌";return"📄";};
  const runScan=async()=>{
    setScanDone(false);setApproved(false);
    const checks=[
      {id:"creds",   label:"OAuth2 Credential Validation",   detail:"Verifying tokens for both tenants"},
      {id:"conn",    label:"Connectivity & Latency Check",   detail:"Testing HTTPS endpoints"},
      {id:"perms",   label:"Permission & Role Audit",        detail:"Checking transport authorization"},
      {id:"ssl",     label:"SSL/TLS Certificate Validation", detail:"Verifying certificate chain"},
      {id:"pkg",     label:"Package Integrity Scan",         detail:"Scanning selected packages"},
      {id:"dup",     label:"Duplicate Detection",            detail:"Checking artifacts on target"},
      {id:"size",    label:"Payload Size Estimation",        detail:"Calculating transport size"},
      {id:"version", label:"API Version Compatibility",      detail:"Verifying CPI API version"},
    ];
    setScans(checks.map(c=>({...c,status:"pending"})));
    await sleep(300);
    const details={
      creds:"OAuth2 tokens valid — both tenants authenticated",
      conn:"Latency 38ms — all endpoints reachable",
      perms:"Read + Write + Deploy permissions confirmed",
      ssl:"TLS 1.3 — certificates valid",
      pkg:`No anomalies in ${selPkgs.length} package(s)`,
      dup:`${Object.values(selArts).flat().length} artifacts to verify`,
      size:`Est. payload ~${(selPkgs.length*0.4).toFixed(1)} MB`,
      version:"Management API v1 — Compatible",
    };
    for(let i=0;i<checks.length;i++){
      setScans(s=>s.map((c,j)=>j===i?{...c,status:"scanning"}:c));
      await sleep(500+Math.random()*400);
      setScans(s=>s.map((c,j)=>j===i?{...c,status:"pass",detail:details[c.id]}:c));
      await sleep(100);
    }
    setScanDone(true);
  };

  const connectWS = (job_id) => {
    const ws = new WebSocket(`${WS}/${job_id}`);
    wsRef.current = ws;
    ws.onopen = () => setLogs(x=>[...x,{status:"info",timestamp:new Date().toISOString(),progress:0,message:"🔌 Connected to transport engine…"}]);
    ws.onmessage = (e) => {
      try{
        const msg = JSON.parse(e.data);
        if(msg.type==="ping") return;
        if(msg.type==="log" && msg.entry){
          const lvl=(msg.entry.level||"INFO").toLowerCase();
          setLogs(x=>[...x,{
            status: lvl==="warn"?"warning":lvl==="error"?"error":"info",
            timestamp: msg.entry.ts,
            progress:  msg.progress||0,
            message:   msg.entry.msg||""
          }]);
          if(msg.progress!==undefined) setProg(Math.min(100,msg.progress));
        }
        if(msg.type==="status" && msg.progress!==undefined) setProg(Math.min(100,msg.progress));
        if(msg.type==="complete"||msg.status==="complete"){
          setProg(100); setJStatus("complete");
          setLogs(x=>[...x,{status:"complete",timestamp:new Date().toISOString(),progress:100,message:"🎉 Transport completed successfully!"}]);
        }
        if(msg.type==="error"||msg.status==="error"){
          setJStatus("error");
          setLogs(x=>[...x,{status:"error",timestamp:new Date().toISOString(),progress:0,message:"❌ "+(msg.error||"Transport failed")}]);
        }
      }catch(err){ console.error("WS parse:",err); }
    };
    ws.onclose = () => {
      // Only fetch final state if job didn't complete via WS
      setTimeout(async()=>{
        const j=await fetch(`${API}/jobs/${job_id}`,{headers:authH(adminToken)}).then(r=>r.json()).catch(()=>null);
        if(!j) return;
        setProg(j.progress||0);
        if(j.status==="complete"){setJStatus("complete");setProg(100);}
        if(j.status==="error") setJStatus("error");
        // Only replace logs if WS delivered none
        setLogs(prev=>{
          if(prev.length<=1 && j.logs&&j.logs.length>0){
            return j.logs.map(e=>({
              status:(e.level||"").toLowerCase()==="error"?"error":(e.level||"").toLowerCase()==="warn"?"warning":"info",
              timestamp:e.ts, progress:j.progress||0, message:e.msg
            }));
          }
          return prev;
        });
      },800);
    };
    ws.onerror = () => {
      const poll=setInterval(async()=>{
        const j=await fetch(`${API}/jobs/${job_id}`,{headers:authH(adminToken)}).then(r=>r.json()).catch(()=>null);
        if(!j) return;
        if(j.logs&&j.logs.length>0) setLogs(j.logs.map(e=>({status:(e.level||'INFO').toLowerCase()==='error'?'error':(e.level||'').toLowerCase()==='warn'?'warning':'info',timestamp:e.ts,progress:j.progress||0,message:e.msg})));
        setProg(j.progress||0);
        if(j.status==="complete"){setJStatus("complete");setProg(100);clearInterval(poll);}
        if(j.status==="error"){setJStatus("error");clearInterval(poll);}
      },2000);
      setTimeout(()=>clearInterval(poll),300000);
    };
  };

  const startTransport=async()=>{
    const allArts=Object.values(selArts).flat();
    try{
      const resp=await fetch(`${API}/transport/start`,{
        method:"POST",
        headers:{"Content-Type":"application/json","Authorization":`Bearer ${adminToken}`},
        body:JSON.stringify({
          source_tenant: src,
          target_tenant: tgt,
          package_ids:   selPkgs,
          iflow_ids:     allArts.length>0 ? allArts : null,
          requested_by:  "admin",
          conflict_resolution: opts.conflict_resolution||"overwrite",
          deploy_after:  opts.deploy_after||false,
          dry_run:       opts.dry_run||false,
          validate_checksum: opts.validate_checksum!==false,
          auto_rollback:     opts.auto_rollback!==false,
        })
      }).then(r=>r.json());
      const job_id = resp.job_id || resp.id;
      const tr_id  = resp.transport_id || job_id;
      if(!job_id){ alert("Transport failed: "+(resp.detail||resp.message||JSON.stringify(resp))); return; }
      setJobId(job_id); setTransportId(tr_id); setLogs([]); setProg(0); setJStatus("running"); setStep(5);
      connectWS(job_id);
    }catch(err){ alert("Transport Error: "+err.message); }
  }

  // ── Handle Deploy with PROD Approval ────────────────────────

  // ── Admin: helpers ────────────────────────────────────────────
  const AHDR = () => ({Authorization:`Bearer ${adminToken}`,'Content-Type':'application/json'});

  // ── Forgot Password Step 1: get reset token ──────────────────
  const doAdminForgot1 = async () => {
    if(!adminForgotUser){setAdminPwMsg({text:'Enter your username',type:'error'});return;}
    setAdminPwMsg({text:'',type:''});
    try{
      const r = await fetch(`${API}/admin/forgot-password`,{
        method:'POST', headers:{'Content-Type':'application/json'},
        body:JSON.stringify({username:adminForgotUser})
      }).then(r=>r.json());
      if(r.reset_token){ setAdminForgotTok(r.reset_token); setAdminPwStep(2);
        setAdminPwMsg({text:`Reset token generated (expires 15 min)`,type:'success'}); }
      else setAdminPwMsg({text:r.message||r.detail||'Failed',type:'error'});
    }catch(e){ setAdminPwMsg({text:'Connection error',type:'error'}); }
  };

  // ── Forgot Password Step 2: reset with token ─────────────────
  const doAdminForgot2 = async () => {
    if(adminNewPw!==adminConfPw){setAdminPwMsg({text:'Passwords do not match',type:'error'});return;}
    if(adminNewPw.length<6){setAdminPwMsg({text:'Minimum 6 characters',type:'error'});return;}
    try{
      const r = await fetch(`${API}/admin/reset-password`,{
        method:'POST', headers:{'Content-Type':'application/json'},
        body:JSON.stringify({reset_token:adminForgotTok, new_password:adminNewPw, confirm_password:adminConfPw})
      }).then(r=>r.json());
      if(r.message&&!r.detail){
        setAdminPwMsg({text:'✅ Password reset! Please sign in.',type:'success'});
        setTimeout(()=>{setShowAdminForgot(false);setAdminPwStep(1);setAdminForgotUser('');
          setAdminForgotTok('');setAdminNewPw('');setAdminConfPw('');},2000);
      } else setAdminPwMsg({text:r.detail||'Failed',type:'error'});
    }catch(e){ setAdminPwMsg({text:'Connection error',type:'error'}); }
  };

  // ── Change Password (logged-in admin) ─────────────────────────
  const doAdminChangePw = async () => {
    if(adminNewPw!==adminConfPw){setAdminPwMsg({text:'Passwords do not match',type:'error'});return;}
    if(adminNewPw.length<6){setAdminPwMsg({text:'Minimum 6 characters',type:'error'});return;}
    try{
      const r = await fetch(`${API}/admin/change-password`,{
        method:'POST', headers:{...AHDR()},
        body:JSON.stringify({current_password:adminCurPw, new_password:adminNewPw, confirm_password:adminConfPw})
      }).then(r=>r.json());
      if(r.message&&!r.detail){
        setAdminPwMsg({text:'✅ '+r.message,type:'success'});
        setTimeout(()=>{ setShowAdminChPw(false); adminLogout(); },1800);
      } else setAdminPwMsg({text:r.detail||'Failed',type:'error'});
    }catch(e){ setAdminPwMsg({text:'Connection error',type:'error'}); }
  };
  const adminFetch = async (path, opts={}) => {
    const r = await fetch(`${API}${path}`,{...opts,headers:{...AHDR(),...(opts.headers||{})}});
    if(r.status===401){adminLogout();return null;}
    return r.ok ? r.json() : null;
  };

  // ── Fetch credentials hint on mount ──
  useEffect(()=>{
    fetch(`${API}/admin/credentials-hint`)
      .then(r=>r.json()).then(d=>setCredHint(d)).catch(()=>{});
  },[]);

  // ── Change password ──
  const doChangePw = async()=>{
    setPwMsg({text:"",type:""});
    if(pwForm.new_!==pwForm.confirm){setPwMsg({text:"New passwords do not match",type:"error"});return;}
    if(pwForm.new_.length<6){setPwMsg({text:"Min 6 characters required",type:"error"});return;}
    try{
      const r=await fetch(`${API}/admin/change-password`,{
        method:"POST",headers:{"Content-Type":"application/json","Authorization":`Bearer ${adminToken}`},
        body:JSON.stringify({current_password:pwForm.current,new_password:pwForm.new_,confirm_password:pwForm.confirm})
      }).then(r=>r.json());
      if(r.detail){setPwMsg({text:r.detail,type:"error"});}
      else{setPwMsg({text:"✅ "+r.message,type:"success"});setPwForm({current:"",new_:"",confirm:""});
        setTimeout(()=>{setShowChangePw(false);adminLogout();},2000);}
    }catch(e){setPwMsg({text:"Error: "+e.message,type:"error"});}
  };

  // ── Forgot password step 1: get reset token ──
  const doForgotStep1 = async()=>{
    setPwMsg({text:"",type:""});
    if(!forgotUser){setPwMsg({text:"Enter username",type:"error"});return;}
    try{
      const r=await fetch(`${API}/admin/forgot-password`,{
        method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({username:forgotUser})
      }).then(r=>r.json());
      setPwMsg({text:r.message,type:"info"});
      if(r.reset_token){setForgotToken(r.reset_token);setResetStep(2);}
    }catch(e){setPwMsg({text:"Error: "+e.message,type:"error"});}
  };

  // ── Forgot password step 2: reset with token ──
  const doForgotStep2 = async()=>{
    setPwMsg({text:"",type:""});
    if(forgotNewPw!==forgotConfirm){setPwMsg({text:"Passwords do not match",type:"error"});return;}
    try{
      const r=await fetch(`${API}/admin/reset-password`,{
        method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({reset_token:forgotToken,new_password:forgotNewPw,confirm_password:forgotConfirm})
      }).then(r=>r.json());
      if(r.detail){setPwMsg({text:r.detail,type:"error"});}
      else{setPwMsg({text:"✅ "+r.message,type:"success"});
        setTimeout(()=>{setShowForgotPw(false);setResetStep(1);setForgotUser("");setForgotToken("");setForgotNewPw("");setForgotConfirm("");},2000);}
    }catch(e){setPwMsg({text:"Error: "+e.message,type:"error"});}
  };

  // ── Change PIN ──
  const doChangePin = async()=>{
    setPinMsg({text:"",type:""});
    if(pinForm.new_!==pinForm.confirm){setPinMsg({text:"New PINs do not match",type:"error"});return;}
    if(pinForm.new_.length<4){setPinMsg({text:"Min 4 characters required",type:"error"});return;}
    try{
      const r=await fetch(`${API}/approval/change-pin`,{
        method:"POST",headers:{"Content-Type":"application/json","Authorization":`Bearer ${adminToken}`},
        body:JSON.stringify({current_pin:pinForm.current,new_pin:pinForm.new_,confirm_pin:pinForm.confirm})
      }).then(r=>r.json());
      if(r.detail){setPinMsg({text:r.detail,type:"error"});}
      else{setPinMsg({text:"✅ "+r.message,type:"success"});setPinForm({current:"",new_:"",confirm:""});
        setTimeout(()=>setShowChangePin(false),2000);}
    }catch(e){setPinMsg({text:"Error: "+e.message,type:"error"});}
  };

  const adminLogout = () => {
    sessionStorage.removeItem('cpi_admin_token');
    setAdminToken(null); setAdminInfo(null);
  };

  const loadAdminData = async () => {
    if(!adminToken) return;
    const [notifs, users, stats] = await Promise.all([
      adminFetch('/admin/notifications'),
      adminFetch('/admin/users'),
      adminFetch('/admin/stats'),
    ]);
    if(notifs) setAllNotifs(notifs);
    if(users)  setAdminUsers(users);
    if(stats){ setAdminStats(stats); setPendingCount(stats.pending||0); }
  };

  const loginAdmin = async () => {
    setAdminBusy(true); setAdminLoginErr('');
    try{
      const r = await fetch(`${API}/admin/login`,{
        method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify(adminLoginCreds)
      }).then(r=>r.json());
      if(r.token){
        sessionStorage.setItem('cpi_admin_token',r.token);
        setAdminToken(r.token);
        setAdminInfo({username:r.username,role:r.role});
        setAdminLoginErr('');
      } else {
        setAdminLoginErr(r.detail||'Invalid credentials');
      }
    }catch(e){ setAdminLoginErr('Connection error: '+e.message); }
    setAdminBusy(false);
  };

  const adminApprove = async (nid) => {
    setAdminBusy(true);
    const r = await adminFetch(`/admin/notifications/${nid}/approve`,{method:'POST',body:'{}'});
    if(r){ await loadAdminData(); }
    setAdminBusy(false);
  };

  const adminReject = async (nid, reason='') => {
    setAdminBusy(true);
    const r = await adminFetch(`/admin/notifications/${nid}/reject`,{
      method:'POST', body:JSON.stringify({reason})
    });
    if(r){ await loadAdminData(); setRejectTarget(null); setRejectReason(''); }
    setAdminBusy(false);
  };

  const adminAddUser = async () => {
    if(!newUser.username||!newUser.password){ alert('Username and password required'); return; }
    setAdminBusy(true);
    const r = await adminFetch('/admin/users',{method:'POST',body:JSON.stringify(newUser)});
    if(r&&r.success){ await loadAdminData(); setNewUser({username:'',password:'',role:'viewer',email:''}); }
    setAdminBusy(false);
  };

  const adminDeleteUser = async (username) => {
    if(!window.confirm(`Remove user "${username}"?`)) return;
    setAdminBusy(true);
    await adminFetch(`/admin/users/${username}`,{method:'DELETE'});
    await loadAdminData();
    setAdminBusy(false);
  };

  const adminChangeRole = async (username, role) => {
    setAdminBusy(true);
    await adminFetch(`/admin/users/${username}`,{method:'PUT',body:JSON.stringify({role})});
    await loadAdminData();
    setAdminBusy(false);
  };

  // Poll pending count every 60s (for bell badge — even when not on admin tab)
  useEffect(()=>{
    if(!adminToken) return;
    const poll = async () => {
      const r = await fetch(`${API}/admin/pending-count`).then(r=>r.json()).catch(()=>({pending:0}));
      setPendingCount(r.pending||0);
    };
    poll();
    const iv = setInterval(poll, 60000);
    return () => clearInterval(iv);
  },[adminToken]);

  // Load admin data when switching to admin tab
  useEffect(()=>{
    if(tab!=='admin'||!adminToken) return;
    loadAdminData();
    const iv = setInterval(loadAdminData, 30000);
    return () => clearInterval(iv);
  },[tab, adminToken]);

  // Verify existing admin token on mount
  useEffect(()=>{
    if(!adminToken) return;
    fetch(`${API}/admin/verify`,{headers:AHDR()})
      .then(r=>r.ok?r.json():null)
      .then(d=>{ if(d&&d.valid) setAdminInfo({username:d.username,role:d.role}); else adminLogout(); })
      .catch(()=>{});
  },[]);

  const [expanded,    setExpanded]    = useState({});
  const [viewJobModal,setViewJobModal]= useState(null);


  // ── Hash routing for standalone Approval Portal ──────────────
  const [routeHash, setRouteHash] = useState(window.location.hash);
  useEffect(()=>{
    const h=()=>setRouteHash(window.location.hash);
    window.addEventListener('hashchange',h);
    return()=>window.removeEventListener('hashchange',h);
  },[]);
  if(routeHash==='#/approval-portal') return <ApprovalPortalPage/>;


  const handleDeploy=async()=>{
    const isProd=(tgtT?.env||tgtT?.environment||"")==="Production"||(tgtT?.env||tgtT?.environment||"")==="production"||tgtT?.name?.toLowerCase().includes("prod");
    if(isProd){
      try{
        const transportId=`TRN-${Date.now().toString(36).toUpperCase()}`;
        const iflowList = Object.values(selArts).flat();
        // Build artifact_details from current selection
        const artDetails=[];
        for(const pkg of selPkgs){
          const pkgArts=(artifacts[pkg]||[]);
          for(const a of pkgArts){
            if(iflowList.includes(a.id)||iflowList.length===0)
              artDetails.push({id:a.id,name:a.name,package_id:pkg});
          }
        }
        const res=await fetch(`${API}/request-approval`,{
          method:"POST",headers:{"Content-Type":"application/json"},
          body:JSON.stringify({
            transport_id:     transportId,
            package_name:     selPkgs.join(", "),
            iflows:           iflowList,
            artifact_details: artDetails,
            source:           srcT?.name||src,
            target:           tgtT?.name||tgt,
            requested_by:     "sagar.reddy@in.abb.com",
          })
        });
        const data=await res.json();
        setApprovalToken(data.token);
        setPendingInfo({
          transport_id: transportId,
          package_name: selPkgs.join(", "),
          iflows:       iflowList,
          target:       tgtT?.name||tgt,
        });
        setShowApprovalWait(true);
      }catch(e){ alert("Failed to create approval: "+e.message); }
    }else{
      startTransport();
    }
  };


  const deleteTenant=async(key)=>{
    await fetch(`${API}/tenants/${key}`,{method:"DELETE"});
    setDeleteKey(null);refreshTenants();
    if(src===key)setSrc(null);if(tgt===key)setTgt(null);
  };

  const srcT=tenants.find(t=>t.key===src);
  const tgtT=tenants.find(t=>t.key===tgt);
  const allArtCount=Object.values(selArts).flat().length;
  const canNext1=src&&tgt&&src!==tgt;
  const isProdTarget=(tgtT?.env||tgtT?.environment||"")==="Production"||(tgtT?.env||tgtT?.environment||"")==="production"||tgtT?.name?.toLowerCase().includes("prod");



  return (
    <div className="min-h-screen" style={{background:BG_MAIN, color:TEXT_MAIN}}>
      {showAdd&&<AddTenantModal onClose={()=>setShowAdd(false)} onAdded={refreshTenants} adminToken={adminToken}/>}


      {/* JOB DETAIL MODAL */}
      {viewJobModal&&(
        <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.85)",display:"flex",
                     alignItems:"center",justifyContent:"center",zIndex:9990,padding:20}}>
          <div style={{background:"#1e293b",border:"1px solid #334155",borderRadius:16,
                       width:"100%",maxWidth:800,maxHeight:"88vh",display:"flex",flexDirection:"column"}}>
            <div style={{padding:"16px 22px",borderBottom:"1px solid #334155",
                         display:"flex",alignItems:"center",justifyContent:"space-between",flexShrink:0}}>
              <div>
                <div style={{fontWeight:900,color:"white",fontSize:16}}>
                  📋 {viewJobModal.transport_id||viewJobModal.id?.slice(0,8)}
                </div>
                <div style={{fontSize:12,color:"#64748b",marginTop:2}}>
                  {viewJobModal.source} → {viewJobModal.target} ·{" "}
                  {(viewJobModal.artifact_details||[]).length} artifacts ·{" "}
                  <span style={{color:viewJobModal.status==="complete"?"#22c55e":"#ef4444",fontWeight:700}}>
                    {(viewJobModal.status||"").toUpperCase()}
                  </span>
                  {viewJobModal.days_until_expiry!=null&&(
                    <span style={{color:"#f59e0b",marginLeft:8}}>· Expires in {viewJobModal.days_until_expiry}d</span>
                  )}
                </div>
              </div>
              <div style={{display:"flex",gap:8}}>
                <button onClick={()=>window.open(`${API}/jobs/${viewJobModal.id}/logs/download`,'_blank')}
                  style={{padding:"7px 16px",background:"linear-gradient(135deg,#FF000F,#cc0000)",
                          border:"none",borderRadius:8,color:"white",fontWeight:700,fontSize:13,cursor:"pointer"}}>
                  ⬇ Download Log
                </button>
                <button onClick={()=>setViewJobModal(null)}
                  style={{padding:"7px 14px",background:"#334155",border:"none",
                          borderRadius:8,color:"#94a3b8",cursor:"pointer"}}>✕</button>
              </div>
            </div>
            {/* Transport info */}
            <div style={{padding:"12px 22px",background:"rgba(0,0,0,0.2)",
                         borderBottom:"1px solid #1e293b",flexShrink:0,display:"flex",gap:24,flexWrap:"wrap"}}>
              {[
                ["TR ID",viewJobModal.transport_id,"#FF000F"],
                ["Package",(viewJobModal.package_ids||[]).join(", "),"#e2e8f0"],
                ["Source",viewJobModal.source,"#3b82f6"],
                ["Target",viewJobModal.target,"#FF000F"],
                ["Approved by",viewJobModal.approved_by||"Auto","#a78bfa"],
                ["Started",viewJobModal.created_at&&new Date(viewJobModal.created_at).toLocaleString(),"#94a3b8"],
              ].map(([k,v,c])=>v?(
                <div key={k} style={{fontSize:12}}>
                  <span style={{color:"#475569"}}>{k}: </span>
                  <span style={{color:c,fontWeight:600}}>{v}</span>
                </div>
              ):null)}
            </div>
            {/* Artifacts */}
            {(viewJobModal.artifact_details||[]).length>0&&(
              <div style={{padding:"10px 22px",borderBottom:"1px solid #1e293b",flexShrink:0}}>
                <div style={{fontSize:11,color:"#475569",fontWeight:700,marginBottom:6,textTransform:"uppercase",letterSpacing:1}}>
                  Artifacts ({(viewJobModal.artifact_details||[]).length})
                </div>
                <div style={{display:"flex",flexWrap:"wrap",gap:5}}>
                  {(viewJobModal.artifact_details||[]).map((a,i)=>(
                    <span key={i} style={{background:"rgba(99,102,241,0.1)",border:"1px solid rgba(99,102,241,0.25)",
                                          borderRadius:6,padding:"3px 9px",color:"#a5b4fc",fontSize:11}}>
                      {a.name}
                    </span>
                  ))}
                </div>
              </div>
            )}
            {/* Log lines */}
            <div style={{flex:1,overflow:"auto",padding:"14px 22px",
                         fontFamily:"monospace",fontSize:12,background:"#0f172a"}}>
              {(viewJobModal.logs||[]).map((entry,i)=>{
                const clr={success:"#22c55e",error:"#ef4444",warning:"#f59e0b",complete:"#a78bfa",info:"#475569"}[entry.status]||"#475569";
                const ts=(entry.timestamp||"").slice(11,19);
                const pct=entry.progress!=null?` [${String(entry.progress).padStart(3,"0")}%]`:"";
                return(
                  <div key={i} style={{color:clr,marginBottom:2,lineHeight:1.6}}>
                    <span style={{color:"#1e293b"}}>[{ts}]</span>
                    <span style={{color:"#334155"}}>{pct}</span>{" "}{entry.message}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* HEADER */}
      <header className="bg-slate-900/90 backdrop-blur border-b border-slate-700 px-6 h-14 flex items-center justify-between sticky top-0 z-40">
        <div className="flex items-center gap-3">
          <div style={{position:"relative",width:40,height:40,minWidth:40}}>
            <div style={{width:40,height:40,background:"linear-gradient(145deg,#FF000F 0%,#cc0000 55%,#7f0000 100%)",borderRadius:12,display:"flex",alignItems:"center",justifyContent:"center",boxShadow:"0 0 0 1px rgba(255,0,15,0.4),0 4px 20px rgba(255,0,15,0.45),inset 0 1px 0 rgba(255,255,255,0.15)",border:"1px solid rgba(255,80,80,0.2)"}}>
              <span style={{color:"white",fontWeight:900,fontSize:16,letterSpacing:"-1.5px",fontFamily:"system-ui,sans-serif",textShadow:"0 2px 6px rgba(0,0,0,0.5)"}}>SR</span>
            </div>
          </div>
          <div style={{lineHeight:1.2}}>
            <div style={{fontWeight:900,fontSize:19,letterSpacing:"2px",fontFamily:"system-ui,sans-serif",textTransform:"uppercase",color:"transparent",backgroundImage:"linear-gradient(180deg,#ffffff 0%,#e2e8f0 40%,#94a3b8 100%)",WebkitBackgroundClip:"text",backgroundClip:"text"}}>SAP CPI TRANSPORTER</div>
            <div style={{fontSize:10,marginTop:3,display:"flex",alignItems:"center",gap:5}}>
              <span style={{display:"inline-flex",alignItems:"center",gap:3,background:"rgba(255,0,15,0.12)",border:"1px solid rgba(255,0,15,0.25)",borderRadius:4,padding:"1px 6px",color:"#ff6b6b",fontWeight:700,fontSize:9}}>● LIVE</span>
              <span style={{color:"#475569",fontSize:10}}>SAP Integration Suite · iFlow Transport</span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 bg-slate-800 p-1 rounded-xl border border-slate-600">
            {[
              {id:"transport",icon:"🚀",label:"Transport"},
              {id:"jobs",     icon:"📋",label:"Jobs"},
              {id:"tenants",  icon:"🖥", label:"Tenants"},
              {id:"admin",    icon:"🔐",label:"Admin"},
              {id:"about",    icon:"ℹ️", label:"About"},
            ].map(t=>(
              <button key={t.id} onClick={()=>setTab(t.id)}
                className={cls("px-3 sm:px-4 py-1.5 rounded-lg text-xs font-semibold transition-all relative",
                  tab===t.id?"bg-slate-700 text-slate-100 shadow-sm":"text-slate-400 hover:text-slate-200"
                )}>
                {t.icon} <span className="hidden sm:inline">{t.label}</span>
                {t.id==="admin"&&pendingCount>0&&(
                  <span style={{position:"absolute",top:-4,right:-4,background:"#FF000F",color:"white",
                                borderRadius:"50%",width:16,height:16,fontSize:9,fontWeight:900,
                                display:"flex",alignItems:"center",justifyContent:"center",
                                border:"2px solid #0f172a"}}>
                    {pendingCount>9?"9+":pendingCount}
                  </span>
                )}
              </button>
            ))}
          </div>
          {/* Approval Portal button */}
          <button onClick={()=>window.open('#/approval-portal','_blank')}
            style={{display:"flex",alignItems:"center",gap:6,padding:"6px 14px",
                    background:pendingCount>0?"linear-gradient(135deg,#FF000F,#cc0000)":"#1e293b",
                    border:`1px solid ${pendingCount>0?"transparent":"#334155"}`,
                    borderRadius:10,color:"white",fontSize:12,fontWeight:700,cursor:"pointer",
                    position:"relative",whiteSpace:"nowrap"}}>
            {pendingCount>0&&<span style={{animation:"pulse 2s infinite"}}>🔔</span>}
            {pendingCount===0&&<span>🔔</span>}
            Approval Portal
            {pendingCount>0&&(
              <span style={{background:"white",color:"#FF000F",borderRadius:10,
                             padding:"1px 6px",fontSize:10,fontWeight:900}}>{pendingCount}</span>
            )}
            <span style={{fontSize:9,opacity:0.7}}>↗</span>
          </button>
          <button onClick={()=>setShowAdd(true)}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold text-white hover:shadow-lg transition-all"
            style={{background:"linear-gradient(135deg,#FF000F,#cc0000)"}}>
            + Add Tenant
          </button>
          {adminInfo?(
            <div style={{display:"flex",alignItems:"center",gap:6,background:"rgba(255,0,15,0.1)",
                         border:"1px solid rgba(255,0,15,0.3)",borderRadius:20,padding:"4px 10px",cursor:"pointer"}}
                 onClick={()=>setTab('admin')}>
              <span style={{fontSize:11,color:"#ff9999",fontWeight:700}}>🔐 {adminInfo.username}</span>
            </div>
          ):(
            <div style={{position:"relative"}} title="Sagar Reddy">
              <div style={{width:34,height:34,borderRadius:"50%",background:"linear-gradient(145deg,#FF000F,#7f0000)",display:"flex",alignItems:"center",justifyContent:"center",boxShadow:"0 0 0 2px #0f172a,0 0 0 4px rgba(255,0,15,0.35)"}}>
                <span style={{color:"white",fontWeight:900,fontSize:12}}>SR</span>
              </div>
              <div style={{position:"absolute",bottom:1,right:1,width:9,height:9,background:"#22c55e",borderRadius:"50%",border:"2px solid #0f172a"}}/>
            </div>
          )}
        </div>
      </header>

      {tab==="transport"&&<StepNav step={step}/>}

      <main className="max-w-5xl mx-auto p-4 sm:p-6 space-y-4">

        {/* TRANSPORT TAB */}
        {tab==="transport"&&(
          <div className="bg-slate-800 rounded-3xl shadow-sm border border-slate-700 overflow-hidden backdrop-blur">

            {/* STEP 1 */}
            {step===1&&(
              <div className="p-6 space-y-5">
                <div className="flex items-start justify-between">
                  <div>
                    <h2 className="text-2xl font-black text-slate-100">Select Tenants</h2>
                    <p className="text-sm text-slate-400 mt-0.5">Drag & drop or click to assign source and target tenants</p>
                  </div>
                  <span className="text-xs bg-indigo-900/50 text-indigo-300 border border-indigo-700 px-3 py-1.5 rounded-full font-semibold">⇄ Drag & Drop</span>
                </div>

                {/* PROD / NON-PROD ENV INDICATOR */}
                {tgt&&(
                  <div style={{display:"flex",gap:12,marginBottom:4}}>
                    <div style={{
                      display:"inline-flex",alignItems:"center",gap:8,
                      padding:"8px 16px",borderRadius:10,
                      background:isProdTarget?"rgba(255,0,15,0.12)":"rgba(34,197,94,0.12)",
                      border:`1px solid ${isProdTarget?"#FF000F":"#22c55e"}`,
                    }}>
                      <span style={{fontSize:16}}>{isProdTarget?"🔴":"🟢"}</span>
                      <span style={{color:isProdTarget?"#FF000F":"#22c55e",fontWeight:"bold",fontSize:13}}>
                        {isProdTarget?"PRODUCTION TARGET — Approval Required":"NON-PRODUCTION — Direct Deploy"}
                      </span>
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4">
                  <DropZone label="📤 SOURCE — copy FROM" side="src" tenant={src} tenantData={srcT} tStatus={tStatus} onDrop={handleDrop} onClear={()=>{setSrc(null);setPackages([]);setSelPkgs([]);setSelArts({});}}/>
                  <DropZone label="📥 TARGET — copy TO" side="tgt" tenant={tgt} tenantData={tgtT} tStatus={tStatus} onDrop={handleDrop} onClear={()=>setTgt(null)}/>
                </div>
                {src&&tgt&&src!==tgt&&(
                  <div className="flex items-center gap-3 p-3 bg-gradient-to-r from-red-900/30 to-orange-900/30 rounded-2xl border border-red-700">
                    <span className="font-bold text-sm text-slate-200">{srcT?.name}</span>
                    <div className="flex-1 h-0.5 bg-gradient-to-r from-red-600 to-orange-600 rounded"/>
                    <span className="text-red-400 font-black">→</span>
                    <div className="flex-1 h-0.5 bg-gradient-to-r from-orange-600 to-red-600 rounded"/>
                    <span className="font-bold text-sm text-slate-200">{tgtT?.name}</span>
                  </div>
                )}
                {src&&tgt&&src===tgt&&<div className="p-3 bg-red-900/30 border border-red-700 rounded-2xl text-sm text-red-300 font-medium text-center">⚠️ Source and Target must be different</div>}
                <div>
                  <div className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3">Available Tenants ({tenants.length})</div>
                  <div className="space-y-2">{tenants.map(t=><TenantCard key={t.key} tenant={t} tStatus={tStatus} onValidate={validate} onClick={handleClick} onDelete={setDeleteKey}/>)}</div>
                </div>
                <div className="flex justify-between items-center pt-2">
                  <button onClick={()=>setShowAdd(true)} className="text-sm text-slate-400 hover:text-red-400 transition-colors font-medium">+ Add tenant</button>
                  <button disabled={!canNext1} onClick={()=>{if(src)fetchPkgs(src);setStep(2);}}
                    className="flex items-center gap-2 px-6 py-3 rounded-2xl text-white font-bold disabled:opacity-30 hover:shadow-lg transition-all"
                    style={{background:"linear-gradient(135deg,#FF000F,#ff6b35)"}}>
                    Next: Select Objects →
                  </button>
                </div>
              </div>
            )}

            {/* STEP 2 */}
            {/* STEP 2 — Enhanced Package + Artifact Selection */}
            {step===2&&(
              <div className="p-6 space-y-4">
                {/* Header */}
                <div style={{display:"flex",alignItems:"flex-start",justifyContent:"space-between",flexWrap:"wrap",gap:12}}>
                  <div>
                    <h2 className="text-2xl font-black text-slate-100">Select Objects</h2>
                    <p className="text-sm text-slate-400 mt-0.5">
                      Packages &amp; artifacts from <strong style={{color:"#FF000F"}}>{srcT?.label||srcT?.name}</strong>
                      {packages.length>0&&<span style={{marginLeft:8,background:"#1e293b",color:"#94a3b8",padding:"1px 8px",borderRadius:20,fontSize:11,fontFamily:"monospace"}}>{packages.length} pkgs</span>}
                    </p>
                  </div>
                  {packages.length>0&&(
                    <div style={{display:"flex",gap:8}}>
                      <button onClick={selectAllPkgs}
                        style={{padding:"7px 14px",background:"rgba(255,0,15,0.12)",border:"1px solid rgba(255,0,15,0.35)",borderRadius:10,color:"#ff9999",cursor:"pointer",fontSize:12,fontWeight:700}}>
                        ☑ All Packages
                      </button>
                      {selPkgs.length>0&&<button onClick={clearAll}
                        style={{padding:"7px 14px",background:"rgba(100,116,139,0.1)",border:"1px solid #334155",borderRadius:10,color:"#64748b",cursor:"pointer",fontSize:12,fontWeight:600}}>
                        ✕ Clear
                      </button>}
                    </div>
                  )}
                </div>

                {/* List */}
                {loadingPkgs?(
                  <div className="space-y-3 py-4">{[1,2,3].map(i=><div key={i} className="animate-pulse h-16 bg-slate-700 rounded-2xl"/>)}</div>
                ):packages.length===0?(
                  <div style={{display:"flex",flexDirection:"column",alignItems:"center",padding:"56px 0",color:"#475569",gap:12}}>
                    <div style={{fontSize:48}}>📭</div>
                    <div style={{fontWeight:600}}>No packages found</div>
                    <div style={{fontSize:12}}>Check source tenant connection</div>
                  </div>
                ):(
                  <div style={{border:"1px solid #334155",borderRadius:16,overflow:"hidden",maxHeight:460,overflowY:"auto"}}>
                    {packages.map(pkg=>{
                      const isSel=selPkgs.includes(pkg.Id);
                      const pkgArts=artifacts[pkg.Id];
                      const selPA=selArts[pkg.Id]||[];
                      const allSel=pkgArts&&pkgArts.length>0&&selPA.length===pkgArts.length;
                      return(
                        <div key={pkg.Id} style={{background:isSel?"rgba(255,0,15,0.06)":"rgba(30,41,59,0.5)",borderBottom:"1px solid #0f172a"}}>
                          {/* Package Row */}
                          <div style={{display:"flex",alignItems:"center",gap:12,padding:"13px 16px",cursor:"pointer"}}
                            onClick={()=>togPkg(pkg.Id)}>
                            <div style={{width:20,height:20,borderRadius:6,border:`2px solid ${isSel?"#FF000F":"#475569"}`,background:isSel?"#FF000F":"transparent",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,transition:"all .15s"}}>
                              {isSel&&<span style={{color:"white",fontSize:10,fontWeight:900}}>✔</span>}
                            </div>
                            <div style={{width:36,height:36,borderRadius:10,background:"linear-gradient(135deg,#4c1d95,#5b21b6)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:17,flexShrink:0}}>📦</div>
                            <div style={{flex:1,minWidth:0}}>
                              <div style={{fontWeight:700,fontSize:14,color:"white",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{pkg.Name}</div>
                              <div style={{fontSize:10,color:"#475569",fontFamily:"monospace",marginTop:2}}>{pkg.Id} · v{pkg.Version}</div>
                            </div>
                            {isSel&&pkgArts&&(
                              <span style={{background:"rgba(255,0,15,0.15)",border:"1px solid rgba(255,0,15,0.4)",color:"#ff9999",borderRadius:20,padding:"2px 9px",fontSize:11,fontWeight:700,flexShrink:0}}>
                                {selPA.length}/{pkgArts.length} arts
                              </span>
                            )}
                            {isSel&&pkgArts===null&&<span style={{color:"#475569",fontSize:11}}>⏳</span>}
                            <span style={{color:"#334155",fontSize:12,flexShrink:0}}>{isSel?"▲":"▼"}</span>
                          </div>

                          {/* Artifact Panel */}
                          {isSel&&(
                            <div style={{background:"rgba(15,23,42,0.7)",borderTop:"1px solid #0f172a",padding:"0 16px 12px 16px"}}>
                              {pkgArts===null?(
                                <div style={{padding:"14px 0 6px 50px"}}>
                                  <div style={{height:3,background:"#1e293b",borderRadius:4,overflow:"hidden",maxWidth:180}}>
                                    <div style={{height:"100%",background:"#FF000F",width:"55%",borderRadius:4}}/>
                                  </div>
                                  <div style={{color:"#475569",fontSize:11,marginTop:5}}>⏳ Loading artifacts…</div>
                                </div>
                              ):pkgArts.length===0?(
                                <div style={{padding:"10px 0 4px 50px",color:"#475569",fontSize:12}}>📭 No artifacts in this package</div>
                              ):(
                                <div style={{marginLeft:50,borderLeft:"2px solid rgba(255,0,15,0.35)",paddingLeft:14}}>
                                  {/* Select all toggle */}
                                  <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"8px 0 5px"}}>
                                    <span style={{fontSize:11,fontWeight:700,color:"#FF000F",textTransform:"uppercase",letterSpacing:1}}>
                                      ⚡ {pkgArts.length} Artifact{pkgArts.length!==1?"s":""}
                                    </span>
                                    <button onClick={e=>{e.stopPropagation();togAllArts(pkg.Id);}}
                                      style={{fontSize:11,fontWeight:700,color:allSel?"#64748b":"#ff9999",background:"none",border:"none",cursor:"pointer"}}>
                                      {allSel?"☐ Deselect All":"☑ Select All"}
                                    </button>
                                  </div>
                                  {/* Artifact list */}
                                  {pkgArts.map(a=>{
                                    const isSA=(selArts[pkg.Id]||[]).includes(a.Id);
                                    const aType=a.Type||a.ArtifactType||"";
                                    return(
                                      <div key={a.Id} onClick={e=>{e.stopPropagation();togArt(pkg.Id,a.Id);}}
                                        style={{display:"flex",alignItems:"center",gap:10,padding:"8px 10px",borderRadius:10,cursor:"pointer",marginBottom:3,transition:"all .1s",
                                          background:isSA?"rgba(255,0,15,0.1)":"transparent",
                                          border:isSA?"1px solid rgba(255,0,15,0.25)":"1px solid transparent"}}>
                                        <div style={{width:15,height:15,borderRadius:4,border:`2px solid ${isSA?"#FF000F":"#334155"}`,background:isSA?"#FF000F":"transparent",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                                          {isSA&&<span style={{color:"white",fontSize:7,fontWeight:900}}>✔</span>}
                                        </div>
                                        <span style={{fontSize:14,flexShrink:0}}>{artTypeIcon(aType)}</span>
                                        <div style={{flex:1,minWidth:0}}>
                                          <div style={{fontSize:13,fontWeight:600,color:isSA?"white":"#94a3b8",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{a.Name}</div>
                                          <div style={{fontSize:10,color:"#334155",fontFamily:"monospace",marginTop:1}}>
                                            {a.Id}
                                            {aType&&<span style={{marginLeft:6,color:"#475569",background:"#0f172a",padding:"1px 4px",borderRadius:4,fontSize:9}}>{aType}</span>}
                                          </div>
                                        </div>
                                        <span style={{fontSize:10,color:"#334155",fontFamily:"monospace",flexShrink:0}}>v{a.Version}</span>
                                      </div>
                                    );
                                  })}
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* Summary */}
                {selPkgs.length>0&&(
                  <div style={{display:"flex",alignItems:"center",gap:12,padding:"12px 16px",background:"linear-gradient(135deg,rgba(109,40,217,0.12),rgba(79,70,229,0.08))",border:"1px solid rgba(109,40,217,0.35)",borderRadius:14}}>
                    <span style={{fontSize:20}}>📊</span>
                    <div style={{flex:1}}>
                      <div style={{fontSize:13,fontWeight:700,color:"white"}}>
                        <span style={{color:"#c084fc"}}>{selPkgs.length}</span> package{selPkgs.length!==1?"s":""} &nbsp;·&nbsp;
                        <span style={{color:"#60a5fa"}}>{allArtCount}</span> artifact{allArtCount!==1?"s":""} selected
                      </div>
                      <div style={{fontSize:11,color:"#475569",marginTop:3,display:"flex",flexWrap:"wrap",gap:8}}>
                        {selPkgs.map(id=>{const p=packages.find(x=>x.Id===id);const ac=(selArts[id]||[]).length;const tot=(artifacts[id]||[]).length;
                          return p?<span key={id}>📦 {p.Name} <span style={{color:"#FF000F"}}>({ac}/{tot})</span></span>:null;})}
                      </div>
                    </div>
                  </div>
                )}

                {/* Navigation */}
                <div style={{display:"flex",justifyContent:"space-between",paddingTop:8}}>
                  <button onClick={()=>setStep(1)} style={{padding:"10px 20px",borderRadius:14,border:"1px solid #334155",color:"#64748b",background:"transparent",cursor:"pointer",fontWeight:600,fontSize:13}}>
                    ← Back
                  </button>
                  <button disabled={selPkgs.length===0||allArtCount===0}
                    onClick={()=>{setStep(3);runScan();}}
                    style={{display:"flex",alignItems:"center",gap:8,padding:"10px 24px",borderRadius:14,background:selPkgs.length===0||allArtCount===0?"#1e293b":"linear-gradient(135deg,#FF000F,#cc0000)",color:"white",border:"none",cursor:selPkgs.length===0||allArtCount===0?"not-allowed":"pointer",fontWeight:700,fontSize:13,opacity:selPkgs.length===0||allArtCount===0?0.4:1}}>
                    🔍 Scan &amp; Continue → ({selPkgs.length} pkg · {allArtCount} art)
                  </button>
                </div>
              </div>
            )}

            {/* STEP 3 */}
            {step===3&&(
              <div className="p-6 space-y-5">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-white shadow-md text-xl" style={{background:"linear-gradient(135deg,#0ea5e9,#6366f1)"}}>🔍</div>
                  <div className="flex-1"><h2 className="text-2xl font-black text-slate-100">Security Validation</h2><p className="text-sm text-slate-400">8 automated pre-flight checks</p></div>
                  {scanDone&&<Badge status="passed"/>}
                </div>
                <div className="grid grid-cols-2 gap-2">{scans.map(s=><ScanRow key={s.id} {...s}/>)}</div>
                {!scanDone&&<div className="flex items-center gap-3 p-4 bg-blue-900/30 rounded-2xl border border-blue-700 text-sm text-blue-300"><Spinner/> Running checks…</div>}
                {scanDone&&(
                  <div className="flex items-center gap-4 p-4 bg-emerald-900/30 rounded-2xl border border-emerald-700">
                    <div className="w-10 h-10 bg-emerald-500 rounded-2xl flex items-center justify-center text-white text-lg shadow-md">✔</div>
                    <div><div className="font-bold text-emerald-300">All {scans.length} checks passed — Transport is secure</div><div className="text-xs text-emerald-400 mt-0.5">Ready for approval gate</div></div>
                  </div>
                )}
                <div className="flex justify-between pt-2">
                  <button onClick={()=>setStep(2)} className="px-5 py-2.5 rounded-2xl border border-slate-600 text-slate-400 hover:bg-slate-700 font-medium text-sm">← Back</button>
                  <button disabled={!scanDone} onClick={()=>setStep(4)}
                    className="flex items-center gap-2 px-6 py-3 rounded-2xl text-white font-bold disabled:opacity-30 hover:shadow-lg transition-all"
                    style={{background:"linear-gradient(135deg,#22c55e,#16a34a)"}}>
                    Proceed to Approval →
                  </button>
                </div>
              </div>
            )}

            {/* STEP 4 */}
            {step===4&&(
              <div className="p-6 space-y-5">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-white shadow-md text-xl" style={{background:"linear-gradient(135deg,#f59e0b,#ef4444)"}}>📋</div>
                  <div><h2 className="text-2xl font-black text-slate-100">Approve Transport</h2><p className="text-sm text-slate-400">Review and authorize execution</p></div>
                </div>

                {/* PROD WARNING BANNER */}
                {isProdTarget&&(
                  <div style={{background:"rgba(255,0,15,0.1)",border:"2px solid #FF000F",borderRadius:12,padding:"14px 18px",display:"flex",alignItems:"center",gap:12}}>
                    <span style={{fontSize:24}}>🔴</span>
                    <div>
                      <div style={{color:"#FF000F",fontWeight:"bold",fontSize:14}}>PRODUCTION TARGET DETECTED</div>
                      <div style={{color:"#ff9999",fontSize:12,marginTop:2}}>
                        Clicking "Execute Transport" will send approval emails to:<br/>
                        <strong>sagar.reddy@in.abb.com</strong> &amp; <strong>sreenivasulu.kancham@in.abb.com</strong><br/>
                        Transport will start <strong>automatically</strong> after approval.
                      </div>
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-3 gap-3">
                  {[{icon:"📤",label:"Source",value:srcT?.name,sub:srcT?.env+" · "+srcT?.region},
                    {icon:"📥",label:"Target",value:tgtT?.name,sub:tgtT?.env+" · "+tgtT?.region},
                    {icon:"02",label:"Payload",value:selPkgs.length+" packages",sub:allArtCount+" artifacts"}].map((c,i)=>(
                    <div key={i} className="p-4 bg-slate-800 rounded-2xl border border-slate-700">
                      <div className="text-2xl mb-2">{c.icon}</div>
                      <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">{c.label}</div>
                      <div className="font-bold text-slate-200 mt-0.5 text-sm">{c.value}</div>
                      <div className="text-xs text-slate-500">{c.sub}</div>
                    </div>
                  ))}
                </div>
                <div className="p-4 bg-slate-800 rounded-2xl border border-slate-700">
                  <div className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3">Transport Options</div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="text-xs text-slate-500 mb-2 font-semibold">Conflict Resolution</div>
                      <div className="flex gap-2 flex-wrap">
                        {["overwrite","skip","rename"].map(v=>(
                          <button key={v} onClick={()=>setOpts(o=>({...o,conflict_resolution:v}))}
                            className={cls("px-3 py-1.5 rounded-xl text-xs font-bold border-2 transition-all capitalize",
                              opts.conflict_resolution===v?"text-white border-red-500":"bg-slate-700 border-slate-600 text-slate-400"
                            )} style={opts.conflict_resolution===v?{background:"linear-gradient(135deg,#FF000F,#ff6b35)"}:{}}>{v}</button>
                        ))}
                      </div>
                    </div>
                    <div className="space-y-2">
                      {[["deploy_after","🚀 Deploy after transport"],["dry_run","🧪 Dry run"],["validate_checksum","🔍 Verify integrity"],["auto_rollback","↺ Auto rollback"]].map(([k,l])=>(
                        <label key={k} className="flex items-center gap-2.5 cursor-pointer">
                          <div onClick={()=>setOpts(o=>({...o,[k]:!o[k]}))}
                            className={cls("w-9 h-5 rounded-full border-2 relative cursor-pointer transition-all",opts[k]?"bg-blue-500 border-blue-500":"bg-slate-600 border-slate-600")}>
                            <div className={cls("absolute top-0.5 w-3 h-3 rounded-full bg-white shadow transition-all",opts[k]?"left-[20px]":"left-0.5")}/>
                          </div>
                          <span className={cls("text-xs",opts[k]?"text-slate-200 font-semibold":"text-slate-400")}>{l}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>
                <div className={cls("p-4 rounded-2xl border-2 cursor-pointer transition-all",approved?"bg-emerald-900/30 border-emerald-700 shadow-md":"bg-slate-800 border-slate-700 hover:border-slate-600")} onClick={()=>setApproved(a=>!a)}>
                  <div className="flex items-start gap-3">
                    <div className={cls("w-6 h-6 rounded-lg border-2 flex items-center justify-center transition-all shrink-0",approved?"bg-emerald-500 border-emerald-500 text-white":"border-slate-500")}>
                      {approved&&<span className="text-xs font-black">✔</span>}
                    </div>
                    <div>
                      <div className="font-bold text-slate-200 text-sm">I authorize this transport operation</div>
                      <div className="text-xs text-slate-400 mt-1 leading-relaxed">Moving <strong>{selPkgs.length}</strong> package(s) from <strong>{srcT?.name}</strong> → <strong>{tgtT?.name}</strong>{opts.dry_run&&<span className="text-amber-400 font-bold ml-1">[DRY RUN]</span>}</div>
                    </div>
                  </div>
                </div>
                <div className="flex justify-between pt-2">
                  <button onClick={()=>setStep(3)} className="px-5 py-2.5 rounded-2xl border border-slate-600 text-slate-400 hover:bg-slate-700 font-medium text-sm">← Back</button>
                  <button disabled={!approved} onClick={handleDeploy}
                    className="flex items-center gap-3 px-8 py-3 rounded-2xl text-white font-black text-base disabled:opacity-30 hover:shadow-xl transition-all"
                    style={{background:approved?(isProdTarget?"linear-gradient(135deg,#FF000F,#cc0000)":"linear-gradient(135deg,#FF000F,#ff6b35)"):"#475569",boxShadow:approved?"0 8px 25px rgba(255,0,15,0.3)":"none"}}>
                    {isProdTarget?"📧 Request Approval":"🚀 Execute Transport"}
                  </button>
                </div>
              </div>
            )}

            {/* STEP 5 */}
            {step===5&&(
              <div className="p-6 space-y-5">
                <div className="flex items-center justify-between">
                  <div>
                    <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:4}}>
                      <h2 className="text-2xl font-black text-slate-100">Live Transport</h2>
                      {jStatus==="complete"&&<span style={{background:"linear-gradient(135deg,#22c55e,#16a34a)",color:"white",padding:"3px 12px",borderRadius:20,fontSize:11,fontWeight:700}}>✔ COMPLETE</span>}
                      {jStatus==="error"&&<span style={{background:"#ef4444",color:"white",padding:"3px 12px",borderRadius:20,fontSize:11,fontWeight:700}}>✘ FAILED</span>}
                    </div>
                    <div style={{display:"flex",alignItems:"center",gap:6}}>
                      <div style={{display:"flex",alignItems:"center",gap:8}}>
                  <span style={{background:"rgba(255,0,15,0.15)",border:"1px solid rgba(255,0,15,0.4)",borderRadius:6,padding:"3px 12px",fontFamily:"monospace",fontSize:13,fontWeight:900,color:"#FF000F",letterSpacing:2}}>
                    🔖 {transportId||jobId}
                  </span>
                  <span style={{background:"#1e293b",border:"1px solid #334155",borderRadius:6,padding:"2px 8px",fontFamily:"monospace",fontSize:10,color:"#475569"}}>
                    JOB: {jobId}
                  </span>
                </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge status={jStatus==="complete"?"complete":jStatus}/>
                    <div
                      className="relative"
                      style={{cursor:jStatus==="complete"?"pointer":"default"}}
                      title={jStatus==="complete"?"Click to start new transport":""}
                      onClick={()=>{if(jStatus==="complete"){setStep(1);setSrc(null);setTgt(null);setSelPkgs([]);setSelArts({});setLogs([]);setProg(0);setApproved(false);setScanDone(false);setScans([]);setJStatus("idle");}}}
                    >
                      <Ring pct={prog} size={56} stroke={5}/>
                      <div className="absolute inset-0 flex items-center justify-center">
                        {jStatus==="complete"
                          ? <span style={{fontSize:18}}>🏠</span>
                          : <span className="text-[12px] font-black text-slate-200">{prog}%</span>
                        }
                      </div>
                    </div>
                  </div>
                </div>
                <div className="p-5 rounded-2xl border border-slate-700 flex items-center gap-5" style={{background:"linear-gradient(135deg,#1e3a4f,#0f172a)"}}>
                  <div className="text-center shrink-0">
                    <Avatar letter={srcT?.name?.charAt(0)} k={src} size="w-14 h-14 text-2xl mx-auto"/>
                    <div className="text-xs font-bold text-slate-300 mt-2">{srcT?.name}</div>
                    <div className="text-[10px] text-slate-500">{srcT?.region}</div>
                  </div>
                  <div className="flex-1 space-y-2"><Bar pct={prog} h={10}/><div className={cls("text-xs text-center font-semibold",jStatus==="complete"?"text-emerald-400":"text-slate-400")}>{jStatus==="complete"?"✔ Transport Complete!":jStatus==="error"?"❌ Transport Failed":`Transporting… ${prog}%`}</div></div>
                  <div className="text-center shrink-0">
                    <Avatar letter={tgtT?.name?.charAt(0)} k={tgt} size="w-14 h-14 text-2xl mx-auto"/>
                    <div className="text-xs font-bold text-slate-300 mt-2">{tgtT?.name}</div>
                    <div className="text-[10px] text-slate-500">{tgtT?.region}</div>
                  </div>
                </div>
                <div ref={logRef} className="bg-slate-950 border border-slate-800 rounded-2xl p-4 h-72 overflow-y-auto">
                  <div className="flex items-center gap-2 pb-2 mb-2 border-b border-slate-800">
                    <div className="flex gap-1.5"><div className="w-3 h-3 rounded-full bg-red-500"/><div className="w-3 h-3 rounded-full bg-yellow-500"/><div className="w-3 h-3 rounded-full bg-green-500"/></div>
                    <span className="text-slate-500 text-xs font-mono ml-1">SR Transport Engine v1.0</span>
                    {jStatus==="running"&&<div className="ml-auto w-2 h-2 rounded-full bg-green-400 animate-pulse"/>}
                  </div>
                  {logs.length===0?<div className="text-slate-500 text-xs font-mono">SR Transport Engine v1.0 — Ready</div>:logs.map((l,i)=><LogLine key={i} log={l}/>)}
                </div>
                {jStatus==="complete"&&(
                  <div className="p-5 bg-gradient-to-r from-emerald-900/30 to-green-900/30 rounded-2xl border border-emerald-700 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-emerald-500 rounded-2xl flex items-center justify-center text-2xl shadow-lg shadow-emerald-900/50">🎉</div>
                      <div><div className="font-black text-emerald-300 text-base">Transport Complete!</div><div className="text-sm text-emerald-400">{srcT?.name} → {tgtT?.name} ✔</div></div>
                    </div>
                    <button onClick={()=>{setStep(1);setSrc(null);setTgt(null);setSelPkgs([]);setSelArts({});setLogs([]);setProg(0);setApproved(false);setScanDone(false);setScans([]);setJStatus("idle");}}
                      className="px-5 py-2.5 rounded-2xl text-white font-bold hover:shadow-lg transition-all" style={{background:"linear-gradient(135deg,#22c55e,#16a34a)"}}>🔄 New</button>
                  </div>
                )}
                {jStatus==="error"&&(
                  <div className="p-4 bg-red-900/30 rounded-2xl border border-red-700">
                    <div className="font-bold text-red-300">Transport had errors — check log above</div>
                    <button onClick={()=>{setStep(1);setSrc(null);setTgt(null);setSelPkgs([]);setSelArts({});setLogs([]);setProg(0);setApproved(false);setScanDone(false);setScans([]);setJStatus("idle");}}
                      className="mt-3 px-4 py-2 rounded-xl text-white text-xs font-bold" style={{background:"#ef4444"}}>🔄 Try Again</button>
                  </div>
                )}
              </div>
            )}
          </div>
        )}


        {/* JOBS TAB - Enhanced with full details + log download */}
        {tab==="jobs"&&(
          <div className="bg-slate-800 rounded-3xl shadow-sm border border-slate-700 p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-2xl font-black text-slate-100">Transport Jobs</h2>
                <p className="text-sm text-slate-400 mt-0.5">Full history · logs stored 60 days · auto-expire after 60 days</p>
              </div>
              <div style={{display:"flex",gap:8}}>
                <button onClick={()=>window.open('#/approval-portal','_blank')}
                  style={{padding:"8px 16px",background:"linear-gradient(135deg,#FF000F,#cc0000)",
                          border:"none",borderRadius:10,color:"white",fontWeight:700,
                          fontSize:13,cursor:"pointer",display:"flex",alignItems:"center",gap:6}}>
                  🔔 Approval Portal ↗
                </button>
                <button onClick={()=>fetch(`${API}/jobs`).then(r=>r.json()).then(d=>setJobs(Array.isArray(d)?d:(d.jobs||[])))}
                  className="flex items-center gap-2 px-4 py-2 bg-slate-700 rounded-xl text-sm font-semibold hover:bg-slate-600">
                  ↻ Refresh
                </button>
              </div>
            </div>
            {jobs.length===0?(
              <div className="flex flex-col items-center py-16 text-slate-500 gap-3">
                <div className="text-5xl">📋</div>
                <div className="font-semibold text-lg">No jobs yet</div>
                <div className="text-sm">Start a transport to see it here</div>
              </div>
            ):(
              <div className="space-y-3">
                {/* ── Column Headers ── */}
                <div style={{display:"flex",alignItems:"center",gap:12,padding:"8px 18px",background:"#0f172a",borderRadius:10,flexWrap:"wrap",fontSize:11,fontWeight:700,color:"#475569",textTransform:"uppercase",letterSpacing:1}}>
                  <div style={{minWidth:130,flexShrink:0}}>🔖 TR Number</div>
                  <div style={{flex:1,minWidth:140}}>📦 Source → Target</div>
                  <div style={{width:120}}>📊 Progress</div>
                  <div style={{minWidth:80}}>⚡ Status</div>
                  <div style={{minWidth:60}}>⏳ Expiry</div>
                  <div style={{minWidth:100}}>Actions</div>
                </div>
                {jobs.map(j=>{
                  const sColor={complete:"#22c55e",error:"#ef4444",running:"#3b82f6",queued:"#8b5cf6"}[j.status]||"#64748b";
                  const expDays=j.days_until_expiry;
                  const isExpanded=expanded&&expanded[j.id];
                  return(
                    <div key={j.id||j.job_id}
                      style={{background:"#1e293b",border:"1px solid #334155",borderRadius:14,overflow:"hidden"}}>
                      {/* Job row */}
                      <div style={{padding:"14px 18px",display:"flex",alignItems:"center",
                                   gap:12,cursor:"pointer",flexWrap:"wrap"}}
                           onClick={()=>setExpanded&&setExpanded(e=>({...(e||{}),[(j.id||j.job_id)]:!e?.[j.id||j.job_id]}))}>
                        <div style={{minWidth:130,flexShrink:0}}>
                          <div style={{fontFamily:"monospace",color:"#FF000F",fontWeight:700,fontSize:13}}>
                            {j.transport_id||((j.id||j.job_id||'').slice(0,8)+'…')}
                          </div>
                          <div style={{color:"#475569",fontSize:11,marginTop:1}}>
                            {j.created_at&&new Date(j.created_at).toLocaleString()}
                          </div>
                        </div>
                        <div style={{flex:1,minWidth:140}}>
                          <div style={{fontSize:13,color:"#94a3b8",fontWeight:600}}>
                            {j.source} <span style={{color:"#475569"}}>→</span> <b style={{color:"#FF000F"}}>{j.target}</b>
                          </div>
                          <div style={{fontSize:11,color:"#475569"}}>
                            {(j.package_ids||[]).join(", ")}
                          </div>
                        </div>
                        <div style={{width:120}}>
                          <div style={{height:5,background:"#334155",borderRadius:4,overflow:"hidden"}}>
                            <div style={{height:5,width:`${j.progress||0}%`,
                                         background:j.progress===100?"#22c55e":"#FF000F",
                                         borderRadius:4,transition:"width .3s"}}/>
                          </div>
                          <div style={{fontSize:11,color:"#475569",textAlign:"right",marginTop:2}}>{j.progress||0}%</div>
                        </div>
                        <span style={{background:`${sColor}22`,border:`1px solid ${sColor}55`,
                                       borderRadius:20,padding:"3px 10px",color:sColor,
                                       fontSize:11,fontWeight:700,flexShrink:0}}>
                          {(j.status||"").toUpperCase()}
                        </span>
                        <div style={{fontSize:11,color:expDays<7?"#f59e0b":"#334155",flexShrink:0}}>
                          {j.archived?"📦 Archived":`⏱ ${expDays}d`}
                        </div>
                        <div style={{display:"flex",gap:6,flexShrink:0}}>
                          <button onClick={e=>{e.stopPropagation();
                            fetch(`${API}/jobs/${j.id||j.job_id}`).then(r=>r.json()).then(full=>{
                              setViewJobModal(full);
                            });
                          }}
                            style={{padding:"5px 10px",background:"rgba(99,102,241,0.1)",
                                    border:"1px solid rgba(99,102,241,0.3)",borderRadius:7,
                                    color:"#a5b4fc",cursor:"pointer",fontSize:11,fontWeight:600}}>
                            👁 Logs
                          </button>
                          <button onClick={e=>{e.stopPropagation();
                            window.open(`${API}/jobs/${j.id||j.job_id}/logs/download`,'_blank');
                          }}
                            style={{padding:"5px 10px",background:"rgba(255,0,15,0.08)",
                                    border:"1px solid rgba(255,0,15,0.25)",borderRadius:7,
                                    color:"#ff9999",cursor:"pointer",fontSize:11,fontWeight:600}}>
                            ⬇
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}


        {/* TENANTS TAB */}
        {tab==="tenants"&&(
          <div className="bg-slate-800 rounded-3xl shadow-sm border border-slate-700 p-6">
            <div className="flex items-center justify-between mb-6">
              <div><h2 className="text-2xl font-black text-slate-100">Registered Tenants</h2><p className="text-sm text-slate-400 mt-0.5">{tenants.length} CPI environments connected</p></div>
              <button onClick={()=>setShowAdd(true)} className="flex items-center gap-2 px-4 py-2.5 rounded-2xl text-white font-bold hover:shadow-lg transition-all" style={{background:"linear-gradient(135deg,#FF000F,#ff6b35)"}}>+ Add Tenant</button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {tenants.map(t=>{
                const c=gc(t.key);
                return(
                  <div key={t.key} className="group p-5 bg-slate-800 rounded-3xl hover:shadow-lg transition-all relative overflow-hidden border border-slate-700">
                    <div className="absolute top-0 right-0 w-28 h-28 rounded-full opacity-5 -translate-y-6 translate-x-6" style={{background:`linear-gradient(135deg,${c.from},${c.to})`}}/>
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <Avatar letter={((t.label||t.name)||'?').charAt(0)} k={t.key} size="w-11 h-11 text-xl"/>
                        <div><div className="font-bold text-slate-100">{t.label||t.name}</div><div className="text-xs text-slate-400">{t.environment||t.env}</div></div>
                      </div>
                      <button onClick={()=>setDeleteKey(t.key)} className="opacity-0 group-hover:opacity-100 w-7 h-7 rounded-lg bg-red-900/30 text-red-400 hover:bg-red-700/50 flex items-center justify-center text-sm transition-all">✕</button>
                    </div>
                    {tStatus[t.key]&&<div className="mb-3"><Badge status={tStatus[t.key]}/></div>}
                    <div className="space-y-1 text-xs bg-slate-900/50 rounded-xl p-3 font-mono mb-4 border border-slate-700">
                      <div className="text-slate-400 truncate">🌐 {t.url}</div>
                      <div className="text-slate-500">📌 {t.region} · 🔑 {t.type}</div>
                    </div>
                    <button onClick={()=>validate(t.key)} className="w-full py-2.5 rounded-xl border-2 border-dashed text-xs font-bold transition-all"
                      style={tStatus[t.key]==="connected"?{borderColor:"#22c55e",background:"rgba(34,197,94,0.1)",color:"#22c55e"}:{borderColor:"#475569",color:"#94a3b8"}}>
                      {tStatus[t.key]==="loading"?"⏳ Testing…":tStatus[t.key]==="connected"?"✔ Connected — Re-test":"🔌 Test Connection"}
                    </button>
                  </div>
                );
              })}
              <div onClick={()=>setShowAdd(true)} className="flex flex-col items-center justify-center p-6 border-2 border-dashed border-slate-600 rounded-3xl cursor-pointer hover:border-red-500 hover:bg-red-900/10 transition-all group min-h-[200px] gap-3">
                <div className="w-12 h-12 rounded-2xl bg-slate-700 group-hover:bg-red-900/50 flex items-center justify-center text-slate-500 group-hover:text-red-400 text-2xl transition-all">+</div>
                <div className="text-center"><div className="font-semibold text-slate-400 group-hover:text-red-300 transition-colors">Add Tenant</div><div className="text-xs text-slate-500 mt-0.5">Connect another CPI environment</div></div>
              </div>
            </div>
          </div>
        )}

        {/* ABOUT TAB */}
        {tab==="about"&&(
          <div className="max-w-2xl mx-auto">
            <div className="bg-slate-800 rounded-3xl border border-slate-700 overflow-hidden">

              {/* Hero Header */}
              <div style={{background:"linear-gradient(135deg,#FF000F 0%,#cc0000 60%,#7f0000 100%)",padding:"40px 32px 32px",textAlign:"center",position:"relative",overflow:"hidden"}}>
                {/* Background glow circles */}
                <div style={{position:"absolute",top:-40,left:-40,width:160,height:160,borderRadius:"50%",background:"rgba(255,255,255,0.05)",pointerEvents:"none"}}/>
                <div style={{position:"absolute",bottom:-30,right:-30,width:120,height:120,borderRadius:"50%",background:"rgba(0,0,0,0.15)",pointerEvents:"none"}}/>

                {/* Logo */}
                <div style={{width:80,height:80,background:"rgba(255,255,255,0.15)",borderRadius:20,display:"flex",alignItems:"center",justifyContent:"center",margin:"0 auto 16px",fontSize:40,boxShadow:"0 8px 32px rgba(0,0,0,0.3)",border:"1px solid rgba(255,255,255,0.2)"}}>🚀</div>
                <h2 style={{color:"white",margin:"0 0 6px",fontSize:28,fontWeight:900,letterSpacing:2,textShadow:"0 2px 8px rgba(0,0,0,0.4)"}}>SAP CPI TRANSPORTER</h2>
                <p style={{color:"rgba(255,255,255,0.8)",margin:"0 0 16px",fontSize:13}}>SAP Integration Suite · iFlow Transport Tool</p>
                <div style={{display:"inline-flex",alignItems:"center",gap:8,background:"rgba(0,0,0,0.25)",padding:"6px 18px",borderRadius:24,border:"1px solid rgba(255,255,255,0.15)"}}>
                  <span style={{width:8,height:8,borderRadius:"50%",background:"#22c55e",display:"inline-block",boxShadow:"0 0 6px #22c55e"}}/>
                  <span style={{color:"white",fontSize:12,fontWeight:700,letterSpacing:1}}>LIVE ON SAP BTP</span>
                </div>
              </div>

              <div style={{padding:"28px 28px"}}>

                {/* Info Grid */}
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:28}}>
                  {[
                    {label:"Version",value:"1.0.0",icon:"🏷️"},
                    {label:"Platform",value:"SAP BTP Cloud Foundry",icon:"☁️"},
                    {label:"Backend",value:"Python FastAPI",icon:"⚙️"},
                    {label:"Frontend",value:"React + TailwindCSS",icon:"🎨"},
                    {label:"Region",value:"Singapore Azure (ap21)",icon:"🌏"},
                    {label:"Status",value:"● Live & Running",icon:"✅",color:"#22c55e"},
                  ].map((item,i)=>(
                    <div key={i} style={{background:"rgba(255,255,255,0.04)",border:"1px solid #1e293b",borderRadius:12,padding:"14px 16px",display:"flex",alignItems:"center",gap:10,transition:"all 0.2s"}}>
                      <span style={{fontSize:18}}>{item.icon}</span>
                      <div>
                        <div style={{color:"#475569",fontSize:9,marginBottom:3,textTransform:"uppercase",letterSpacing:1.2,fontWeight:700}}>{item.label}</div>
                        <div style={{color:item.color||"#f1f5f9",fontWeight:700,fontSize:13}}>{item.value}</div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Developer Card - Special Section */}
                <div style={{
                  background:"linear-gradient(135deg,rgba(255,0,15,0.08),rgba(127,0,0,0.12))",
                  border:"1px solid rgba(255,0,15,0.3)",
                  borderRadius:16,padding:"28px 24px",marginBottom:24,textAlign:"center",
                  position:"relative",overflow:"hidden"
                }}>
                  {/* Decorative top bar */}
                  <div style={{position:"absolute",top:0,left:0,right:0,height:3,background:"linear-gradient(90deg,#FF000F,#ff6b35,#FF000F)"}}/>

                  <div style={{fontSize:11,color:"#FF000F",fontWeight:700,letterSpacing:2,textTransform:"uppercase",marginBottom:16}}>⭐ Designed & Developed By</div>

                  {/* Avatar with ring */}
                  <div style={{position:"relative",width:80,height:80,margin:"0 auto 14px"}}>
                    <div style={{
                      width:80,height:80,
                      background:"linear-gradient(145deg,#FF000F,#7f0000)",
                      borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",
                      fontSize:28,fontWeight:900,color:"white",
                      boxShadow:"0 0 0 3px #1e293b,0 0 0 6px rgba(255,0,15,0.4),0 8px 24px rgba(255,0,15,0.3)",
                    }}>SP</div>
                    <div style={{position:"absolute",bottom:2,right:2,width:18,height:18,background:"#22c55e",borderRadius:"50%",border:"3px solid #1e293b",display:"flex",alignItems:"center",justifyContent:"center",fontSize:9}}>✔</div>
                  </div>

                  <div style={{color:"white",fontWeight:900,fontSize:22,marginBottom:2,letterSpacing:0.5}}>Sagar Reddy Pushpagiri</div>
                  <div style={{color:"#FF000F",fontWeight:700,fontSize:13,marginBottom:12,letterSpacing:0.5}}>SAP CPI Developer & Solution Architect</div>

                  {/* Skill Tags */}
                  <div style={{display:"flex",gap:8,flexWrap:"wrap",justifyContent:"center",marginBottom:16}}>
                    {["SAP Integration Suite","Python","React","Cloud Foundry","OAuth2","REST API"].map((skill,i)=>(
                      <span key={i} style={{
                        background:"rgba(255,0,15,0.12)",
                        border:"1px solid rgba(255,0,15,0.25)",
                        padding:"3px 10px",borderRadius:20,
                        color:"#ff9999",fontSize:11,fontWeight:600
                      }}>{skill}</span>
                    ))}
                  </div>

                  {/* Contact */}
                  <div style={{display:"flex",gap:8,flexWrap:"wrap",justifyContent:"center"}}>
                    <span style={{background:"rgba(255,255,255,0.06)",padding:"5px 14px",borderRadius:20,color:"#94a3b8",fontSize:11,display:"flex",alignItems:"center",gap:5}}>
                      📧 sagar.reddy@in.abb.com
                    </span>
                    <span style={{background:"rgba(255,255,255,0.06)",padding:"5px 14px",borderRadius:20,color:"#94a3b8",fontSize:11,display:"flex",alignItems:"center",gap:5}}>
                      🏢 ABB · India
                    </span>
                  </div>

                  {/* Special Quote */}
                  <div style={{marginTop:20,padding:"12px 16px",background:"rgba(0,0,0,0.2)",borderRadius:10,borderLeft:"3px solid #FF000F"}}>
                    <p style={{color:"#94a3b8",fontSize:12,margin:0,fontStyle:"italic",lineHeight:1.6}}>
                      "Built to simplify SAP CPI iFlow transport management — from development to production with full approval governance."
                    </p>
                  </div>
                </div>

                {/* Features */}
                <h4 style={{color:"white",marginBottom:12,fontSize:14,fontWeight:700,display:"flex",alignItems:"center",gap:8}}>✨ Features</h4>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:24}}>
                  {[
                    {icon:"🔄",text:"Multi-tenant iFlow transport"},
                    {icon:"🔴",text:"Production approval workflow"},
                    {icon:"📧",text:"Email notifications"},
                    {icon:"📊",text:"Real-time progress monitoring"},
                    {icon:"🔍",text:"Security pre-flight checks"},
                    {icon:"📋",text:"Job history & tracking"},
                    {icon:"🖱️",text:"Drag & drop tenant management"},
                    {icon:"☁️",text:"SAP BTP Cloud Foundry hosted"},
                  ].map((f,i)=>(
                    <div key={i} style={{display:"flex",alignItems:"center",gap:8,background:"rgba(255,255,255,0.03)",borderRadius:8,padding:"9px 12px",border:"1px solid rgba(255,255,255,0.05)"}}>
                      <span style={{fontSize:14}}>{f.icon}</span>
                      <span style={{color:"#94a3b8",fontSize:12}}>{f.text}</span>
                    </div>
                  ))}
                </div>

                {/* Deployment URLs */}
                <h4 style={{color:"white",marginBottom:12,fontSize:14,fontWeight:700}}>🌐 Deployment URLs</h4>
                <div style={{background:"rgba(0,0,0,0.35)",borderRadius:12,padding:"14px 18px",fontFamily:"monospace",fontSize:11,lineHeight:2.2,border:"1px solid #1e293b"}}>
                  <div style={{display:"flex",alignItems:"center",gap:8}}>
                    <span style={{background:"#22c55e",color:"white",padding:"1px 8px",borderRadius:4,fontSize:10,fontWeight:700}}>UI</span>
                    <span style={{color:"#64748b",wordBreak:"break-all"}}>cpi-transporter-frontend.cfapps.ap21.hana.ondemand.com</span>
                  </div>
                  <div style={{display:"flex",alignItems:"center",gap:8}}>
                    <span style={{background:"#3b82f6",color:"white",padding:"1px 8px",borderRadius:4,fontSize:10,fontWeight:700}}>API</span>
                    <span style={{color:"#64748b",wordBreak:"break-all"}}>cpi-transporter.cfapps.ap21.hana.ondemand.com</span>
                  </div>
                </div>

              </div>

              {/* Footer */}
              <div style={{borderTop:"1px solid #1e293b",padding:"16px 28px",textAlign:"center",background:"#0a1220"}}>
                <p style={{color:"#334155",margin:0,fontSize:11,letterSpacing:0.3}}>
                  Designed & Developed by <strong style={{color:"#FF000F"}}>Sagar Reddy Pushpagiri</strong> · ABB · SAP Integration Suite · 2026
                </p>
              </div>
            </div>
          </div>
        )}

        {/* ═══════════ ADMIN PORTAL TAB ═══════════ */}
        {tab==="admin"&&(
          <div>
          {!adminToken||!adminInfo?(
            /* ── ADMIN LOGIN ──────────────────── */
            <div style={{display:"flex",alignItems:"center",justifyContent:"center",minHeight:"70vh"}}>
              <div style={{background:"#1e293b",border:"1px solid #334155",borderRadius:20,
                           padding:40,width:360,maxWidth:"92%",textAlign:"center"}}>
                <div style={{fontSize:52,marginBottom:12}}>🔐</div>
                <div style={{fontWeight:900,fontSize:22,color:"white",marginBottom:4}}>Admin Portal</div>
                <div style={{fontSize:13,color:"#64748b",marginBottom:28}}>Sign in to manage approvals & users</div>
                {adminLoginErr&&(
                  <div style={{background:"rgba(239,68,68,0.12)",border:"1px solid #ef4444",
                               borderRadius:8,padding:"8px 14px",color:"#f87171",fontSize:12,
                               marginBottom:16,textAlign:"left"}}>{adminLoginErr}</div>
                )}
                <input value={adminLoginCreds.username}
                  onChange={e=>setAdminLoginCreds(c=>({...c,username:e.target.value}))}
                  placeholder="Username (default: admin)"
                  style={{width:"100%",background:"#0f172a",border:"1px solid #334155",
                          borderRadius:10,padding:"11px 14px",color:"white",fontSize:14,
                          marginBottom:10,boxSizing:"border-box"}}/>
                <input type="password" value={adminLoginCreds.password}
                  onChange={e=>setAdminLoginCreds(c=>({...c,password:e.target.value}))}
                  onKeyDown={e=>e.key==="Enter"&&loginAdmin()}
                  placeholder="Password (default: admin123)"
                  style={{width:"100%",background:"#0f172a",border:"1px solid #334155",
                          borderRadius:10,padding:"11px 14px",color:"white",fontSize:14,
                          marginBottom:18,boxSizing:"border-box"}}/>
                <button onClick={loginAdmin} disabled={adminBusy}
                  style={{width:"100%",padding:"13px",background:"linear-gradient(135deg,#FF000F,#cc0000)",
                          border:"none",borderRadius:10,color:"white",fontWeight:900,
                          fontSize:15,cursor:adminBusy?"not-allowed":"pointer",
                          opacity:adminBusy?0.7:1}}>
                  {adminBusy?"Signing in…":"Sign In →"}
                </button>
                <div style={{color:"#475569",fontSize:11,marginTop:16}}>
                  Change credentials via ADMIN_USER / ADMIN_PASS env vars in manifest.yml
                </div>
              </div>
            </div>
          ):(
            /* ── ADMIN PORTAL MAIN ─────────────── */
            <div style={{display:"flex",gap:0,minHeight:"80vh"}}>

              {/* SIDEBAR */}
              <div style={{width:200,flexShrink:0,background:"#1e293b",borderRight:"1px solid #334155",
                           padding:"20px 0"}}>
                <div style={{padding:"0 16px 16px",borderBottom:"1px solid #334155",marginBottom:16}}>
                  <div style={{fontSize:11,color:"#475569",fontWeight:700,textTransform:"uppercase",
                               letterSpacing:1,marginBottom:6}}>Admin Portal</div>
                  <div style={{color:"#e2e8f0",fontWeight:700,fontSize:14}}>{adminInfo.username}</div>
                  <div style={{display:"inline-flex",alignItems:"center",gap:4,background:"rgba(255,0,15,0.15)",
                               border:"1px solid rgba(255,0,15,0.3)",borderRadius:20,
                               padding:"2px 8px",marginTop:4}}>
                    <span style={{color:"#FF000F",fontSize:10,fontWeight:700,textTransform:"uppercase"}}>
                      {adminInfo.role}
                    </span>
                  </div>
                </div>
                {[
                  {id:"pending",  icon:"🔔", label:"Pending",  badge: adminStats.pending},
                  {id:"archived", icon:"🗄",  label:"Archived", badge: null},
                  {id:"history",  icon:"📋",  label:"Job History", badge: null},
                  {id:"users",    icon:"👥",  label:"Users",    badge: null},
                ].map(s=>(
                  <button key={s.id} onClick={()=>setAdminSection(s.id)}
                    style={{
                      width:"100%",textAlign:"left",padding:"11px 16px",
                      background:adminSection===s.id?"rgba(255,0,15,0.12)":"transparent",
                      border:"none",borderLeft:adminSection===s.id?"3px solid #FF000F":"3px solid transparent",
                      color:adminSection===s.id?"#ff9999":"#94a3b8",
                      cursor:"pointer",fontSize:13,fontWeight:adminSection===s.id?700:500,
                      display:"flex",alignItems:"center",justifyContent:"space-between",
                      transition:"all .15s",
                    }}>
                    <span>{s.icon} {s.label}</span>
                    {s.badge>0&&(
                      <span style={{background:"#FF000F",color:"white",borderRadius:10,
                                    padding:"1px 7px",fontSize:10,fontWeight:900}}>{s.badge}</span>
                    )}
                  </button>
                ))}
                <div style={{padding:"12px 16px",marginTop:"auto",borderTop:"1px solid #334155",position:"absolute",bottom:0,width:200,boxSizing:"border-box"}}>
                  <button onClick={()=>{setShowChangePw(true);setPwMsg({text:"",type:""});setPwForm({current:"",new_:"",confirm:""}); }}
                    style={{width:"100%",padding:"8px",background:"rgba(96,165,250,0.1)",
                            border:"1px solid rgba(96,165,250,0.3)",borderRadius:8,color:"#60a5fa",
                            cursor:"pointer",fontSize:12,fontWeight:600,marginBottom:6}}>
                    🔑 Change Password
                  </button>
                  <button onClick={()=>{setShowChangePin(true);setPinMsg({text:"",type:""});setPinForm({current:"",new_:"",confirm:""}); }}
                    style={{width:"100%",padding:"8px",background:"rgba(167,139,250,0.1)",
                            border:"1px solid rgba(167,139,250,0.3)",borderRadius:8,color:"#a78bfa",
                            cursor:"pointer",fontSize:12,fontWeight:600,marginBottom:6}}>
                    🔒 Change PIN
                  </button>
                  <button onClick={adminLogout}
                    style={{width:"100%",padding:"8px",background:"rgba(239,68,68,0.1)",
                            border:"1px solid rgba(239,68,68,0.3)",borderRadius:8,color:"#f87171",
                            cursor:"pointer",fontSize:12,fontWeight:600}}>
                    ⏏ Sign Out
                  </button>
                </div>
              </div>

              {/* CONTENT */}
              <div style={{flex:1,padding:"24px 28px",overflow:"auto"}}>

                {/* ── PENDING APPROVALS ── */}
                {adminSection==="pending"&&(
                  <div>
                    <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:20}}>
                      <div>
                        <h2 style={{color:"white",margin:0,fontSize:22,fontWeight:900}}>🔔 Pending Approvals</h2>
                        <p style={{color:"#64748b",margin:"4px 0 0",fontSize:13}}>
                          Notifications auto-archive after 3 days if not acted upon
                        </p>
                      </div>
                      <button onClick={loadAdminData}
                        style={{padding:"7px 14px",background:"#334155",border:"1px solid #475569",
                                borderRadius:8,color:"#94a3b8",cursor:"pointer",fontSize:12}}>
                        ↻ Refresh
                      </button>
                    </div>

                    {/* Stats bar */}
                    <div style={{display:"flex",gap:12,marginBottom:24,flexWrap:"wrap"}}>
                      {[
                        {label:"Pending",  val:adminStats.pending,  color:"#f59e0b"},
                        {label:"Approved", val:adminStats.approved, color:"#22c55e"},
                        {label:"Rejected", val:adminStats.rejected, color:"#ef4444"},
                        {label:"Archived", val:adminStats.archived, color:"#64748b"},
                      ].map(s=>(
                        <div key={s.label} style={{background:"#1e293b",border:`1px solid ${s.color}33`,
                                                   borderRadius:12,padding:"12px 20px",minWidth:110,textAlign:"center"}}>
                          <div style={{fontSize:24,fontWeight:900,color:s.color}}>{s.val}</div>
                          <div style={{fontSize:11,color:"#64748b",fontWeight:600,textTransform:"uppercase",letterSpacing:0.5}}>{s.label}</div>
                        </div>
                      ))}
                    </div>

                    {allNotifs.filter(n=>n.status==="PENDING").length===0?(
                      <div style={{textAlign:"center",padding:"60px 20px",color:"#475569"}}>
                        <div style={{fontSize:48,marginBottom:12}}>✅</div>
                        <div style={{fontSize:18,fontWeight:700,color:"#64748b"}}>No pending approvals</div>
                        <div style={{fontSize:13,marginTop:6}}>All transports are approved or archived</div>
                      </div>
                    ):(
                      <div style={{display:"flex",flexDirection:"column",gap:14}}>
                        {allNotifs.filter(n=>n.status==="PENDING").map(n=>{
                          const exp = new Date(n.expires_at);
                          const now = new Date();
                          const msLeft = exp - now;
                          const dLeft  = Math.max(0, Math.floor(msLeft/86400000));
                          const hLeft  = Math.max(0, Math.floor((msLeft%86400000)/3600000));
                          const urgent = dLeft < 1;
                          return (
                            <div key={n.id} style={{
                              background:"#1e293b",border:`1px solid ${urgent?"#f59e0b":"#334155"}`,
                              borderRadius:14,overflow:"hidden",
                            }}>
                              <div style={{background:urgent?"rgba(245,158,11,0.08)":"rgba(255,0,15,0.05)",
                                           padding:"14px 20px",borderBottom:"1px solid #334155",
                                           display:"flex",alignItems:"center",justifyContent:"space-between",flexWrap:"wrap",gap:8}}>
                                <div style={{display:"flex",alignItems:"center",gap:12}}>
                                  <div style={{background:"rgba(255,0,15,0.15)",border:"1px solid rgba(255,0,15,0.3)",
                                               borderRadius:8,padding:"6px 12px"}}>
                                    <div style={{color:"#FF000F",fontWeight:900,fontFamily:"monospace",fontSize:13}}>{n.transport_id}</div>
                                  </div>
                                  <div>
                                    <div style={{color:"white",fontWeight:700,fontSize:15}}>{n.package_name}</div>
                                    <div style={{color:"#64748b",fontSize:12}}>by {n.requested_by||"user"} · {new Date(n.created_at).toLocaleString()}</div>
                                  </div>
                                </div>
                                <div style={{display:"flex",alignItems:"center",gap:8}}>
                                  <div style={{background:urgent?"rgba(245,158,11,0.15)":"rgba(100,116,139,0.15)",
                                               border:`1px solid ${urgent?"#f59e0b":"#475569"}`,
                                               borderRadius:8,padding:"5px 12px",
                                               color:urgent?"#f59e0b":"#94a3b8",fontSize:12,fontWeight:700}}>
                                    ⏱ {dLeft}d {hLeft}h left
                                  </div>
                                  <span style={{background:"rgba(245,158,11,0.15)",border:"1px solid #f59e0b33",
                                                borderRadius:20,padding:"3px 10px",color:"#f59e0b",
                                                fontSize:11,fontWeight:700}}>⏳ PENDING</span>
                                </div>
                              </div>
                              <div style={{padding:"14px 20px",display:"flex",gap:24,flexWrap:"wrap"}}>
                                <div style={{flex:1,minWidth:200}}>
                                  <div style={{display:"flex",gap:16,marginBottom:10}}>
                                    <div style={{textAlign:"center"}}>
                                      <div style={{fontSize:10,color:"#475569",fontWeight:700,textTransform:"uppercase",letterSpacing:0.5}}>Source</div>
                                      <div style={{color:"#3b82f6",fontWeight:700,fontSize:13,marginTop:2}}>{n.source}</div>
                                    </div>
                                    <div style={{color:"#475569",fontSize:18,alignSelf:"center"}}>→</div>
                                    <div style={{textAlign:"center"}}>
                                      <div style={{fontSize:10,color:"#475569",fontWeight:700,textTransform:"uppercase",letterSpacing:0.5}}>Target</div>
                                      <div style={{color:"#FF000F",fontWeight:900,fontSize:13,marginTop:2}}>{n.target} 🎯</div>
                                    </div>
                                  </div>
                                  <div style={{fontSize:12,color:"#64748b"}}>
                                    <b style={{color:"#94a3b8"}}>iFlows ({(n.iflows||[]).length}):</b>{" "}
                                    <span style={{color:"#7dd3fc"}}>{(n.iflows||[]).slice(0,3).join(", ")}{(n.iflows||[]).length>3?` +${(n.iflows||[]).length-3} more`:""}</span>
                                  </div>
                                </div>
                                <div style={{display:"flex",gap:10,alignItems:"center",flexShrink:0}}>
                                  <button onClick={()=>adminApprove(n.id)} disabled={adminBusy}
                                    style={{padding:"10px 22px",background:"linear-gradient(135deg,#16a34a,#15803d)",
                                            border:"none",borderRadius:10,color:"white",fontWeight:900,
                                            fontSize:14,cursor:"pointer",opacity:adminBusy?0.6:1}}>
                                    ✅ Approve
                                  </button>
                                  <button onClick={()=>setRejectTarget(n)} disabled={adminBusy}
                                    style={{padding:"10px 22px",background:"rgba(239,68,68,0.15)",
                                            border:"1px solid #ef4444",borderRadius:10,color:"#f87171",
                                            fontWeight:700,fontSize:14,cursor:"pointer",opacity:adminBusy?0.6:1}}>
                                    ❌ Reject
                                  </button>
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}

                {/* ── ARCHIVED ── */}
                {adminSection==="archived"&&(
                  <div>
                    <h2 style={{color:"white",margin:"0 0 20px",fontSize:22,fontWeight:900}}>🗄 Archived Notifications</h2>
                    <div style={{display:"flex",flexDirection:"column",gap:10}}>
                      {allNotifs.filter(n=>n.status!=="PENDING").length===0?(
                        <div style={{textAlign:"center",padding:"60px 20px",color:"#475569"}}>
                          <div style={{fontSize:40,marginBottom:10}}>🗄</div>
                          <div style={{fontWeight:700,color:"#64748b"}}>No archived notifications</div>
                        </div>
                      ):(
                        allNotifs.filter(n=>n.status!=="PENDING").map(n=>{
                          const statusColor={APPROVED:"#22c55e",REJECTED:"#ef4444",ARCHIVED:"#64748b",EXPIRED:"#64748b"}[n.status]||"#94a3b8";
                          return(
                            <div key={n.id} style={{background:"#1e293b",border:"1px solid #334155",
                                                     borderRadius:12,padding:"14px 20px",
                                                     display:"flex",alignItems:"center",gap:16,flexWrap:"wrap"}}>
                              <div style={{flex:1,minWidth:200}}>
                                <div style={{display:"flex",gap:8,alignItems:"center",marginBottom:4}}>
                                  <span style={{fontFamily:"monospace",color:"#FF000F",fontWeight:700,fontSize:12}}>{n.transport_id}</span>
                                  <span style={{background:`${statusColor}22`,border:`1px solid ${statusColor}55`,
                                                borderRadius:20,padding:"1px 8px",color:statusColor,
                                                fontSize:10,fontWeight:700}}>{n.status}</span>
                                </div>
                                <div style={{color:"#e2e8f0",fontWeight:600,fontSize:14}}>{n.package_name}</div>
                                <div style={{color:"#475569",fontSize:11,marginTop:2}}>
                                  {n.source} → {n.target} · {(n.iflows||[]).length} iFlows
                                  {n.approved_by&&<span> · Approved by <b style={{color:"#22c55e"}}>{n.approved_by}</b></span>}
                                  {n.rejected_by&&<span> · Rejected by <b style={{color:"#ef4444"}}>{n.rejected_by}</b></span>}
                                  {n.reject_reason&&<span> · "{n.reject_reason}"</span>}
                                </div>
                              </div>
                              <div style={{color:"#475569",fontSize:11,textAlign:"right",flexShrink:0}}>
                                <div>Created: {new Date(n.created_at).toLocaleString()}</div>
                                {n.approved_at&&<div style={{color:"#22c55e"}}>Approved: {new Date(n.approved_at).toLocaleString()}</div>}
                                {n.rejected_at&&<div style={{color:"#ef4444"}}>Rejected: {new Date(n.rejected_at).toLocaleString()}</div>}
                                {n.job_id&&<div style={{color:"#60a5fa"}}>Job: {n.job_id.slice(0,8)}…</div>}
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>
                )}

                {/* ── JOB HISTORY ── */}
                {adminSection==="history"&&(
                  <div>
                    <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:20}}>
                      <div>
                        <h2 style={{color:"white",margin:0,fontSize:22,fontWeight:900}}>📋 Job History</h2>
                        <p style={{color:"#64748b",margin:"4px 0 0",fontSize:13}}>Jobs auto-archive after 30 days</p>
                      </div>
                      <button onClick={()=>fetch(`${API}/jobs`).then(r=>r.json()).then(d=>setJobs(Array.isArray(d)?d:(d.jobs||[])))}
                        style={{padding:"7px 14px",background:"#334155",border:"1px solid #475569",
                                borderRadius:8,color:"#94a3b8",cursor:"pointer",fontSize:12}}>↻ Refresh</button>
                    </div>
                    {jobs.length===0?(
                      <div style={{textAlign:"center",padding:"60px 20px",color:"#475569"}}>
                        <div style={{fontSize:40,marginBottom:10}}>📋</div>
                        <div style={{fontWeight:700,color:"#64748b"}}>No jobs yet</div>
                      </div>
                    ):(
                      <div style={{display:"flex",flexDirection:"column",gap:8}}>
                        {jobs.map(j=>{
                          const dLeft = j.days_until_archive||0;
                          const isArch = j.archived;
                          const sColor={complete:"#22c55e",error:"#ef4444",running:"#3b82f6",queued:"#8b5cf6"}[j.status]||"#64748b";
                          return(
                            <div key={j.id} style={{background:isArch?"#0f172a":"#1e293b",
                                                     border:`1px solid ${isArch?"#1e293b":"#334155"}`,
                                                     borderRadius:12,padding:"12px 18px",
                                                     opacity:isArch?0.6:1,
                                                     display:"flex",alignItems:"center",gap:12,flexWrap:"wrap"}}>
                              <span style={{fontFamily:"monospace",color:"#64748b",fontSize:11,
                                             minWidth:80}}>{j.id?.slice(0,8)}…</span>
                              <span style={{background:`${sColor}22`,border:`1px solid ${sColor}55`,
                                            borderRadius:20,padding:"2px 10px",color:sColor,
                                            fontSize:11,fontWeight:700}}>{j.status?.toUpperCase()}</span>
                              <div style={{flex:1,minWidth:140}}>
                                <div style={{fontSize:12,color:"#94a3b8",fontWeight:600}}>
                                  {j.source} → {j.target}
                                </div>
                                <div style={{fontSize:11,color:"#475569"}}>
                                  {j.created_at&&new Date(j.created_at).toLocaleString()}
                                </div>
                              </div>
                              <div style={{width:100}}>
                                <div style={{height:4,background:"#334155",borderRadius:4,overflow:"hidden"}}>
                                  <div style={{height:4,width:`${j.progress||0}%`,
                                               background:j.progress===100?"#22c55e":"#FF000F",
                                               borderRadius:4,transition:"width .3s"}}/>
                                </div>
                                <div style={{fontSize:10,color:"#475569",textAlign:"right",marginTop:2}}>{j.progress||0}%</div>
                              </div>
                              <div style={{fontSize:10,textAlign:"right",flexShrink:0,
                                           color:isArch?"#334155":dLeft<5?"#f59e0b":"#475569"}}>
                                {isArch?"📦 Archived":`📦 in ${dLeft}d`}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}

                {/* ── USER MANAGEMENT ── */}
                {adminSection==="users"&&(
                  <div>
                    <h2 style={{color:"white",margin:"0 0 20px",fontSize:22,fontWeight:900}}>👥 User Management</h2>

                    {/* Add User Form */}
                    {adminInfo.role==="admin"&&(
                      <div style={{background:"#1e293b",border:"1px solid #334155",borderRadius:14,
                                   padding:20,marginBottom:24}}>
                        <div style={{fontWeight:700,color:"#94a3b8",fontSize:13,marginBottom:14,
                                     display:"flex",alignItems:"center",gap:6}}>
                          ➕ Add New User
                        </div>
                        <div style={{display:"flex",gap:10,flexWrap:"wrap",alignItems:"flex-end"}}>
                          {[
                            {key:"username",ph:"Username",type:"text"},
                            {key:"password",ph:"Password",type:"password"},
                            {key:"email",ph:"Email (optional)",type:"email"},
                          ].map(f=>(
                            <input key={f.key} type={f.type} value={newUser[f.key]}
                              onChange={e=>setNewUser(u=>({...u,[f.key]:e.target.value}))}
                              placeholder={f.ph}
                              style={{flex:1,minWidth:140,background:"#0f172a",border:"1px solid #334155",
                                      borderRadius:8,padding:"9px 12px",color:"white",fontSize:13,boxSizing:"border-box"}}/>
                          ))}
                          <select value={newUser.role} onChange={e=>setNewUser(u=>({...u,role:e.target.value}))}
                            style={{background:"#0f172a",border:"1px solid #334155",borderRadius:8,
                                    padding:"9px 12px",color:"white",fontSize:13}}>
                            <option value="viewer">Viewer</option>
                            <option value="approver">Approver</option>
                            <option value="admin">Admin</option>
                          </select>
                          <button onClick={adminAddUser} disabled={adminBusy}
                            style={{padding:"9px 20px",background:"linear-gradient(135deg,#FF000F,#cc0000)",
                                    border:"none",borderRadius:8,color:"white",fontWeight:700,
                                    cursor:"pointer",fontSize:13,whiteSpace:"nowrap"}}>
                            + Add User
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Users Table */}
                    <div style={{background:"#1e293b",border:"1px solid #334155",borderRadius:14,overflow:"hidden"}}>
                      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr auto",
                                   padding:"10px 16px",background:"#0f172a",
                                   fontSize:11,color:"#475569",fontWeight:700,textTransform:"uppercase",letterSpacing:0.5}}>
                        <div>Username</div><div>Email</div><div>Role</div><div>Actions</div>
                      </div>
                      {adminUsers.map((u,i)=>(
                        <div key={u.username} style={{
                          display:"grid",gridTemplateColumns:"1fr 1fr 1fr auto",
                          padding:"12px 16px",alignItems:"center",gap:8,
                          borderTop:i>0?"1px solid #1e293b":"none",
                          background:i%2===0?"#1e293b":"rgba(15,23,42,0.4)",
                        }}>
                          <div style={{display:"flex",alignItems:"center",gap:8}}>
                            <div style={{width:28,height:28,borderRadius:"50%",
                                         background:"linear-gradient(135deg,#FF000F,#7f0000)",
                                         display:"flex",alignItems:"center",justifyContent:"center",
                                         color:"white",fontWeight:900,fontSize:11}}>
                              {u.username.charAt(0).toUpperCase()}
                            </div>
                            <span style={{color:"#e2e8f0",fontWeight:600,fontSize:13}}>{u.username}</span>
                          </div>
                          <div style={{color:"#64748b",fontSize:12}}>{u.email||"—"}</div>
                          <div>
                            {adminInfo.role==="admin"&&u.username!=="admin"?(
                              <select value={u.role}
                                onChange={e=>adminChangeRole(u.username,e.target.value)}
                                style={{background:"#0f172a",border:"1px solid #334155",
                                        borderRadius:6,padding:"4px 8px",color:"white",fontSize:12}}>
                                <option value="viewer">Viewer</option>
                                <option value="approver">Approver</option>
                                <option value="admin">Admin</option>
                              </select>
                            ):(
                              <span style={{background:u.role==="admin"?"rgba(255,0,15,0.15)":"rgba(59,130,246,0.15)",
                                             border:`1px solid ${u.role==="admin"?"#FF000F55":"#3b82f655"}`,
                                             borderRadius:20,padding:"3px 10px",
                                             color:u.role==="admin"?"#ff9999":"#60a5fa",
                                             fontSize:11,fontWeight:700,textTransform:"uppercase"}}>
                                {u.role}
                              </span>
                            )}
                          </div>
                          <div>
                            {adminInfo.role==="admin"&&u.username!=="admin"&&(
                              <button onClick={()=>adminDeleteUser(u.username)}
                                style={{background:"rgba(239,68,68,0.1)",border:"1px solid rgba(239,68,68,0.3)",
                                        borderRadius:6,color:"#f87171",padding:"5px 10px",
                                        cursor:"pointer",fontSize:11,fontWeight:600}}>
                                Remove
                              </button>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>

                    <div style={{marginTop:16,padding:"12px 16px",background:"rgba(59,130,246,0.06)",
                                 border:"1px solid rgba(59,130,246,0.2)",borderRadius:10,fontSize:12,color:"#64748b"}}>
                      💡 <b style={{color:"#94a3b8"}}>Roles:</b> Admin = full access · Approver = can approve/reject · Viewer = read only<br/>
                      Default admin password can be changed via <code style={{color:"#7dd3fc"}}>ADMIN_PASS</code> env var in manifest.yml
                    </div>
                  </div>
                )}

              </div>
            </div>
          )}

          {/* ── SECURITY SECTION ── */}
          {adminSection==="security"&&<SecurityPanel adminToken={adminToken} setAdminToken={setAdminToken}/>}

          </div>
        )}

      </main>

      {/* FOOTER - No name here, moved to About tab */}
      <footer style={{textAlign:"center",paddingTop:16,paddingBottom:16,borderTop:"1px solid #1e293b",background:"linear-gradient(180deg,#0a1628 0%,#0f172a 100%)"}}>
        <div style={{display:"flex",alignItems:"center",justifyContent:"center",gap:8}}>
          <div style={{width:26,height:26,borderRadius:8,background:"linear-gradient(145deg,#FF000F,#7f0000)",display:"flex",alignItems:"center",justifyContent:"center",boxShadow:"0 0 0 1px rgba(255,0,15,0.3)"}}>
            <span style={{fontSize:13}}>⚡</span>
          </div>
          <span style={{color:"#334155",fontSize:11}}>SAP CPI Transporter</span>
          <span style={{color:"#1e293b",fontSize:13}}>·</span>
          <span style={{color:"#1e293b",fontSize:11}}>SAP Integration Suite · iFlow Transport</span>
        </div>
      </footer>
    </div>
  );
}