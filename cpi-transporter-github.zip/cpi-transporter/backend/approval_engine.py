# ═══════════════════════════════════════════════════════════════
# approval_engine.py  —  SAP CPI Transporter  v5  (FIXED)
# Roles: admin > approver > developer > viewer
# Permissions:
#   admin    — everything
#   approver — approve/reject transports, view all
#   developer— start transports, manage tenants, view
#   viewer   — read-only view
# ═══════════════════════════════════════════════════════════════

import uuid, os, hashlib
from datetime import datetime, timedelta

# ── Stores ─────────────────────────────────────────────────────
notification_store = {}   # nid  → notification dict
approval_store     = notification_store
admin_sessions     = {}   # token → session dict
user_store         = {}   # username → user dict

# ── Env vars ───────────────────────────────────────────────────
_ADMIN_USER          = os.environ.get("ADMIN_USER",          "admin")
_ADMIN_PASS          = os.environ.get("ADMIN_PASS",          "admin123")
_ADMIN_EMAIL         = os.environ.get("ADMIN_EMAIL",         "sagar.reddy@in.abb.com")
APPROVAL_PORTAL_PIN  = os.environ.get("APPROVAL_PORTAL_PIN", "cpi1234")

NOTIFICATION_TTL_DAYS = 3
JOB_LOG_RETAIN_DAYS   = 60

# ── Role hierarchy ─────────────────────────────────────────────
VALID_ROLES = ["admin", "approver", "developer", "viewer"]

# Role permissions matrix
ROLE_PERMISSIONS = {
    "admin": {
        "can_view":          True,
        "can_transport":     True,  # start transport
        "can_manage_tenants":True,  # add/delete tenants
        "can_approve":       True,  # approve/reject
        "can_manage_users":  True,  # add/edit/delete users
        "can_view_logs":     True,
    },
    "approver": {
        "can_view":          True,
        "can_transport":     False, # cannot start transport (only approve)
        "can_manage_tenants":False,
        "can_approve":       True,  # CAN approve/reject
        "can_manage_users":  False,
        "can_view_logs":     True,
    },
    "developer": {
        "can_view":          True,
        "can_transport":     True,  # CAN start transport (needs approval for prod)
        "can_manage_tenants":True,  # CAN add/delete tenants
        "can_approve":       False, # CANNOT approve
        "can_manage_users":  False,
        "can_view_logs":     True,
    },
    "viewer": {
        "can_view":          True,
        "can_transport":     False,
        "can_manage_tenants":False,
        "can_approve":       False,
        "can_manage_users":  False,
        "can_view_logs":     True,
    },
}

def get_permissions(role: str) -> dict:
    return ROLE_PERMISSIONS.get(role, ROLE_PERMISSIONS["viewer"])

def _hash(pw: str) -> str:
    return hashlib.sha256(pw.encode()).hexdigest()

def _seed_admin():
    """Ensure default admin user always exists."""
    if _ADMIN_USER not in user_store:
        user_store[_ADMIN_USER] = {
            "id":            _ADMIN_USER,
            "username":      _ADMIN_USER,
            "password_hash": _hash(_ADMIN_PASS),
            "role":          "admin",
            "email":         _ADMIN_EMAIL,
            "created_at":    datetime.now().isoformat(),
        }

_seed_admin()


# ══════════════════════════════════════════════════════════════
# PORTAL PIN AUTH
# ══════════════════════════════════════════════════════════════

def verify_portal_pin(pin: str) -> bool:
    return str(pin).strip() == str(APPROVAL_PORTAL_PIN).strip()


# ══════════════════════════════════════════════════════════════
# ADMIN SESSION AUTH
# ══════════════════════════════════════════════════════════════

def admin_login(username: str, password: str) -> dict:
    _seed_admin()  # ensure default admin exists
    user = user_store.get(username)
    if not user or user["password_hash"] != _hash(password):
        raise ValueError("Invalid username or password")
    token = str(uuid.uuid4())
    admin_sessions[token] = {
        "username":   username,
        "role":       user["role"],
        "created_at": datetime.now().isoformat(),
        "permissions": get_permissions(user["role"]),
    }
    return {
        "token":       token,
        "username":    username,
        "role":        user["role"],
        "permissions": get_permissions(user["role"]),
    }

def admin_verify(token: str):
    return admin_sessions.get(token)

def admin_logout(token: str):
    admin_sessions.pop(token, None)


# ══════════════════════════════════════════════════════════════
# USER MANAGEMENT
# ══════════════════════════════════════════════════════════════

def get_all_users() -> list:
    return [{k:v for k,v in u.items() if k != "password_hash"}
            for u in user_store.values()]

def add_user(username: str, password: str, role: str = "viewer", email: str = "") -> dict:
    if username in user_store:
        raise ValueError(f"User {username!r} already exists")
    if role not in VALID_ROLES:
        raise ValueError(f"Invalid role {role!r}. Must be one of: {VALID_ROLES}")
    user_store[username] = {
        "id":            username,
        "username":      username,
        "password_hash": _hash(password),
        "role":          role,
        "email":         email,
        "created_at":    datetime.now().isoformat(),
    }
    return {k:v for k,v in user_store[username].items() if k != "password_hash"}

def update_user(username: str, data: dict) -> dict:
    if username not in user_store:
        raise ValueError(f"User {username!r} not found")
    u = user_store[username]
    if "password" in data and data["password"]:
        u["password_hash"] = _hash(data["password"])
    if "role" in data:
        if data["role"] not in VALID_ROLES:
            raise ValueError(f"Invalid role: {data['role']!r}")
        u["role"] = data["role"]
        # Update active sessions for this user
        for sess in admin_sessions.values():
            if sess.get("username") == username:
                sess["role"] = data["role"]
                sess["permissions"] = get_permissions(data["role"])
    if "email" in data:
        u["email"] = data["email"]
    return {k:v for k,v in u.items() if k != "password_hash"}

def delete_user(username: str):
    if username == _ADMIN_USER:
        raise ValueError("Cannot delete default admin user")
    if username not in user_store:
        raise ValueError(f"User {username!r} not found")
    del user_store[username]
    # Invalidate sessions
    to_del = [t for t,s in admin_sessions.items() if s.get("username") == username]
    for t in to_del: del admin_sessions[t]


# ══════════════════════════════════════════════════════════════
# NOTIFICATIONS / APPROVAL WORKFLOW
# ══════════════════════════════════════════════════════════════

def create_notification(transport_id, package_name, source_tenant,
                        target_tenant, requested_by, iflows=None, extra=None) -> str:
    nid = str(uuid.uuid4())
    notification_store[nid] = {
        "id":             nid,
        "transport_id":   transport_id,
        "package_name":   package_name,
        "source_tenant":  source_tenant,
        "target_tenant":  target_tenant,
        "requested_by":   requested_by,
        "iflows":         iflows or [],
        "extra":          extra or {},
        "status":         "PENDING",
        "created_at":     datetime.now().isoformat(),
        "expires_at":     (datetime.now() + timedelta(days=NOTIFICATION_TTL_DAYS)).isoformat(),
        "job_id":         None,
        "approved_by":    None,
        "rejected_reason": None,
    }
    return nid

def get_notification(nid: str):
    return notification_store.get(nid)

def get_all_notifications() -> list:
    return list(notification_store.values())

def approve_notification(nid: str, approved_by: str = "portal"):
    n = notification_store.get(nid)
    if n:
        n["status"]      = "APPROVED"
        n["approved_by"] = approved_by
        n["approved_at"] = datetime.now().isoformat()

def reject_notification(nid: str, reason: str = "Rejected", rejected_by: str = "portal"):
    n = notification_store.get(nid)
    if n:
        n["status"]          = "REJECTED"
        n["rejected_reason"] = reason
        n["rejected_by"]     = rejected_by
        n["rejected_at"]     = datetime.now().isoformat()

def auto_archive_expired():
    now = datetime.now()
    for n in notification_store.values():
        if n.get("status") == "PENDING":
            expires = datetime.fromisoformat(n.get("expires_at","2099-01-01"))
            if now > expires:
                n["status"] = "ARCHIVED"


# ══════════════════════════════════════════════════════════════
# STATS
# ══════════════════════════════════════════════════════════════

def get_admin_stats() -> dict:
    notifs = list(notification_store.values())
    return {
        "pending":    sum(1 for n in notifs if n.get("status")=="PENDING"),
        "approved":   sum(1 for n in notifs if n.get("status")=="APPROVED"),
        "rejected":   sum(1 for n in notifs if n.get("status")=="REJECTED"),
        "archived":   sum(1 for n in notifs if n.get("status")=="ARCHIVED"),
        "total_jobs": len(notifs),
        "users":      len(user_store),
        "roles":      {r: sum(1 for u in user_store.values() if u.get("role")==r) for r in VALID_ROLES},
    }
