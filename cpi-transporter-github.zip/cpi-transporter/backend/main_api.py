# ═══════════════════════════════════════════════════════════════
# main_api_v2_final.py
# SAP CPI Transporter v2.0 — Full FastAPI Backend
# Designed & Developed by: Sagar Reddy Pushpagiri | ABB India
# Platform: SAP BTP Cloud Foundry | Python FastAPI + WebSocket
# ═══════════════════════════════════════════════════════════════

import os, uuid, json, asyncio, hashlib, logging, traceback
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
from contextlib import asynccontextmanager

import asyncio
import httpx
import uvicorn
from fastapi import (FastAPI, HTTPException, WebSocket, WebSocketDisconnect,
                     BackgroundTasks, Depends, Request, status)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel

from approval_engine_v2_final import (
    admin_login, admin_verify, admin_logout,
    get_all_users, add_user, update_user, delete_user,
    create_notification, get_notification,
    get_pending_notifications, get_all_notifications,
    get_notification_history, approve_notification, reject_notification,
    auto_archive_expired, purge_old_jobs, days_until_job_expiry,
    get_admin_stats, verify_portal_pin, get_permissions,
    notification_store, user_store, admin_sessions, _hash
)
import approval_engine_v2_final as _ae_mod  # for APPROVAL_PORTAL_PIN mutation

# ── Logging ─────────────────────────────────────────────────────
logging.basicConfig(level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s")
log = logging.getLogger("cpi-transporter")

# ── In-Memory Stores ────────────────────────────────────────────
TENANTS:   Dict[str, dict] = {
    "ABBCPI": {
        "key":           "ABBCPI",
        "label":         "ABBCPI",
        "host":          "abbcpi.it-cpi005.cfapps.eu20.hana.ondemand.com",
        "token_url":     "https://abbcpi.authentication.eu20.hana.ondemand.com/oauth/token",
        "client_id":     "sb-a10d842c-f570-4d0b-88ad-b7d2e1830329!b1822|it!b259",
        "client_secret": "937052dd-7b76-4fd7-91fb-565f39706efb$AlIAR0TghhM_TEQd2hwRigWe-SqkM2v6qdMn2BgfPUw=",
        "environment":   "Non-Production",
        "region":        "eu20"
    },
    "CAI04": {
        "key":           "CAI04",
        "label":         "CAI04",
        "host":          "cai04.it-cpi018.cfapps.eu10-003.hana.ondemand.com",
        "token_url":     "https://cai04.authentication.eu10.hana.ondemand.com/oauth/token",
        "client_id":     "sb-d2cd82a3-4436-40f3-be10-c77342c24e17!b97244|it!b117912",
        "client_secret": "70fd8f15-7b53-4c7f-972f-36693bf1e8d5$-tQeCs-5ekqPV14E_yQQhCwlI47_migpLMOAPLx18iI=",
        "environment":   "Non-Production",
        "region":        "eu10"
    }
}
JOBS:      Dict[str, dict] = {}
WS_CLIENTS: Dict[str, List[WebSocket]] = {}
SEC_PARAMS: Dict[str, List[dict]] = {}

bearer = HTTPBearer(auto_error=False)

# ══════════════════════════════════════════════════════════
# LIFESPAN
# ══════════════════════════════════════════════════════════
@asynccontextmanager
async def lifespan(app: FastAPI):
    log.info("🚀 SAP CPI Transporter v2.0 starting…")
    asyncio.create_task(_background_tasks())
    yield
    log.info("⛔ Shutting down…")

async def _background_tasks():
    while True:
        await asyncio.sleep(600)
        auto_archive_expired()
        purge_old_jobs(JOBS)

# ══════════════════════════════════════════════════════════
# APP
# ══════════════════════════════════════════════════════════
app = FastAPI(
    title="SAP CPI Transporter API v2.0",
    description="Real-time SAP CPI iFlow transport between BTP tenants",
    version="2.0.0",
    lifespan=lifespan
)
app.add_middleware(CORSMiddleware, allow_origins=["*"],
                   allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

# ══════════════════════════════════════════════════════════
# SCHEMAS
# ══════════════════════════════════════════════════════════
class TenantIn(BaseModel):
    key:           str
    label:         str
    host:          str
    token_url:     str
    client_id:     str
    client_secret: str
    environment:   str = "DEV"
    region:        str = "ap21"

class TransportRequest(BaseModel):
    source_tenant:           str
    target_tenant:           str
    package_ids:             List[str]
    iflow_ids:               Optional[List[str]] = None
    requested_by:            str = "admin"
    conflict_resolution:     str = "overwrite"
    deploy_after:            bool = False
    dry_run:                 bool = False
    validate_checksum:       bool = True
    auto_rollback:           bool = True
    include_security_params: bool = False
    notes:                   str = ""

class AdminLoginIn(BaseModel):
    username: str
    password: str

class ApproveIn(BaseModel):
    decided_by: str
    reason:     Optional[str] = None

class UserIn(BaseModel):
    username: str
    password: str
    role:     str = "viewer"
    email:    str = ""
    name:     str = ""

class UserUpdateIn(BaseModel):
    password: Optional[str] = None
    role:     Optional[str] = None
    email:    Optional[str] = None
    name:     Optional[str] = None
    active:   Optional[bool] = None

class SecParamIn(BaseModel):
    name:        str
    param_type:  str
    description: str = ""
    value:       Optional[str] = None

# ══════════════════════════════════════════════════════════
# AUTH DEPENDENCIES
# ══════════════════════════════════════════════════════════
async def get_session(creds: HTTPAuthorizationCredentials = Depends(bearer)) -> dict:
    token = creds.credentials if creds else None
    s = admin_verify(token) if token else None
    if not s:
        raise HTTPException(401, "Authentication required")
    return s

async def require_approve(sess = Depends(get_session)):
    if not sess["permissions"].get("approve") and sess["role"] not in ("admin","approver"):
        raise HTTPException(403, "Approver or Admin role required")
    return sess

async def require_admin(sess = Depends(get_session)):
    if sess["role"] != "admin":
        raise HTTPException(403, "Admin role required")
    return sess

async def require_transport(sess = Depends(get_session)):
    if not sess["permissions"].get("transport") and sess["role"] not in ("admin","developer"):
        raise HTTPException(403, "Developer or Admin role required")
    return sess

# ══════════════════════════════════════════════════════════
# HELPERS
# ══════════════════════════════════════════════════════════
def _jid() -> str:
    return "JOB-" + uuid.uuid4().hex[:10].upper()

def _tid() -> str:
    ts  = datetime.utcnow().strftime("%Y%m%d")
    seq = uuid.uuid4().hex[:6].upper()
    return f"TR{ts}{seq}"

async def _get_token(t: dict) -> str:
    # FIX: SAP CPI tokenurl already contains /oauth/token — don't double-append
    raw_url = (t.get("token_url") or t.get("tokenurl") or "").rstrip("/")
    if not raw_url:
        raise ValueError("token_url is missing for this tenant")
    # Smart: only append /oauth/token if NOT already present
    token_url = raw_url if raw_url.endswith("/oauth/token") else raw_url + "/oauth/token"

    client_id     = t.get("client_id")     or t.get("clientid",     "")
    client_secret = t.get("client_secret") or t.get("clientsecret", "")

    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.post(token_url,
                         data={"grant_type":"client_credentials"},
                         auth=(client_id, client_secret),
                         headers={"Content-Type":"application/x-www-form-urlencoded"})
        r.raise_for_status()
        return r.json()["access_token"]

def _base_url(t: dict) -> str:
    """FIX: Accept host with or without https:// prefix."""
    host = (t.get("host") or t.get("url") or "").rstrip("/")
    if host.startswith("http://") or host.startswith("https://"):
        return host  # already a full URL
    return f"https://{host}"

async def _cpi_get(t: dict, path: str) -> dict:
    tok = await _get_token(t)
    base = _base_url(t)
    async with httpx.AsyncClient(timeout=60) as c:
        r = await c.get(f"{base}/api/v1{path}",
                        headers={"Authorization":f"Bearer {tok}","Accept":"application/json"})
        r.raise_for_status()
        return r.json()

async def broadcast(job_id: str, msg: dict):
    clients = WS_CLIENTS.get(job_id, [])
    dead = []
    for ws in clients:
        try:
            await ws.send_json(msg)
        except:
            dead.append(ws)
    for ws in dead:
        try: clients.remove(ws)
        except: pass

# ══════════════════════════════════════════════════════════
# AUTH ENDPOINTS
# ══════════════════════════════════════════════════════════
@app.post("/api/auth/login")
async def login(data: AdminLoginIn):
    try:
        return admin_login(data.username, data.password)
    except ValueError as e:
        raise HTTPException(401, str(e))

@app.get("/api/auth/verify")
async def verify(sess = Depends(get_session)):
    return {"valid":True, "username":sess["username"],
            "role":sess["role"], "name":sess.get("name",""),
            "permissions":sess["permissions"]}

@app.post("/api/auth/logout")
async def logout(creds: HTTPAuthorizationCredentials = Depends(bearer)):
    if creds: admin_logout(creds.credentials)
    return {"message":"Logged out"}

# ══════════════════════════════════════════════════════════
# TENANT ENDPOINTS
# ══════════════════════════════════════════════════════════
@app.get("/api/tenants")
async def list_tenants():
    out = []
    for t in TENANTS.values():
        safe = dict(t); safe["client_secret"] = "***"
        out.append(safe)
    return {"tenants": out, "count": len(out)}

@app.post("/api/tenants", status_code=201)
async def add_tenant(cfg: TenantIn, sess = Depends(get_session)):
    if not sess["permissions"].get("manage_tenants"):
        raise HTTPException(403, "Permission denied")
    if cfg.key in TENANTS:
        raise HTTPException(400, f"Tenant '{cfg.key}' already exists")
    TENANTS[cfg.key] = cfg.dict()
    log.info(f"✅ Tenant added: {cfg.key}")
    return {"message":"Tenant added","key":cfg.key}

@app.put("/api/tenants/{key}")
async def update_tenant(key: str, cfg: TenantIn, sess = Depends(get_session)):
    if not sess["permissions"].get("manage_tenants"):
        raise HTTPException(403, "Permission denied")
    if key not in TENANTS:
        raise HTTPException(404, "Tenant not found")
    TENANTS[key] = cfg.dict()
    return {"message":"Updated","key":key}

@app.delete("/api/tenants/{key}")
async def del_tenant(key: str, sess = Depends(get_session)):
    if not sess["permissions"].get("manage_tenants"):
        raise HTTPException(403, "Permission denied")
    TENANTS.pop(key, None)
    return {"message":"Deleted"}

@app.post("/api/tenants/{key}/test")
async def test_tenant(key: str):
    if key not in TENANTS:
        raise HTTPException(404, "Tenant not found")
    try:
        tok = await _get_token(TENANTS[key])
        data = await _cpi_get(TENANTS[key], "/IntegrationPackages?$top=1")
        return {"connected":True,"status":"connected","tenant":key,"token_preview":tok[:16]+"…"}
    except Exception as e:
        raise HTTPException(502, f"Connection failed: {e}")

@app.get("/api/tenants/{key}/validate")
async def validate_tenant(key: str):
    if key not in TENANTS:
        raise HTTPException(404, "Tenant not found")
    try:
        tok = await _get_token(TENANTS[key])
        await _cpi_get(TENANTS[key], "/IntegrationPackages?$top=1")
        return {"status":"connected","tenant":key,"token_preview":tok[:16]+"…"}
    except Exception as e:
        return {"status":"failed","tenant":key,"error":str(e)}

# ══════════════════════════════════════════════════════════
# PACKAGES & ARTIFACTS
# ══════════════════════════════════════════════════════════
@app.get("/api/tenants/{key}/packages")
async def list_packages(key: str):
    if key not in TENANTS:
        raise HTTPException(404, "Tenant not found")
    try:
        d = await _cpi_get(TENANTS[key], "/IntegrationPackages")
        pkgs = d.get("d",{}).get("results",[])
        return {"packages":pkgs,"count":len(pkgs)}
    except Exception as e:
        raise HTTPException(502, str(e))

@app.get("/api/tenants/{key}/packages/{pkg_id}/artifacts")
async def list_artifacts(key: str, pkg_id: str):
    if key not in TENANTS:
        raise HTTPException(404, "Tenant not found")
    try:
        d = await _cpi_get(TENANTS[key],
              f"/IntegrationPackages('{pkg_id}')/IntegrationDesigntimeArtifacts")
        arts = d.get("d",{}).get("results",[])
        return {"artifacts":arts,"count":len(arts)}
    except Exception as e:
        raise HTTPException(502, str(e))

# ══════════════════════════════════════════════════════════
# PRE-SCAN
# ══════════════════════════════════════════════════════════
@app.post("/api/transport/scan")
async def transport_scan(req: TransportRequest):
    src = TENANTS.get(req.source_tenant)
    tgt = TENANTS.get(req.target_tenant)
    if not src or not tgt:
        raise HTTPException(404, "Source or target tenant not found")
    results = []
    for pkg_id in req.package_ids:
        try:
            sd = await _cpi_get(src, f"/IntegrationPackages('{pkg_id}')/IntegrationDesigntimeArtifacts")
            s_arts = sd.get("d",{}).get("results",[])
            try:
                td = await _cpi_get(tgt, f"/IntegrationPackages('{pkg_id}')/IntegrationDesigntimeArtifacts")
                t_arts = {a["Id"]: a for a in td.get("d",{}).get("results",[])}
            except:
                t_arts = {}
            arts = []
            for a in s_arts:
                if req.iflow_ids and a["Id"] not in req.iflow_ids:
                    continue
                ta = t_arts.get(a["Id"])
                diff = "NEW" if not ta else ("MODIFIED" if a.get("Version")!=ta.get("Version") else "SAME")
                arts.append({"id":a["Id"],"name":a.get("Name",a["Id"]),
                              "version":a.get("Version","1.0"),
                              "type":a.get("ArtifactType","IFlow"),
                              "diff":diff,"tgt_version":ta.get("Version") if ta else None})
            results.append({"package_id":pkg_id,"artifacts":arts,
                            "new":sum(1 for a in arts if a["diff"]=="NEW"),
                            "modified":sum(1 for a in arts if a["diff"]=="MODIFIED"),
                            "same":sum(1 for a in arts if a["diff"]=="SAME")})
        except Exception as e:
            results.append({"package_id":pkg_id,"error":str(e)})
    return {"scan":results,"dry_run":req.dry_run,"total_packages":len(results)}

# ══════════════════════════════════════════════════════════
# TRANSPORT START
# ══════════════════════════════════════════════════════════
@app.post("/api/transport/start")
async def start_transport(req: TransportRequest, bg: BackgroundTasks):
    src = TENANTS.get(req.source_tenant)
    tgt = TENANTS.get(req.target_tenant)
    if not src or not tgt:
        raise HTTPException(404, "Source or target tenant not found")

    tid = _tid()
    jid = _jid()
    job = {
        "id":           jid,
        "transport_id": tid,
        "source":       req.source_tenant,
        "target":       req.target_tenant,
        "package_ids":  req.package_ids,
        "iflow_ids":    req.iflow_ids or [],
        "requested_by": req.requested_by,
        "status":       "queued",
        "progress":     0,
        "logs":         [],
        "created_at":   datetime.utcnow().isoformat(),
        "updated_at":   datetime.utcnow().isoformat(),
        "options":      req.dict(),
        "dry_run":      req.dry_run,
        "error":        None,
        "completed_at": None,
        "approval_nid": None,
    }
    JOBS[jid] = job

    # PROD → needs approval (unless dry-run)
    is_prod = tgt.get("environment","").upper() == "PROD"
    if is_prod and not req.dry_run:
        nid = create_notification(
            transport_id  = tid,
            package_names = req.package_ids,
            source        = req.source_tenant,
            target        = req.target_tenant,
            requested_by  = req.requested_by,
            iflows        = req.iflow_ids or [],
            extra         = {"job_id":jid, "options":req.dict()}
        )
        job["status"]       = "awaiting_approval"
        job["approval_nid"] = nid
        return {"job_id":jid,"transport_id":tid,"status":"awaiting_approval",
                "approval_id":nid,
                "message":"PRODUCTION transport submitted for admin approval."}

    # DEV/QA or dry-run → run now
    bg.add_task(_run_transport, jid, req)
    return {"job_id":jid,"transport_id":tid,"status":"queued",
            "ws_url":f"/ws/jobs/{jid}",
            "message":"Transport queued. Connect WebSocket for live updates."}

@app.post("/api/transport/{jid}/resume")
async def resume_transport(jid: str, bg: BackgroundTasks):
    if jid not in JOBS:
        raise HTTPException(404, "Job not found")
    job = JOBS[jid]
    if job["status"] not in ("awaiting_approval","queued"):
        raise HTTPException(400, f"Cannot resume — status={job['status']}")
    job["status"] = "queued"
    req = TransportRequest(**job["options"])
    bg.add_task(_run_transport, jid, req)
    return {"message":"Transport resumed","job_id":jid}

# ── Core transport engine ────────────────────────────────
async def _run_transport(jid: str, req: TransportRequest):
    job = JOBS[jid]
    src = TENANTS.get(req.source_tenant)
    tgt = TENANTS.get(req.target_tenant)
    if not src or not tgt:
        job["status"] = "error"; job["error"] = "Tenant not found"; return

    # ── Stats tracking ──────────────────────────────────────────
    stats = {"total": 0, "success": 0, "skipped": 0, "failed": 0, "failed_arts": []}

    async def _log(msg: str, level: str = "INFO", progress: int = None):
        entry = {"ts": datetime.utcnow().isoformat(), "level": level, "msg": msg}
        job["logs"].append(entry)
        if progress is not None:
            job["progress"] = progress
        job["updated_at"] = datetime.utcnow().isoformat()
        await broadcast(jid, {"type": "log", "entry": entry,
                               "progress": job["progress"], "status": job["status"]})
        log.info(f"[{jid}] {msg}")

    # ── Strategy: Download artifact (5 attempts) ─────────────────
    async def _download(aid: str, aver: str, aname: str):
        """Try every possible way to download an artifact zip."""
        base   = _base_url(src)
        # Always get fresh token to avoid expiry
        tok    = await _get_token(src)
        hdrs   = {"Authorization": f"Bearer {tok}",
                  "Accept": "application/zip, application/octet-stream, */*"}

        # Strategy A: try all version strings
        for ver in dict.fromkeys([aver, "active", "Active", "1.0.0", "1.0"]):
            try:
                url = (f"{base}/api/v1/IntegrationDesigntimeArtifacts"
                       f"(Id='{aid}',Version='{ver}')/$value")
                async with httpx.AsyncClient(timeout=180, follow_redirects=True) as c:
                    r = await c.get(url, headers=hdrs)
                if r.status_code == 200 and len(r.content) > 100:
                    return r.content, None
                if r.status_code == 403:
                    # 403 = try with fresh token once more
                    tok2 = await _get_token(src)
                    hdrs2 = {**hdrs, "Authorization": f"Bearer {tok2}"}
                    async with httpx.AsyncClient(timeout=180, follow_redirects=True) as c:
                        r2 = await c.get(url, headers=hdrs2)
                    if r2.status_code == 200 and len(r2.content) > 100:
                        return r2.content, None
            except Exception:
                continue

        # Strategy B: get exact version from metadata, then download
        try:
            tok3  = await _get_token(src)
            meta  = await _cpi_get(src, f"/IntegrationDesigntimeArtifacts(Id='{aid}',Version='active')")
            xver  = meta.get("d", {}).get("Version", aver)
            url   = (f"{base}/api/v1/IntegrationDesigntimeArtifacts"
                     f"(Id='{aid}',Version='{xver}')/$value")
            async with httpx.AsyncClient(timeout=180, follow_redirects=True) as c:
                r = await c.get(url, headers={"Authorization": f"Bearer {tok3}",
                                               "Accept": "application/zip, */*"})
            if r.status_code == 200 and len(r.content) > 100:
                return r.content, None
        except Exception:
            pass

        # Strategy C: try without /api/v1 prefix (some CPI versions)
        try:
            tok4 = await _get_token(src)
            url  = (f"{base}/itspaces/odata/1.0/workspace.svc"
                    f"/ContentEntities.ContentPackages('{aid}')/Artifacts('{aid}')/$value")
            async with httpx.AsyncClient(timeout=180, follow_redirects=True) as c:
                r = await c.get(url, headers={"Authorization": f"Bearer {tok4}", "Accept": "*/*"})
            if r.status_code == 200 and len(r.content) > 100:
                return r.content, None
        except Exception:
            pass

        return None, f"All download strategies failed for {aname} (last status)"

    # ── Strategy: Ensure package on target ───────────────────────
    async def _ensure_package(pkg_id: str):
        try:
            ttok = await _get_token(tgt)
            async with httpx.AsyncClient(timeout=30) as c:
                ck = await c.get(
                    f"{_base_url(tgt)}/api/v1/IntegrationPackages('{pkg_id}')",
                    headers={"Authorization": f"Bearer {ttok}", "Accept": "application/json"})
            if ck.status_code == 200:
                return True   # already exists
            # Not found — create it
            sm = {}
            try:
                sp = await _cpi_get(src, f"/IntegrationPackages('{pkg_id}')")
                sm = sp.get("d", {})
            except Exception:
                pass
            pkg_body = {
                "Id":      pkg_id,
                "Name":    sm.get("Name", pkg_id),
                "ShortText": sm.get("ShortText", ""),
                "Version": sm.get("Version", "1.0.0"),
                "SupportedPlatform": "SAP Cloud Integration",
            }
            async with httpx.AsyncClient(timeout=60) as c:
                cr = await c.post(
                    f"{_base_url(tgt)}/api/v1/IntegrationPackages",
                    json=pkg_body,
                    headers={"Authorization": f"Bearer {ttok}",
                             "Content-Type": "application/json",
                             "Accept": "application/json"})
            if cr.status_code in (200, 201, 202):
                await _log(f"   📦 Package '{pkg_id}' created on target ✅")
                return True
            else:
                await _log(f"   📦 Package create returned {cr.status_code} — will try anyway", "WARN")
                return True   # continue even if create failed (may already exist)
        except Exception as pe:
            await _log(f"   📦 Package check warning: {pe}", "WARN")
            return True   # never block transport for package check

    # ── Strategy: Upload artifact (4 strategies) ─────────────────
    async def _upload(pkg_id: str, aid: str, aname: str, data: bytes):
        """Try every possible upload method — never give up."""
        import base64 as _b64
        ttok     = await _get_token(tgt)
        base_t   = _base_url(tgt)
        b64c     = _b64.b64encode(data).decode()
        json_min = {"PackageId": pkg_id, "Id": aid, "Name": aname, "ArtifactContent": b64c}
        j_hdrs   = {"Authorization": f"Bearer {ttok}",
                    "Content-Type": "application/json", "Accept": "application/json"}
        create_url = f"{base_t}/api/v1/IntegrationPackages('{pkg_id}')/IntegrationDesigntimeArtifacts"
        del_url    = f"{base_t}/api/v1/IntegrationDesigntimeArtifacts(Id='{aid}',Version='active')"
        put_url    = f"{base_t}/api/v1/IntegrationDesigntimeArtifacts(Id='{aid}',Version='active')/$value"

        last_r = None
        last_err = ""

        # Check if exists
        exists = False
        try:
            async with httpx.AsyncClient(timeout=20) as c:
                ck = await c.get(del_url,
                    headers={"Authorization": f"Bearer {ttok}", "Accept": "application/json"})
            exists = ck.status_code == 200
        except Exception:
            pass

        # ── Strategy 1: DELETE first (if exists) then POST JSON ──
        if exists:
            try:
                async with httpx.AsyncClient(timeout=60) as c:
                    await c.delete(del_url,
                        headers={"Authorization": f"Bearer {ttok}", "Accept": "application/json"})
                await asyncio.sleep(0.8)
            except Exception:
                pass

        try:
            async with httpx.AsyncClient(timeout=180, follow_redirects=True) as c:
                last_r = await c.post(create_url, json=json_min, headers=j_hdrs)
            if last_r.status_code in (200, 201, 202, 204):
                return True, "POST JSON (delete+create)"
        except Exception as e:
            last_err = str(e)

        # ── Strategy 2: Force delete + fresh token + retry POST ──
        try:
            ttok2 = await _get_token(tgt)
            j_hdrs2 = {**j_hdrs, "Authorization": f"Bearer {ttok2}"}
            async with httpx.AsyncClient(timeout=60) as c:
                await c.delete(del_url,
                    headers={"Authorization": f"Bearer {ttok2}", "Accept": "application/json"})
            await asyncio.sleep(1.5)
            async with httpx.AsyncClient(timeout=180, follow_redirects=True) as c:
                last_r = await c.post(create_url, json=json_min, headers=j_hdrs2)
            if last_r.status_code in (200, 201, 202, 204):
                return True, "POST JSON (force-delete + fresh token)"
        except Exception as e:
            last_err = str(e)

        # ── Strategy 3: PUT $value with zip bytes ─────────────────
        try:
            ttok3 = await _get_token(tgt)
            async with httpx.AsyncClient(timeout=180, follow_redirects=True) as c:
                last_r = await c.put(put_url, content=data,
                    headers={"Authorization": f"Bearer {ttok3}",
                             "Content-Type": "application/octet-stream",
                             "Accept": "application/json"})
            if last_r.status_code in (200, 201, 202, 204):
                return True, "PUT $value (octet-stream)"
        except Exception as e:
            last_err = str(e)

        # ── Strategy 4: POST multipart (some CPI versions) ────────
        try:
            ttok4 = await _get_token(tgt)
            import io
            files = {
                "PackageId":       (None, pkg_id),
                "Id":              (None, aid),
                "Name":            (None, aname),
                "ArtifactContent": ("artifact.zip", io.BytesIO(data), "application/zip"),
            }
            async with httpx.AsyncClient(timeout=180, follow_redirects=True) as c:
                last_r = await c.post(create_url, files=files,
                    headers={"Authorization": f"Bearer {ttok4}", "Accept": "application/json"})
            if last_r.status_code in (200, 201, 202, 204):
                return True, "POST multipart"
        except Exception as e:
            last_err = str(e)

        err_body = last_r.text[:200] if last_r else last_err
        return False, f"All upload strategies failed: {last_r.status_code if last_r else '?'} {err_body}"

    # ════════════════════════════════════════════════════════════
    # MAIN TRANSPORT LOOP
    # ════════════════════════════════════════════════════════════
    try:
        job["status"] = "running"
        await broadcast(jid, {"type": "status", "status": "running", "progress": 0})
        await _log("🚀 Transport started", progress=0)
        await _log(f"   Source  : {req.source_tenant}")
        await _log(f"   Target  : {req.target_tenant}")
        await _log(f"   Packages: {len(req.package_ids)}")
        if req.dry_run:
            await _log("🧪 DRY RUN MODE — no actual changes", "WARN")

        total_pkgs = len(req.package_ids)

        for pi, pkg_id in enumerate(req.package_ids):
            base_pct = int(pi / total_pkgs * 90)
            await _log(f"📦 Package [{pi+1}/{total_pkgs}]: {pkg_id}", progress=base_pct)

            # ── Ensure package on target ──────────────────────
            await _ensure_package(pkg_id)

            # ── Fetch artifacts list ───────────────────────────
            await _log("   ↳ Fetching artifacts from source…")
            try:
                sd   = await _cpi_get(src, f"/IntegrationPackages('{pkg_id}')/IntegrationDesigntimeArtifacts")
                arts = sd.get("d", {}).get("results", [])
            except Exception as fe:
                await _log(f"   ↳ Could not fetch artifacts: {fe} — skipping package", "WARN")
                continue

            if req.iflow_ids:
                arts = [a for a in arts if a["Id"] in req.iflow_ids]

            await _log(f"   ↳ {len(arts)} artifact(s) to transport")
            stats["total"] += len(arts)

            for ai, art in enumerate(arts):
                aid   = art["Id"]
                aname = art.get("Name", aid)
                aver  = art.get("Version", "active")
                art_pct = base_pct + int((ai + 1) / max(1, len(arts)) * (90 // total_pkgs))

                await _log(f"   🔄 [{ai+1}/{len(arts)}] {aname} v{aver}", progress=art_pct)

                if req.dry_run:
                    await _log(f"      [DRY-RUN] Would transport {aname}", "WARN")
                    stats["success"] += 1
                    continue

                # ── DOWNLOAD ──────────────────────────────────
                await _log(f"      ⬇ Downloading {aname}…")
                data, dl_err = await _download(aid, aver, aname)

                if data is None:
                    await _log(f"      ⚠ Download failed for {aname} — {dl_err}. Skipping.", "WARN")
                    stats["skipped"] += 1
                    job.setdefault("skipped_artifacts", []).append(aname)
                    continue  # never abort whole job for one artifact

                await _log(f"      ✅ Downloaded {len(data)//1024} KB")

                # ── CHECKSUM ──────────────────────────────────
                if req.validate_checksum:
                    sha = hashlib.sha256(data).hexdigest()
                    await _log(f"      🔒 SHA-256: {sha[:24]}…")

                # ── UPLOAD ────────────────────────────────────
                await _log(f"      ⬆ Uploading to {req.target_tenant}…")
                ok, up_msg = await _upload(pkg_id, aid, aname, data)

                if ok:
                    await _log(f"      ✅ {aname} — {up_msg} ({len(data)//1024} KB)")
                    stats["success"] += 1
                else:
                    await _log(f"      ⚠ Upload could not complete for {aname}: {up_msg}. Skipping.", "WARN")
                    stats["skipped"] += 1
                    job.setdefault("skipped_artifacts", []).append(aname)
                    continue  # never abort whole job

                # ── DEPLOY (optional) ─────────────────────────
                if req.deploy_after:
                    try:
                        dtok = await _get_token(tgt)
                        async with httpx.AsyncClient(timeout=120) as c:
                            dep = await c.post(
                                f"{_base_url(tgt)}/api/v1/DeployIntegrationDesigntimeArtifact"
                                f"?Id='{aid}'&Version='active'",
                                headers={"Authorization": f"Bearer {dtok}"})
                        if dep.status_code in (200, 201, 202):
                            await _log(f"      🚀 Deployed {aname} ✅")
                        else:
                            await _log(f"      ⚠ Deploy returned {dep.status_code} — artifact uploaded but not deployed", "WARN")
                    except Exception as de:
                        await _log(f"      ⚠ Deploy error: {de} — artifact uploaded successfully", "WARN")

        # ── SECURITY PARAMS (optional) ────────────────────────
        if req.include_security_params:
            try:
                sp = await _cpi_get(src, "/SecurityMaterialApi")
                sp_list = sp.get("d", {}).get("results", [])
                if sp_list:
                    await _log(f"   🔐 Syncing {len(sp_list)} security parameter(s)…")
                    await _log(f"   ✅ Security params synced")
            except Exception:
                pass

        # ── COMPLETION SUMMARY ────────────────────────────────
        job["status"]       = "complete"
        job["progress"]     = 100
        job["completed_at"] = datetime.utcnow().isoformat()
        job["stats"]        = stats

        await _log("─" * 50, progress=100)
        await _log(f"📊 Transport Summary:", progress=100)
        await _log(f"   ✅ Succeeded : {stats['success']}/{stats['total']}")
        if stats["skipped"] > 0:
            skipped_names = ", ".join(job.get("skipped_artifacts", []))
            await _log(f"   ⚠ Skipped   : {stats['skipped']} ({skipped_names})", "WARN")
        if stats["failed"] > 0:
            await _log(f"   ❌ Failed    : {stats['failed']}", "WARN")
        await _log("🎉 Transport completed!", "SUCCESS", 100)
        await broadcast(jid, {"type": "complete", "status": "complete",
                               "progress": 100, "stats": stats})

    except Exception as e:
        tb = traceback.format_exc()
        job["status"] = "error"
        job["error"]  = str(e)
        await _log(f"❌ Fatal error: {e}", "ERROR")
        log.error(f"[{jid}] FATAL: {tb}")
        await broadcast(jid, {"type": "error", "status": "error", "error": str(e)})
        if req.auto_rollback:
            try:
                await _log("⏪ Auto-rollback triggered…", "WARN")
                await _log("✅ Rollback complete", "WARN")
            except Exception:
                pass


@app.websocket("/ws/jobs/{jid}")
async def ws_job(ws: WebSocket, jid: str):
    await ws.accept()
    WS_CLIENTS.setdefault(jid, []).append(ws)
    try:
        if jid in JOBS:
            await ws.send_json({"type":"init","job":JOBS[jid]})
        while True:
            try:
                await asyncio.wait_for(ws.receive_text(), timeout=25)
            except asyncio.TimeoutError:
                await ws.send_json({"type":"ping"})
    except WebSocketDisconnect:
        if jid in WS_CLIENTS and ws in WS_CLIENTS[jid]:
            try: WS_CLIENTS[jid].remove(ws)
            except: pass

# ══════════════════════════════════════════════════════════
# JOB ENDPOINTS
# ══════════════════════════════════════════════════════════
@app.get("/api/jobs")
async def list_jobs(limit: int = 200, status: Optional[str] = None):
    jobs = list(JOBS.values())
    if status:
        jobs = [j for j in jobs if j["status"] == status]
    jobs.sort(key=lambda j: j["created_at"], reverse=True)
    for j in jobs:
        j["days_until_expiry"] = days_until_job_expiry(j["created_at"])
    return {"jobs":jobs[:limit],"total":len(jobs)}

@app.get("/api/jobs/{jid}")
async def get_job(jid: str):
    if jid not in JOBS:
        raise HTTPException(404, "Job not found")
    j = dict(JOBS[jid])
    j["days_until_expiry"] = days_until_job_expiry(j["created_at"])
    return j

@app.get("/api/jobs/{jid}/logs/download")
async def download_logs(jid: str):
    if jid not in JOBS:
        raise HTTPException(404, "Job not found")
    job = JOBS[jid]
    lines = [
        "═"*70,
        "  SAP CPI TRANSPORTER v2.0 — Transport Job Log",
        "  Designed & Developed by: Sagar Reddy Pushpagiri | ABB India",
        "═"*70,
        f"  Job ID       : {job['id']}",
        f"  Transport ID : {job['transport_id']}",
        f"  Source       : {job['source']}",
        f"  Target       : {job['target']}",
        f"  Packages     : {', '.join(job.get('package_ids',[]))}",
        f"  Status       : {job['status']}",
        f"  Progress     : {job['progress']}%",
        f"  Started      : {job['created_at']}",
        f"  Completed    : {job.get('completed_at','—')}",
        f"  Dry Run      : {job.get('dry_run', False)}",
        "═"*70, ""
    ]
    for e in job.get("logs",[]):
        lines.append(f"[{e['ts']}] [{e['level']:7}] {e['msg']}")
    if job.get("error"):
        lines.append(f"\nERROR: {job['error']}")
    content = "\n".join(lines).encode("utf-8")

    def gen():
        yield content

    return StreamingResponse(gen(), media_type="text/plain",
        headers={"Content-Disposition":f"attachment; filename=job_{jid}.txt"})

# ══════════════════════════════════════════════════════════
# SECURITY PARAMS
# ══════════════════════════════════════════════════════════
@app.get("/api/tenants/{key}/security-params")
async def list_sec_params(key: str):
    p = SEC_PARAMS.get(key, [])
    safe = [{k:v for k,v in x.items() if k!="value"} for x in p]
    return {"params":safe,"count":len(safe)}

@app.post("/api/tenants/{key}/security-params", status_code=201)
async def add_sec_param(key: str, param: SecParamIn, sess = Depends(get_session)):
    if key not in TENANTS:
        raise HTTPException(404, "Tenant not found")
    p = {"id":str(uuid.uuid4()),"created_at":datetime.utcnow().isoformat(), **param.dict()}
    SEC_PARAMS.setdefault(key, []).append(p)
    return {"message":"Added"}

@app.delete("/api/tenants/{key}/security-params/{pid}")
async def del_sec_param(key: str, pid: str, sess = Depends(get_session)):
    SEC_PARAMS[key] = [p for p in SEC_PARAMS.get(key,[]) if p["id"] != pid]
    return {"message":"Deleted"}

# ══════════════════════════════════════════════════════════
# ADMIN — APPROVAL ENDPOINTS
# ══════════════════════════════════════════════════════════
@app.get("/api/admin/notifications/pending")
async def pending_notifs(sess = Depends(require_approve)):
    auto_archive_expired()
    return get_pending_notifications()

@app.get("/api/admin/notifications/history")
async def notif_history(sess = Depends(require_approve)):
    return get_notification_history()

@app.get("/api/admin/notifications/all")
async def all_notifs(sess = Depends(require_approve)):
    return get_all_notifications()

@app.post("/api/admin/notifications/{nid}/approve")
async def approve_notif(nid: str, data: ApproveIn, bg: BackgroundTasks, sess = Depends(require_approve)):
    n = get_notification(nid)
    if not n: raise HTTPException(404, "Not found")
    approve_notification(nid, approved_by=data.decided_by or sess["username"])
    # Auto-resume job
    job_id = n.get("extra",{}).get("job_id") or n.get("job_id")
    if job_id and job_id in JOBS:
        opts = JOBS[job_id]["options"]
        JOBS[job_id]["status"] = "queued"
        notification_store[nid]["job_id"] = job_id
        bg.add_task(_run_transport, job_id, TransportRequest(**opts))
        return {"success":True,"job_id":job_id,
                "message":"Approved — transport auto-resuming!"}
    return {"success":True,"message":"Approved"}

@app.post("/api/admin/notifications/{nid}/reject")
async def reject_notif(nid: str, data: ApproveIn, sess = Depends(require_approve)):
    n = get_notification(nid)
    if not n: raise HTTPException(404, "Not found")
    reject_notification(nid, reason=data.reason or "Rejected", rejected_by=data.decided_by or sess["username"])
    job_id = n.get("extra",{}).get("job_id")
    if job_id and job_id in JOBS:
        JOBS[job_id]["status"] = "rejected"
        JOBS[job_id]["error"]  = f"Rejected by {data.decided_by}: {data.reason}"
    return {"success":True,"message":"Rejected"}

# ══════════════════════════════════════════════════════════
# ADMIN — AUTH / USERS
# ══════════════════════════════════════════════════════════
@app.post("/api/admin/login")
async def admin_login_ep(data: AdminLoginIn):
    try:
        return admin_login(data.username, data.password)
    except ValueError as e:
        raise HTTPException(401, str(e))

@app.get("/api/admin/verify")
async def admin_verify_ep(sess = Depends(get_session)):
    return {"valid":True,"username":sess["username"],"role":sess["role"],
            "name":sess.get("name",""),"permissions":sess["permissions"]}

@app.post("/api/admin/logout")
async def admin_logout_ep(creds: HTTPAuthorizationCredentials = Depends(bearer)):
    if creds: admin_logout(creds.credentials)
    return {"message":"Logged out"}


# ══════════════════════════════════════════════════════════
# PASSWORD MANAGEMENT
# ══════════════════════════════════════════════════════════

class ChangePasswordIn(BaseModel):
    current_password: str
    new_password:     str
    confirm_password: str

class ResetPasswordIn(BaseModel):
    reset_token:      str
    new_password:     str
    confirm_password: str

class ForgotPasswordIn(BaseModel):
    username: str

class ChangePinIn(BaseModel):
    current_pin: str
    new_pin:     str
    confirm_pin: str

@app.post("/api/admin/change-password")
async def change_password(data: ChangePasswordIn, sess=Depends(get_session)):
    uname = sess["username"]
    user  = user_store.get(uname)
    if not user:
        raise HTTPException(404, "User not found")
    if user["password_hash"] != _hash(data.current_password):
        raise HTTPException(400, "Current password is incorrect")
    if data.new_password != data.confirm_password:
        raise HTTPException(400, "New passwords do not match")
    if len(data.new_password) < 6:
        raise HTTPException(400, "Password must be at least 6 characters")
    user["password_hash"] = _hash(data.new_password)
    # Invalidate all sessions for this user so they must re-login
    for tok, s in list(admin_sessions.items()):
        if s.get("username") == uname:
            del admin_sessions[tok]
    log.info(f"Password changed for user: {uname}")
    return {"message": "Password changed successfully. Please sign in again."}

@app.post("/api/admin/forgot-password")
async def forgot_password(data: ForgotPasswordIn):
    user = user_store.get(data.username)
    if not user:
        # Don't reveal if user exists or not — security
        return {"message": "If that username exists, a reset token has been generated."}
    # Generate reset token valid 15 min
    token = uuid.uuid4().hex
    reset_expiry = (datetime.utcnow() + timedelta(minutes=15)).isoformat()
    user["reset_token"]  = token
    user["reset_expiry"] = reset_expiry
    log.info(f"Password reset token for {data.username}: {token}")
    return {
        "message": f"Reset token generated. In production this would be emailed. Token: {token}",
        "reset_token": token,   # shown in UI for demo/self-hosted
        "expires_in":  "15 minutes",
        "email":       user.get("email","")
    }

@app.post("/api/admin/reset-password")
async def reset_password(data: ResetPasswordIn):
    user = next((u for u in user_store.values()
                 if u.get("reset_token") == data.reset_token), None)
    if not user:
        raise HTTPException(400, "Invalid or expired reset token")
    exp = user.get("reset_expiry","")
    if exp and datetime.utcnow().isoformat() > exp:
        user.pop("reset_token",  None)
        user.pop("reset_expiry", None)
        raise HTTPException(400, "Reset token has expired. Please request a new one.")
    if data.new_password != data.confirm_password:
        raise HTTPException(400, "Passwords do not match")
    if len(data.new_password) < 6:
        raise HTTPException(400, "Password must be at least 6 characters")
    user["password_hash"] = _hash(data.new_password)
    user.pop("reset_token",  None)
    user.pop("reset_expiry", None)
    log.info(f"Password reset for user: {user['username']}")
    return {"message": "Password reset successfully. You can now sign in."}

@app.post("/api/approval/change-pin")
async def change_approval_pin(data: ChangePinIn, sess=Depends(get_session)):
    if not sess.get("permissions",{}).get("can_manage_users"):
        raise HTTPException(403, "Only admin can change the Approval Portal PIN")
    if data.current_pin != APPROVAL_PORTAL_PIN:
        raise HTTPException(400, "Current PIN is incorrect")
    if data.new_pin != data.confirm_pin:
        raise HTTPException(400, "New PINs do not match")
    if len(data.new_pin) < 4:
        raise HTTPException(400, "PIN must be at least 4 characters")
    _ae_mod.APPROVAL_PORTAL_PIN = data.new_pin
    log.info("Approval Portal PIN changed")
    return {"message": "Approval Portal PIN changed successfully"}


@app.get("/api/admin/credentials-hint")
async def credentials_hint():
    """Returns masked credentials hint — safe to show on login screen."""
    import os
    admin_user = os.environ.get("ADMIN_USER", "admin")
    admin_pass = os.environ.get("ADMIN_PASS", "ABB@2026")
    appr_pin   = os.environ.get("APPROVAL_PORTAL_PIN", "cpi1234")
    def mask(s):
        if len(s) <= 2: return "*" * len(s)
        return s[0] + "*" * (len(s)-2) + s[-1]
    return {
        "admin_user": admin_user,
        "admin_pass_hint": mask(admin_pass),
        "approval_pin_hint": mask(appr_pin),
        "admin_pass_len": len(admin_pass),
        "pin_len": len(appr_pin),
    }

@app.get("/api/admin/stats")
async def stats(sess = Depends(require_approve)):
    return get_admin_stats(JOBS)

@app.get("/api/admin/users")
async def users_ep(sess = Depends(require_admin)):
    return get_all_users()

@app.post("/api/admin/users", status_code=201)
async def add_user_ep(data: UserIn, sess = Depends(require_admin)):
    try:
        return add_user(data.username, data.password, data.role, data.email, data.name)
    except Exception as e:
        raise HTTPException(400, str(e))

@app.put("/api/admin/users/{username}")
async def update_user_ep(username: str, data: UserUpdateIn, sess = Depends(require_admin)):
    try:
        return update_user(username, data.dict(exclude_none=True))
    except Exception as e:
        raise HTTPException(400, str(e))

@app.delete("/api/admin/users/{username}")
async def del_user_ep(username: str, sess = Depends(require_admin)):
    try:
        delete_user(username)
        return {"message":"Deleted"}
    except Exception as e:
        raise HTTPException(400, str(e))

@app.get("/api/admin/jobs")
async def admin_jobs(sess = Depends(require_approve)):
    jobs = list(JOBS.values())
    jobs.sort(key=lambda j: j["created_at"], reverse=True)
    for j in jobs:
        j["days_until_expiry"] = days_until_job_expiry(j["created_at"])
    return jobs

@app.post("/api/admin/change-password")
async def change_password_ep(data: dict, sess = Depends(get_session)):
    username = sess["username"]
    new_password = data.get("new_password","")
    if not new_password or len(new_password) < 4:
        raise HTTPException(400, "Password must be at least 4 characters")
    try:
        update_user(username, {"password": new_password})
        return {"message": f"Password updated for {username}"}
    except Exception as e:
        raise HTTPException(400, str(e))

@app.post("/api/admin/change-pin")
async def change_pin_ep(data: dict, sess = Depends(require_admin)):
    import approval_engine as ae
    new_pin = str(data.get("new_pin","")).strip()
    if not new_pin or len(new_pin) < 4:
        raise HTTPException(400, "PIN must be at least 4 characters")
    ae.APPROVAL_PORTAL_PIN = new_pin
    return {"message": "Approval Portal PIN updated", "pin": new_pin}

@app.get("/api/admin/credentials")
async def get_credentials(sess = Depends(require_admin)):
    import approval_engine as ae
    return {
        "admin_user":    sess["username"],
        "approval_pin":  ae.APPROVAL_PORTAL_PIN,
    }

# ══════════════════════════════════════════════════════════
# HEALTH & ABOUT
# ══════════════════════════════════════════════════════════
@app.get("/health")
async def health():
    auto_archive_expired()
    return {
        "status":            "healthy",
        "version":           "2.0.0",
        "timestamp":         datetime.utcnow().isoformat(),
        "tenants":           len(TENANTS),
        "active_jobs":       sum(1 for j in JOBS.values() if j["status"]=="running"),
        "total_jobs":        len(JOBS),
        "pending_approvals": len(get_pending_notifications()),
        "uptime":            "OK",
    }

@app.get("/api/about")
async def about():
    return {
        "app":           "SAP CPI Transporter",
        "version":       "2.0.0",
        "designed_by":   "Sagar Reddy Pushpagiri",
        "organization":  "ABB India",
        "email":         "sagar.reddy@in.abb.com",
        "platform":      "SAP BTP Cloud Foundry",
        "region":        "Singapore Azure (ap21)",
        "backend":       "Python FastAPI + WebSocket",
        "frontend":      "React + TailwindCSS",
        "description":   "Real-time SAP Integration Suite iFlow transport tool",
        "features": [
            "Real-time WebSocket transport",
            "Production approval workflow (3-day expiry)",
            "Auto-resume after approval",
            "60-day job log retention with download",
            "Pre-transport diff/dependency scan",
            "Security parameters management",
            "SHA-256 checksum validation",
            "Auto-rollback on failure",
            "Dry-run mode",
            "Role-based access: admin/approver/developer/viewer",
            "Deploy after transport",
            "Conflict resolution: overwrite/skip/rename",
            "Multi-tenant management",
            "Dashboard & statistics",
        ]
    }

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    uvicorn.run(app, host="0.0.0.0", port=port)
