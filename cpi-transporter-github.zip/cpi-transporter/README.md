# 🚀 SAP CPI TRANSPORTER

Transport SAP CPI Integration Packages & Artifacts between tenants.

## 📁 Repository Structure

```
cpi-transporter/
├── backend/
│   ├── main_api.py              ← Backend API (copy from main_api_complete.py)
│   ├── main_api_complete.py     ← Latest backend source
│   ├── approval_engine.py       ← Approval workflow engine
│   ├── requirements.txt         ← Python dependencies
│   ├── Procfile                 ← CF process file
│   └── manifest.yml             ← CF backend manifest
├── frontend/
│   ├── src/
│   │   └── App.js               ← React frontend (copy from App_v3_final.js)
│   ├── public/
│   │   └── index.html
│   ├── package.json
│   └── manifest.yml             ← CF frontend manifest
├── deploy.bat                   ← One-shot Windows deploy script
└── README.md
```

## ⚡ Quick Deploy (New BTP Environment)

### Prerequisites
- [CF CLI](https://github.com/cloudfoundry/cli/releases)
- [Node.js 18+](https://nodejs.org)
- BTP Trial or Enterprise account

### Steps

```bat
:: 1. Download/clone repo to Downloads folder
cd %USERPROFILE%\Downloads\cpi-transporter

:: 2. Run one-shot deploy
deploy.bat
```

That's it! The script will:
- ✅ Log into CF
- ✅ Deploy backend
- ✅ Build React frontend
- ✅ Deploy frontend

## 🔑 Default Credentials

| Portal | Username | Password |
|--------|----------|----------|
| Admin | `admin` | `ABB@2026` |
| Approval PIN | - | `cpi1234` |

> ⚠️ Change these after first login!

## 🌐 URLs (after deploy)

| App | URL |
|-----|-----|
| Frontend | `https://cpi-transporter-frontend-xxxx.cfapps.ap21.hana.ondemand.com` |
| Backend  | `https://cpi-transporter-backend-xxxx.cfapps.ap21.hana.ondemand.com` |

## 🔧 Manual Deploy (Step by Step)

```bat
:: Login
cf login -a https://api.cf.ap21.hana.ondemand.com -u your@email.com

:: Deploy Backend
cd backend
copy main_api_complete.py main_api.py /Y
cf push cpi-transporter-backend -f manifest.yml

:: Build + Deploy Frontend
cd ..\frontend
set DISABLE_ESLINT_PLUGIN=true
set REACT_APP_API_URL=https://YOUR-BACKEND-URL
npm install
npm run build
echo | set /p ="root: ." > build\Staticfile
cf push cpi-transporter-frontend -p "build" -b staticfile_buildpack -m 128M -k 512M -i 1 --no-manifest
```

## 📦 Features

- 🔄 Transport packages & artifacts between tenants
- ✅ Multiple download/upload strategies (never fails on one artifact)
- 📊 Live transport logs with progress
- 🔐 Admin panel with approval workflow
- 🔖 TR Number tracking
- 📋 Jobs history
