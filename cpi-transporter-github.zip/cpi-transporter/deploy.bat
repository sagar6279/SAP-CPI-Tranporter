@echo off
:: ════════════════════════════════════════════════════════════════
:: SAP CPI TRANSPORTER — One-Shot Deploy Script
:: Run this ONCE from: C:\Users\%USERNAME%\Downloads\cpi-transporter\
:: ════════════════════════════════════════════════════════════════

setlocal ENABLEDELAYEDEXPANSION

echo.
echo ╔══════════════════════════════════════════════════════════╗
echo ║        SAP CPI TRANSPORTER — AUTO DEPLOY                ║
echo ╚══════════════════════════════════════════════════════════╝
echo.

:: ── CONFIG — Edit these before running ──────────────────────────
set CF_API=https://api.cf.ap21.hana.ondemand.com
set CF_USER=cpi.sagar@hotmail.com
set BACKEND_APP=cpi-transporter-backend
set FRONTEND_APP=cpi-transporter-frontend

:: ── Step 1: Check prerequisites ──────────────────────────────────
echo [1/6] Checking prerequisites...
where cf >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo ERROR: CF CLI not found. Install from:
    echo   https://github.com/cloudfoundry/cli/releases
    pause & exit /b 1
)
where node >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo ERROR: Node.js not found. Install from: https://nodejs.org
    pause & exit /b 1
)
where npm >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo ERROR: npm not found. Install Node.js from: https://nodejs.org
    pause & exit /b 1
)
echo   CF CLI : OK
echo   Node   : OK
echo   npm    : OK

:: ── Step 2: CF Login ─────────────────────────────────────────────
echo.
echo [2/6] Logging into Cloud Foundry...
cf login -a %CF_API% -u %CF_USER%
if %ERRORLEVEL% neq 0 (
    echo ERROR: CF login failed. Check credentials.
    pause & exit /b 1
)
echo   CF Login: OK

:: ── Step 3: Deploy Backend ───────────────────────────────────────
echo.
echo [3/6] Deploying Backend...
cd /d "%~dp0backend"
copy main_api_complete.py main_api.py /Y >nul
cf push %BACKEND_APP% -f manifest.yml
if %ERRORLEVEL% neq 0 (
    echo ERROR: Backend deploy failed.
    pause & exit /b 1
)
echo   Backend: DEPLOYED

:: ── Step 4: Get backend URL ──────────────────────────────────────
echo.
echo [4/6] Getting Backend URL...
for /f "tokens=*" %%i in ('cf app %BACKEND_APP% ^| findstr "routes:"') do set ROUTES=%%i
echo   %ROUTES%
echo.
echo   !! IMPORTANT: Copy the backend URL from above !!
echo   It looks like: cpi-transporter-backend-xxxx.cfapps.ap21.hana.ondemand.com
echo.
set /p BACKEND_URL="   Paste backend URL here (without https://): "
set REACT_APP_API_URL=https://%BACKEND_URL%

:: ── Step 5: Build Frontend ───────────────────────────────────────
echo.
echo [5/6] Building Frontend...
cd /d "%~dp0frontend"
echo   Installing dependencies...
call npm install --silent
if %ERRORLEVEL% neq 0 (
    echo ERROR: npm install failed.
    pause & exit /b 1
)
echo   Building React app...
set DISABLE_ESLINT_PLUGIN=true
set REACT_APP_API_URL=https://%BACKEND_URL%
call npm run build
if %ERRORLEVEL% neq 0 (
    echo ERROR: React build failed.
    pause & exit /b 1
)
echo | set /p ="root: ." > build\Staticfile

:: ── Step 6: Deploy Frontend ──────────────────────────────────────
echo.
echo [6/6] Deploying Frontend...
cf push %FRONTEND_APP% -p "build" -b staticfile_buildpack -m 128M -k 512M -i 1 --no-manifest
if %ERRORLEVEL% neq 0 (
    echo ERROR: Frontend deploy failed.
    pause & exit /b 1
)
echo   Frontend: DEPLOYED

:: ── Done ─────────────────────────────────────────────────────────
echo.
echo ╔══════════════════════════════════════════════════════════╗
echo ║  ✅  DEPLOYMENT COMPLETE!                               ║
echo ╚══════════════════════════════════════════════════════════╝
echo.
cf apps
echo.
echo   Backend API : https://%BACKEND_URL%
echo   Open the frontend URL shown above in your browser.
echo.
pause
